/*
 * Recipe sharing between two screens running الساقي, by QR code — no internet,
 * no server. One screen shows a QR of the recipe; the other reads it with its
 * camera. The payload is the recipe's own fields packed small so it fits one QR.
 *
 * Uses vendor/qrcode-gen.js (make a QR) and vendor/jsqr.js (read a QR).
 */
(function (root) {
  'use strict';

  var PREFIX = 'SAQI1:'; // marks our QR, and the version, so we ignore other QRs

  // The QR library stores one byte per character, so Arabic must be turned into
  // UTF-8 bytes first and back on read; otherwise names come out as mojibake.
  // We encode the JSON string as UTF-8, then map each byte to a 0-255 char so
  // the library stores it verbatim.
  function utf8Encode(str) {
    if (root.TextEncoder) {
      var arr = new root.TextEncoder().encode(str), out = '';
      for (var i = 0; i < arr.length; i++) out += String.fromCharCode(arr[i]);
      return out;
    }
    return unescape(encodeURIComponent(str));
  }
  function utf8Decode(bytes) {
    try { return decodeURIComponent(escape(bytes)); } catch (e) { return bytes; }
  }

  // Keep only the fields a brew needs, with short keys, so the QR stays small
  // and scannable on a cheap camera.
  function pack(recipe) {
    var o = {
      n: recipe.name || '',
      d: recipe.dose_g,
      c: recipe.cup_type,
      g: recipe.grinder_size,
      ge: recipe.grinder_size_enabled,
      r: recipe.rpm,
      p: (recipe.pours || []).map(function (p) {
        return [p.volume_ml, p.temperature_c, p.pattern, p.flow_rate, p.pause_s,
          p.agitate_before, p.agitate_after];
      })
    };
    return PREFIX + utf8Encode(JSON.stringify(o));
  }

  function unpack(text) {
    if (!text || text.indexOf(PREFIX) !== 0) return null;
    var o;
    try { o = JSON.parse(utf8Decode(text.slice(PREFIX.length))); } catch (e) { return null; }
    if (!o || !o.p || !o.p.length) return null;
    return {
      id: 'r' + Math.random().toString(36).slice(2, 9),
      name: String(o.n || 'وصفة مشاركة'),
      dose_g: Number(o.d), cup_type: Number(o.c) || 3,
      grinder_size: Number(o.g) || 0, grinder_size_enabled: o.ge === 0 ? 0 : 1,
      rpm: Number(o.r) || 90,
      pours: o.p.map(function (a) {
        return {
          volume_ml: Number(a[0]), temperature_c: Number(a[1]), pattern: Number(a[2]) || 2,
          flow_rate: Number(a[3]) || 3.0, pause_s: Number(a[4]) || 0,
          agitate_before: Number(a[5]) || 2, agitate_after: Number(a[6]) || 2
        };
      })
    };
  }

  // Draw the recipe's QR into a container element as an <img>.
  function renderQR(container, recipe) {
    var text = pack(recipe);
    // Pick the smallest QR version whose capacity holds the text.
    var qr = null;
    for (var type = 4; type <= 20; type++) {
      try {
        var q = root.qrcode(type, 'M');
        q.addData(text);
        q.make();
        qr = q;
        break;
      } catch (e) { /* too small, try the next version */ }
    }
    if (!qr) { container.innerHTML = '<p class="hint">الوصفة كبيرة على الباركود</p>'; return false; }
    // cellSize 6, margin 4 cells — crisp and readable from a phone.
    container.innerHTML = qr.createImgTag(6, 16);
    var img = container.querySelector('img');
    if (img) { img.style.width = '100%'; img.style.height = 'auto'; img.style.maxWidth = '460px'; img.style.imageRendering = 'pixelated'; }
    return true;
  }

  // Camera scanner: opens the back camera, scans frames for our QR, calls
  // onFound(recipe) once. Returns a stop() function. onError(reason) on failure.
  function scan(videoEl, canvasEl, onFound, onError) {
    var stream = null, raf = null, stopped = false;
    var getUserMedia = navigator.mediaDevices && navigator.mediaDevices.getUserMedia
      ? function (c) { return navigator.mediaDevices.getUserMedia(c); }
      : function (c) {
          var legacy = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia;
          return legacy ? new Promise(function (res, rej) { legacy.call(navigator, c, res, rej); })
            : Promise.reject(new Error('no camera API'));
        };

    function tick() {
      if (stopped) return;
      if (videoEl.readyState === videoEl.HAVE_ENOUGH_DATA) {
        var w = videoEl.videoWidth, h = videoEl.videoHeight;
        if (w && h) {
          canvasEl.width = w; canvasEl.height = h;
          var ctx = canvasEl.getContext('2d');
          ctx.drawImage(videoEl, 0, 0, w, h);
          var img = ctx.getImageData(0, 0, w, h);
          var code = root.jsQR ? root.jsQR(img.data, w, h, { inversionAttempts: 'dontInvert' }) : null;
          if (code && code.data) {
            var recipe = unpack(code.data);
            if (recipe) { stop(); onFound(recipe); return; }
          }
        }
      }
      raf = root.requestAnimationFrame ? root.requestAnimationFrame(tick) : setTimeout(tick, 60);
    }

    function stop() {
      stopped = true;
      if (raf) { if (root.cancelAnimationFrame) root.cancelAnimationFrame(raf); clearTimeout(raf); }
      if (stream) stream.getTracks().forEach(function (t) { t.stop(); });
    }

    getUserMedia({ video: { facingMode: 'environment' }, audio: false }).then(function (s) {
      if (stopped) { s.getTracks().forEach(function (t) { t.stop(); }); return; }
      stream = s;
      videoEl.srcObject = s;
      videoEl.setAttribute('playsinline', 'true');
      var p = videoEl.play();
      if (p && p.catch) p.catch(function () {});
      tick();
    }).catch(function (e) {
      onError && onError(e && e.name === 'NotAllowedError' ? 'denied' : 'nocam');
    });

    return stop;
  }

  root.Share = { pack: pack, unpack: unpack, renderQR: renderQR, scan: scan };
})(typeof window !== 'undefined' ? window : this);
