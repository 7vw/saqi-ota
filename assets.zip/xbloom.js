/*
 * xBloom Studio BLE protocol — a port of xbloom-py (MIT, Mansour Alshekhi,
 * https://github.com/Alshekhi/xbloom-py) to plain browser JavaScript.
 *
 * Pure functions only: frames in and out as Uint8Array. The transport (the
 * Android BLE bridge, or the mock in the browser preview) lives elsewhere.
 * test/protocol_test.js checks every encoder byte-for-byte against xbloom-py.
 */
(function (root) {
  'use strict';

  // ---------------------------------------------------------------- consts
  var FFE1 = '0000ffe1-0000-1000-8000-00805f9b34fb'; // write: screen -> machine
  var FFE2 = '0000ffe2-0000-1000-8000-00805f9b34fb'; // notify: machine -> screen

  var CMD = {
    HANDSHAKE: 8100, BYPASS_DOSE: 8102, SET_CUP: 8104,
    RECIPE_GRIND: 8001, RECIPE_NO_GRIND: 8004, EXECUTE: 8002,
    TARE: 8500, BACK_TO_HOME: 8022, QUIT_RECIPE: 8017,
    BREW_PAUSE: 40518, BREW_RESUME: 40524, BREW_STOP: 40519,
    MODE: 11511, WATER_SOURCE: 4508, UNIT_WEIGHT: 8005, UNIT_TEMP: 8010,
    SLOT_WRITE: 11510
  };

  var NOTIFY = {
    ACTIVITY: 8023, WEIGHT: 20501, WEIGHT_ALT: 10507, WATER: 40523,
    GRINDER_START: 40502, BREWER_START: 40506, GRINDER_STOP: 40507,
    BLOOM: 40510, BREW_END: 40511, ENJOY: 40512, ABANDONED: 40513,
    PAUSED: 40515, RESUMED: 40516, GRINDER_PAUSED: 9009, BREWER_PAUSED: 9010,
    MACHINE_RESUMED: 9011, MACHINE_INFO: 40521, SLEEPING: 8009, AWAKE: 8011
  };

  var FAULTS = {
    40522: 'no_water', 40517: 'no_beans',
    8204: 'dose_water_error', 8203: 'gear_position_error'
  };

  var REFUSAL_BITS = [
    [0x000040, 'no_water'], [0x000800, 'not_on_home_screen'],
    [0x001000, 'not_on_home_screen'], [0x100000, 'not_ready'],
    [0x200000, 'restore_incomplete'], [0x400000, 'recipe_rejected'],
    [0x000100, 'machine_busy'], [0x000200, 'machine_busy'], [0x000400, 'machine_busy'],
    [0x004000, 'machine_busy'], [0x010000, 'machine_busy'], [0x020000, 'machine_busy'],
    [0x040000, 'machine_busy'], [0x080000, 'machine_busy'], [0x800000, 'machine_busy']
  ];
  var RESEND_MEANS_TAKEN = [0x800000, 0x200000];

  // Pour pattern: API value (what recipes store) -> wire byte.
  var PATTERN_API_TO_BYTE = { 1: 0, 2: 2, 3: 1 };
  var PATTERNS = [ // for the UI, in API order
    { api: 1, name: 'centered' }, { api: 2, name: 'spiral' }, { api: 3, name: 'circular' }
  ];

  var CUP_TYPES = [
    { api: 1, name: 'xPod', dose: [15, 15] },
    { api: 2, name: 'Omni dripper', dose: [5, 18] },
    { api: 3, name: 'Other', dose: [5, 25] },
    { api: 4, name: 'Tea', dose: [1, 5] }
  ];
  var CUP_WEIGHT_RANGE = { 1: [200, 80], 2: [110, 90], 3: [200, 80], 4: [200, 80] };

  var LIMITS = {
    grind_size: [1, 80], rpm: [60, 120], pours: [1, 9], volume: [0, 240],
    temp: [20, 98], flow: [3.0, 3.5], pause: [0, 59], ratio: [5, 25]
  };

  var MODE_PAYLOAD = { auto: [0x91, 0x32, 0x78, 0x56], pro: [0, 0, 0, 0] };
  var WATER_SOURCE_CODES = { tank: 0, tap: 1 };
  var WEIGHT_UNIT_CODES = { ml: 0, g: 1, oz: 2 };
  var TEMP_UNIT_CODES = { f: 0, c: 1 };

  // --------------------------------------------------------------- helpers
  var f32 = Math.fround;

  // Python's round(): halves go to the even neighbour.
  function pyRound(x) {
    var f = Math.floor(x), d = x - f;
    if (d < 0.5) return f;
    if (d > 0.5) return f + 1;
    return (f % 2 === 0) ? f : f + 1;
  }

  function floatBits(v) {
    var dv = new DataView(new ArrayBuffer(4));
    dv.setFloat32(0, v, true);
    return dv.getUint32(0, true);
  }

  function u16le(v) { return [v & 0xFF, (v >>> 8) & 0xFF]; }
  function u32le(v) { v = v >>> 0; return [v & 0xFF, (v >>> 8) & 0xFF, (v >>> 16) & 0xFF, (v >>> 24) & 0xFF]; }

  function toHex(bytes) {
    var s = '';
    for (var i = 0; i < bytes.length; i++) s += (bytes[i] < 16 ? '0' : '') + bytes[i].toString(16);
    return s;
  }
  function fromHex(hex) {
    var out = new Uint8Array(hex.length >> 1);
    for (var i = 0; i < out.length; i++) out[i] = parseInt(hex.substr(i * 2, 2), 16);
    return out;
  }

  // CRC16-Kermit: poly 0x8408 (reflected 0x1021), init 0.
  function crc16(bytes, len) {
    var crc = 0, n = len === undefined ? bytes.length : len;
    for (var i = 0; i < n; i++) {
      crc ^= bytes[i];
      for (var b = 0; b < 8; b++) crc = (crc & 1) ? ((crc >>> 1) ^ 0x8408) : (crc >>> 1);
    }
    return crc;
  }

  // 58 01 <type> <code LE16> <total_len LE32> 01 <data> <crc LE16>
  function buildFrame(code, ints, raw, frameType) {
    var body = [];
    if (raw) body = Array.prototype.slice.call(raw);
    else if (ints) ints.forEach(function (i) { body = body.concat(u32le(i)); });
    var out = [0x58, 0x01, (frameType || 1) & 0xFF]
      .concat(u16le(code), u32le(12 + body.length), [0x01], body);
    return new Uint8Array(out.concat(u16le(crc16(out))));
  }

  // ------------------------------------------------------------ recipe blob
  // The firmware commits a recipe (and its grind size) only when
  // trunc((ratio_byte / 10) * dose) == sum(pour volumes) in float32 maths.
  function gateConsistentVolumes(srcVols, doseI) {
    var total = 0;
    srcVols.forEach(function (v) { total += v; });
    if (doseI <= 0 || total <= 0 || !srcVols.length) {
      return [srcVols.map(pyRound), 0];
    }
    var r0 = pyRound((total / doseI) * 10);
    var chosen = null, target = null;
    var tries = [r0, r0 + 1, r0 - 1, r0 + 2, r0 - 2];
    for (var t = 0; t < tries.length; t++) {
      var r = tries[t];
      if (r <= 0 || r > 0xFF) continue;
      var prod = f32(f32(f32(r) / f32(10)) * f32(doseI));
      if (Math.trunc(prod) === Math.trunc(prod + 0.5)) { chosen = r; target = Math.trunc(prod); break; }
    }
    if (target === null) {
      chosen = Math.max(1, Math.min(0xFF, r0));
      target = Math.trunc(f32(f32(f32(chosen) / f32(10)) * f32(doseI)));
    }
    var ideal = srcVols.map(function (v) { return v * target / total; });
    var ints = ideal.map(function (x) { return Math.floor(x); });
    var sum = 0;
    ints.forEach(function (v) { sum += v; });
    var deficit = target - sum;
    if (deficit > 0) {
      var order = ideal.map(function (_, i) { return i; });
      order.sort(function (a, b) {
        var d = (ideal[b] - ints[b]) - (ideal[a] - ints[a]);
        return d !== 0 ? d : a - b; // stable, like Python's sorted()
      });
      for (var k = 0; k < deficit && k < order.length; k++) ints[order[k]] += 1;
    }
    return [ints, chosen & 0xFF];
  }

  function num(v, dflt) { return (v === undefined || v === null || v === '') ? dflt : Number(v); }

  function encodeRecipeBlob(pours, grinderSize, doseG, rpm) {
    var doseI = doseG ? pyRound(Number(doseG)) : 0;
    var src = pours.map(function (p) { return Math.max(0, num(p.volume_ml, 0)); });
    var g = gateConsistentVolumes(src, doseI);
    var vols = g[0], ratioX10 = g[1];
    var parts = [];
    pours.forEach(function (p, i) {
      var volume = i < vols.length ? vols[i] : 0;
      var temp = Math.trunc(num(p.temperature_c, 93));
      var pattern = PATTERN_API_TO_BYTE[Math.trunc(num(p.pattern, 1))];
      if (pattern === undefined) pattern = 0;
      var vib = (num(p.agitate_before, 2) === 1 ? 1 : 0) | (num(p.agitate_after, 2) === 1 ? 2 : 0);
      var flowByte = pyRound(num(p.flow_rate, 3.0) * 10) & 0xFF;
      var postWait = Math.trunc(num(p.pause_s, 0));
      if (volume > 127) {
        for (var c = 0; c < Math.floor(volume / 127); c++) parts.push(127, temp, pattern, vib);
        if (volume % 127) parts.push(volume % 127, temp, pattern, vib);
      } else {
        parts.push(volume, temp, pattern, vib);
      }
      parts.push((-postWait) & 0xFF, 0, i === 0 ? (Math.trunc(rpm) & 0xFF) : 0, flowByte);
    });
    var grinderByte = Math.min(Math.trunc(grinderSize), 80) & 0xFF;
    return new Uint8Array([parts.length & 0xFF].concat(parts, [grinderByte, ratioX10]));
  }

  function usesGrinder(recipe) {
    return num(recipe.grinder_size_enabled, 1) === 1 && Math.trunc(num(recipe.grinder_size, 0)) > 0;
  }

  // handshake -> bypass+dose -> cup range -> recipe -> execute
  function buildBrewFrames(recipe) {
    var dose = pyRound(num(recipe.dose_g, 0));
    var grinderSize = Math.trunc(num(recipe.grinder_size, 0));
    var rpm = Math.trunc(num(recipe.rpm, 0));
    var cup = Math.trunc(num(recipe.cup_type, 3));
    var useGrinder = usesGrinder(recipe);
    var range = CUP_WEIGHT_RANGE[cup] || [200, 80];
    var blob = encodeRecipeBlob(recipe.pours || [], useGrinder ? grinderSize : 0, dose,
      useGrinder ? rpm : 0);
    return [
      { name: 'handshake', frame: buildFrame(CMD.HANDSHAKE, [185, 1]) },
      { name: 'bypass+dose', frame: buildFrame(CMD.BYPASS_DOSE, [0, 0, dose]) },
      { name: 'set_cup', frame: buildFrame(CMD.SET_CUP, [floatBits(range[0]), floatBits(range[1])]) },
      { name: 'recipe', frame: buildFrame(useGrinder ? CMD.RECIPE_GRIND : CMD.RECIPE_NO_GRIND, null, blob) },
      { name: 'execute', frame: buildFrame(CMD.EXECUTE) }
    ];
  }

  // Writes a recipe into on-machine slot A/B/C (0/1/2) for brewing without a screen.
  function packetSlotWrite(slotIndex, recipe, scaleOn) {
    var useGrinder = usesGrinder(recipe);
    var blob = encodeRecipeBlob(recipe.pours || [], useGrinder ? Math.trunc(num(recipe.grinder_size, 0)) : 0,
      num(recipe.dose_g, 0), useGrinder ? Math.trunc(num(recipe.rpm, 0)) : 0);
    var flags = (scaleOn === false ? 0 : 0x10) | (useGrinder ? 0x02 : 0x04);
    var payload = [slotIndex & 0xFF, flags].concat(Array.prototype.slice.call(blob));
    return buildFrame(CMD.SLOT_WRITE, null, payload, 2);
  }

  var packets = {
    handshake: function () { return buildFrame(CMD.HANDSHAKE, [185, 1]); },
    tare: function () { return buildFrame(CMD.TARE); },
    pause: function () { return buildFrame(CMD.BREW_PAUSE); },
    resume: function () { return buildFrame(CMD.BREW_RESUME); },
    stop: function () { return buildFrame(CMD.BREW_STOP); },
    quitRecipe: function () { return buildFrame(CMD.QUIT_RECIPE); },
    mode: function (m) { return buildFrame(CMD.MODE, null, MODE_PAYLOAD[m] || MODE_PAYLOAD.pro, 2); },
    waterSource: function (s) { return buildFrame(CMD.WATER_SOURCE, [WATER_SOURCE_CODES[s] || 0]); },
    weightUnit: function (u) { return buildFrame(CMD.UNIT_WEIGHT, [WEIGHT_UNIT_CODES[u]]); },
    tempUnit: function (u) { return buildFrame(CMD.UNIT_TEMP, [TEMP_UNIT_CODES[u] === 0 ? 0 : 1]); },
    slotWrite: packetSlotWrite
  };

  // ------------------------------------------------------- notifications
  function frameCode(frame) {
    return (frame.length >= 5 && frame[0] === 0x58) ? (frame[3] | (frame[4] << 8)) : null;
  }

  function frameLength(data) {
    if (data.length < 9 || data[0] !== 0x58 || data[1] !== 0x02) return null;
    var len = (data[5] | (data[6] << 8) | (data[7] << 16) | (data[8] << 24)) >>> 0;
    return (len >= 12 && len <= 1024) ? len : null;
  }

  function crcOk(frame) {
    var n = frame.length;
    return n >= 12 && crc16(frame, n - 2) === (frame[n - 2] | (frame[n - 1] << 8));
  }

  function walk(data) {
    var frames = [], i = 0;
    while (i < data.length) {
      var len = frameLength(data.subarray(i));
      if (len === null || len > data.length - i) break;
      frames.push(cut(data, i, i + len));
      i += len;
    }
    return [frames, cut(data, i)];
  }

  function couldOpenFrame(data) {
    if (data.length < 9 && data[0] === 0x58 && (data.length < 2 || data[1] === 0x02)) return true;
    var len = frameLength(data);
    return len !== null && len > data.length;
  }

  // TypedArray.slice is newer than the frame's WebView 44: copy a subarray.
  function cut(a, start, end) { return new Uint8Array(a.subarray(start, end === undefined ? a.length : end)); }

  function concat(a, b) {
    var out = new Uint8Array(a.length + b.length);
    out.set(a, 0); out.set(b, a.length);
    return out;
  }

  // The machine packs several frames into one notification, and splits a frame
  // across two when it does not fit. Feed every notification in order.
  function Assembler() { this.pending = new Uint8Array(0); }
  Assembler.prototype.reset = function () { this.pending = new Uint8Array(0); };
  Assembler.prototype.feed = function (data) {
    var frames = [];
    if (this.pending.length) {
      var joined = concat(this.pending, data);
      var len = frameLength(joined);
      if (len !== null && len > joined.length) { this.pending = joined; return []; }
      this.pending = new Uint8Array(0);
      if (len !== null && crcOk(joined.subarray(0, len))) {
        frames.push(cut(joined, 0, len));
        data = cut(joined, len);
      }
    }
    if (!data.length) return frames;
    var w = walk(data);
    if (!w[0].length && !frames.length && !couldOpenFrame(data)) return [data];
    frames = frames.concat(w[0]);
    if (w[1].length && couldOpenFrame(w[1])) this.pending = w[1];
    return frames;
  };

  function payloadOf(frame) { return frame.length > 12 ? cut(frame, 10, frame.length - 2) : new Uint8Array(0); }

  function refusalCode(frame) {
    var p = payloadOf(frame);
    if (p.length < 16) return null;
    var code = (p[12] << 16) | (p[13] << 8) | p[14];
    return code || null;
  }
  function refusalFor(code) {
    if (!code) return null;
    for (var i = 0; i < REFUSAL_BITS.length; i++) if (code & REFUSAL_BITS[i][0]) return REFUSAL_BITS[i][1];
    return null;
  }
  function takenOnResend(code) {
    return !!code && RESEND_MEANS_TAKEN.some(function (b) { return code & b; });
  }

  function ascii(p, start, end) {
    if (p.length < end) return null;
    var s = '';
    for (var i = start; i < end && p[i] !== 0; i++) {
      if (p[i] < 32 || p[i] > 126) return null;
      s += String.fromCharCode(p[i]);
    }
    s = s.trim();
    return s || null;
  }

  function decode(frame) {
    if (frame.length < 10 || frame[0] !== 0x58 || frame[1] !== 0x02) return null;
    var cmd = frame[3] | (frame[4] << 8);
    var p = payloadOf(frame);
    var dv = p.length >= 4 ? new DataView(p.buffer, p.byteOffset, p.length) : null;
    var out = { cmd: cmd };
    if ((cmd === NOTIFY.WEIGHT || cmd === NOTIFY.WEIGHT_ALT) && dv) out.weight_g = Math.round(dv.getFloat32(0, true) * 100) / 100;
    else if (cmd === NOTIFY.WATER && dv) out.water_ml = Math.round(dv.getFloat32(0, true) * 10) / 10;
    else if (cmd === NOTIFY.ACTIVITY && dv) out.activity = dv.getUint32(0, true);
    else if (cmd === NOTIFY.BLOOM && dv) out.pour_index = dv.getUint32(0, true);
    else if (cmd === NOTIFY.MACHINE_INFO && p.length >= 35) {
      out.serial = ascii(p, 0, 13);
      out.model = ascii(p, 13, 19);
      var fw = ascii(p, 19, 29);
      if (fw && /\d/.test(fw)) out.fw_version = fw;
      out.water_enough = p[33];
      if (p.length >= 37) out.water_source = p[36] ? 'tap' : 'tank';
      if (p.length >= 40) out.grind_size_current = Math.max(p[37] - 30, 1);
      if (p.length >= 42) {
        out.temp_unit = p[40] ? 'c' : 'f';
        out.weight_unit = { 0: 'ml', 1: 'g', 2: 'oz' }[p[41]] || null;
      }
      if (p.length >= 55) {
        out.mode = (p[51] === 0x91 && p[52] === 0x32 && p[53] === 0x78 && p[54] === 0x56) ? 'auto' : 'pro';
      }
    }
    if (FAULTS[cmd]) out.fault = FAULTS[cmd];
    return out;
  }

  // ------------------------------------------------------- recipe helpers
  // Spread dose x ratio over n pours; a 1:3 bloom first when there are 2+.
  function autoPours(doseG, ratio, n, temp) {
    var total = Math.round(doseG * ratio);
    var pours = [];
    var bloom = n > 1 ? Math.round(doseG * 3) : total;
    var rest = n > 1 ? (total - bloom) / (n - 1) : 0;
    for (var i = 0; i < n; i++) {
      pours.push({
        volume_ml: i === 0 ? bloom : (i === n - 1 ? total - bloom - Math.round(rest) * (n - 2) : Math.round(rest)),
        temperature_c: temp, pattern: 2, flow_rate: 3.0,
        pause_s: i === 0 && n > 1 ? 30 : (i < n - 1 ? 10 : 0),
        agitate_before: 2, agitate_after: i === 0 ? 1 : 2
      });
    }
    return pours;
  }

  function totalWater(recipe) {
    var s = 0;
    (recipe.pours || []).forEach(function (p) { s += num(p.volume_ml, 0); });
    return s;
  }

  // Problems the machine would refuse the recipe for. Empty = fine.
  function validate(recipe) {
    var errs = [];
    var cup = CUP_TYPES.filter(function (c) { return c.api === recipe.cup_type; })[0];
    if (!cup) errs.push('cup_type');
    else if (recipe.dose_g < cup.dose[0] || recipe.dose_g > cup.dose[1]) errs.push('dose');
    var pours = recipe.pours || [];
    if (pours.length < LIMITS.pours[0] || pours.length > LIMITS.pours[1]) errs.push('pour_count');
    if (usesGrinder(recipe) && (recipe.grinder_size > LIMITS.grind_size[1] ||
        recipe.rpm < LIMITS.rpm[0] || recipe.rpm > LIMITS.rpm[1])) errs.push('grinder');
    pours.forEach(function (p, i) {
      if (p.volume_ml < 0 || p.volume_ml > LIMITS.volume[1]) errs.push('pour' + i + '_volume');
      if (p.temperature_c < LIMITS.temp[0] || p.temperature_c > LIMITS.temp[1]) errs.push('pour' + i + '_temp');
      if (p.pause_s < 0 || p.pause_s > LIMITS.pause[1]) errs.push('pour' + i + '_pause');
    });
    var water = totalWater(recipe);
    if (water <= 0) errs.push('water');
    // Tea (cup 4) steeps leaves in the siphon brewer, so its water-to-leaf
    // ratio is far higher than coffee's — the brew ratio check doesn't apply.
    else if (recipe.dose_g > 0 && recipe.cup_type !== 4) {
      var ratio = water / recipe.dose_g;
      if (ratio < LIMITS.ratio[0] || ratio > LIMITS.ratio[1]) errs.push('ratio');
    }
    return errs;
  }

  // -------------------------------------------- recipes from outside the app
  function clamp(v, lo, hi, dflt) { v = Number(v); if (!isFinite(v)) v = dflt; return Math.min(hi, Math.max(lo, v)); }
  function oneOf(v, list, dflt) { v = Number(v); return list.indexOf(v) >= 0 ? v : dflt; }

  // Rebuild a recipe from untrusted input (the phone page, an import) with only
  // the fields we know, every number forced into the machine's limits. Callers
  // still run validate() — this only guarantees a well-formed object.
  function sanitize(r) {
    r = r || {};
    var cup = oneOf(r.cup_type, [1, 2, 3, 4], 2);
    var tea = cup === 4;
    var range = CUP_TYPES.filter(function (c) { return c.api === cup; })[0].dose;
    var pours = (Array.isArray(r.pours) ? r.pours : []).slice(0, LIMITS.pours[1]).map(function (p) {
      p = p || {};
      return {
        volume_ml: Math.round(clamp(p.volume_ml, LIMITS.volume[0], LIMITS.volume[1], 0)),
        temperature_c: Math.round(clamp(p.temperature_c, LIMITS.temp[0], LIMITS.temp[1], 92)),
        pattern: oneOf(p.pattern, [1, 2, 3], 2),
        flow_rate: Math.round(clamp(p.flow_rate, LIMITS.flow[0], LIMITS.flow[1], 3.0) * 10) / 10,
        pause_s: Math.round(clamp(p.pause_s, LIMITS.pause[0], LIMITS.pause[1], 0)),
        agitate_before: oneOf(p.agitate_before, [1, 2], 2),
        agitate_after: oneOf(p.agitate_after, [1, 2], 2)
      };
    });
    var grinds = !tea && Number(r.grinder_size_enabled) !== 0;
    return {
      id: 'r' + Math.random().toString(36).slice(2, 9),
      name: String(r.name == null ? '' : r.name).replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 40),
      dose_g: Math.round(clamp(r.dose_g, range[0], range[1], range[0]) * 10) / 10,
      cup_type: cup,
      grinder_size: grinds ? Math.round(clamp(r.grinder_size, LIMITS.grind_size[0], LIMITS.grind_size[1], 50)) : 0,
      grinder_size_enabled: grinds ? 1 : 0,
      rpm: Math.round(clamp(r.rpm, LIMITS.rpm[0], LIMITS.rpm[1], 90)),
      pours: pours
    };
  }

  // An xBloom recipe (the recipeVo behind a share-h5.xbloom.com link) in our
  // shape. Field names are xBloom's; 1/2 flags mean yes/no on both sides. A tea
  // share keeps its per-steep water at the top level (teaVolume), as xBloom's
  // own share page does. Extra water (bypass) has no equivalent here: reported
  // back in .bypass so the page can say so.
  function fromXbloom(vo, teaVolume) {
    vo = vo || {};
    var cup = Number(vo.cupType), tea = cup === 4;
    var r = sanitize({
      name: vo.theName, dose_g: vo.dose, cup_type: cup,
      grinder_size: vo.grinderSize, grinder_size_enabled: Number(vo.isSetGrinderSize) === 1 ? 1 : 0, rpm: vo.rpm,
      pours: (vo.pourList || []).map(function (p) {
        return {
          volume_ml: tea && teaVolume ? teaVolume : p.volume, temperature_c: p.temperature, pattern: p.pattern,
          flow_rate: p.flowRate, pause_s: p.pausing,
          agitate_before: p.isEnableVibrationBefore, agitate_after: p.isEnableVibrationAfter
        };
      })
    });
    r.bypass = Number(vo.isEnableBypassWater) === 1 ? { volume_ml: Number(vo.bypassVolume) || 0, temperature_c: Number(vo.bypassTemp) || 0 } : null;
    return r;
  }

  root.XB = {
    sanitize: sanitize, fromXbloom: fromXbloom,
    FFE1: FFE1, FFE2: FFE2, CMD: CMD, NOTIFY: NOTIFY, FAULTS: FAULTS,
    PATTERNS: PATTERNS, CUP_TYPES: CUP_TYPES, LIMITS: LIMITS,
    crc16: crc16, buildFrame: buildFrame, floatBits: floatBits, pyRound: pyRound,
    encodeRecipeBlob: encodeRecipeBlob, buildBrewFrames: buildBrewFrames, packets: packets,
    Assembler: Assembler, decode: decode, frameCode: frameCode, refusalCode: refusalCode,
    refusalFor: refusalFor, takenOnResend: takenOnResend,
    toHex: toHex, fromHex: fromHex, autoPours: autoPours, totalWater: totalWater, validate: validate
  };
})(typeof window !== 'undefined' ? window : this);
