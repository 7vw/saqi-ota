/*
 * A pretend xBloom for the browser preview: answers commands and plays a
 * sped-up brew, so the screens can be tried without the machine.
 * Only used when there is no Android bridge (window.XBNative).
 */
(function (root) {
  'use strict';

  function notify(code, payload) {
    payload = payload || [];
    var body = [0x58, 0x02, 0x07, code & 0xFF, (code >> 8) & 0xFF];
    var len = 12 + payload.length;
    body.push(len & 0xFF, (len >> 8) & 0xFF, 0, 0, 0xC1);
    body = body.concat(Array.prototype.slice.call(payload));
    var crc = XB.crc16(body);
    return XB.toHex(new Uint8Array(body.concat([crc & 0xFF, crc >> 8])));
  }
  function f32(v) { var b = new Uint8Array(4); new DataView(b.buffer).setFloat32(0, v, true); return b; }
  function u32(v) { var b = new Uint8Array(4); new DataView(b.buffer).setUint32(0, v, true); return b; }

  function Mock() {
    this.connected = false;
    this.waterSource = 0; this.mode = 'pro'; this.weightUnit = 1; this.tempUnit = 1;
    this.recipe = null; this.timers = [];
  }
  Mock.prototype.cb = function () { return root.xbNative; };
  Mock.prototype.status = function () { return 'ok'; };
  Mock.prototype.startScan = function () {
    var self = this;
    setTimeout(function () { self.cb().onScan('XBLOOM A1B2C3', 'D4:2F:11:A1:B2:C3', -58); }, 900);
  };
  Mock.prototype.stopScan = function () {};
  Mock.prototype.connect = function () {
    var self = this;
    this.cb().onState('connecting', '');
    setTimeout(function () {
      self.connected = true;
      self.cb().onState('connected', '');
      self.heartbeat();
      self.hb = setInterval(function () { self.heartbeat(); }, 5000);
    }, 800);
  };
  Mock.prototype.disconnect = function () {
    this.connected = false;
    clearInterval(this.hb);
    this.cb().onState('disconnected', '');
  };
  Mock.prototype.heartbeat = function () {
    var p = new Uint8Array(64);
    var s = 'XBS2408A1B2C3J15   V12.0D.500';
    for (var i = 0; i < s.length; i++) p[i] = s.charCodeAt(i);
    p[33] = 1; p[36] = this.waterSource; p[37] = 80; p[40] = this.tempUnit; p[41] = this.weightUnit;
    if (this.mode === 'auto') p.set([0x91, 0x32, 0x78, 0x56], 51);
    this.cb().onNotify(notify(XB.NOTIFY.MACHINE_INFO, p));
  };
  Mock.prototype.later = function (ms, fn) { this.timers.push(setTimeout(fn, ms)); };
  Mock.prototype.write = function (hex) {
    var f = XB.fromHex(hex), code = XB.frameCode(f), self = this;
    var payload = Array.prototype.slice.call(f.subarray(10, f.length - 2));
    setTimeout(function () { self.cb().onNotify(notify(code, new Uint8Array(16))); }, 250);
    var C = XB.CMD;
    if (code === C.WATER_SOURCE) this.waterSource = payload[0];
    if (code === C.UNIT_WEIGHT) this.weightUnit = payload[0];
    if (code === C.UNIT_TEMP) this.tempUnit = payload[0];
    if (code === C.MODE) this.mode = payload[0] === 0x91 ? 'auto' : 'pro';
    if ([C.WATER_SOURCE, C.UNIT_WEIGHT, C.UNIT_TEMP, C.MODE].indexOf(code) >= 0) setTimeout(function () { self.heartbeat(); }, 400);
    if (code === C.RECIPE_GRIND || code === C.RECIPE_NO_GRIND) this.recipe = { grind: code === C.RECIPE_GRIND, blob: payload };
    if (code === C.EXECUTE) setTimeout(function () { self.brew(); }, 400);
    if (code === C.TARE) this.say(XB.NOTIFY.WEIGHT, f32(0));
    if (code === C.BREW_PAUSE) { this.paused = true; this.say(XB.NOTIFY.PAUSED); }
    if (code === C.BREW_RESUME) { this.paused = false; this.say(XB.NOTIFY.RESUMED); }
    if (code === C.BREW_STOP) { this.stop(); this.say(XB.NOTIFY.ACTIVITY, u32(1)); }
    return true;
  };
  Mock.prototype.say = function (code, payload) {
    if (this.connected) this.cb().onNotify(notify(code, payload));
  };
  Mock.prototype.stop = function () {
    this.timers.forEach(clearTimeout); this.timers = [];
    clearInterval(this.tick); this.paused = false;
  };
  // Grind 3 s, then each pour fills at ~30 ml/s (10x speed).
  Mock.prototype.brew = function () {
    var self = this, N = XB.NOTIFY, blob = this.recipe ? this.recipe.blob : [0];
    // 4-byte groups: pour chunks [ml, temp, pattern, vib] then one timing
    // block [-pause, 0, rpm, flow]; a chunk's temp byte is never 0.
    var pours = [], vol = 0, end = 1 + blob[0];
    for (var i = 1; i + 4 <= end; i += 4) {
      if (blob[i + 1] !== 0) { vol += blob[i]; continue; }
      pours.push({ vol: vol, wait: (256 - blob[i]) % 256 });
      vol = 0;
    }
    var t = 0, weight = 0, water = 0;
    this.say(N.ACTIVITY, u32(34));
    if (this.recipe && this.recipe.grind) {
      this.say(N.GRINDER_START);
      t = 3000;
      this.later(t, function () { self.say(N.GRINDER_STOP); self.say(N.ACTIVITY, u32(16)); });
    }
    pours.forEach(function (p, k) {
      self.later(t, function () { self.say(N.BLOOM, u32(k)); });
      var steps = Math.max(1, Math.round(p.vol / 6));
      for (var s = 1; s <= steps; s++) {
        (function (s) {
          self.later(t + s * 200, function () {
            if (self.paused) return;
            water += p.vol / steps; weight += p.vol / steps * 0.9;
            self.say(N.WATER, f32(water)); self.say(N.WEIGHT, f32(weight));
          });
        })(s);
      }
      t += steps * 200 + Math.min(p.wait, 10) * 100 + 300;
    });
    this.later(t + 500, function () { self.say(N.BREW_END); self.say(N.ENJOY); self.say(N.ACTIVITY, u32(36)); });
    this.later(t + 6000, function () { self.say(N.ACTIVITY, u32(1)); });
  };

  root.XBMock = Mock;
})(window);
