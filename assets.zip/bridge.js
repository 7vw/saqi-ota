/*
 * Transport through the ESP32 Wi-Fi bridge (bridge/src/main.cpp), for screens
 * without Bluetooth such as the Memoria-10 frame. Same API as the Android
 * bridge, so Link does not know the difference.
 */
(function (root) {
  'use strict';

  var PORT = 81;

  function WsTransport() {
    this.ws = null;
    this.open = false;
    this.host = null;
    this.id = null;   // the bridge's own id, e.g. "7A3F" (last digits of its MAC)
    this.found = [];  // bridges seen by the last search: [{ip, id}]
    try {
      this.host = localStorage.getItem('xb.bridge');
      this.id = localStorage.getItem('xb.bridgeId');
    } catch (e) { /* preview */ }
  }

  WsTransport.prototype.cb = function () { return root.xbNative; };

  WsTransport.prototype.setHost = function (host, id) {
    this.host = host;
    if (id) this.id = id;
    try {
      localStorage.setItem('xb.bridge', host);
      if (id) localStorage.setItem('xb.bridgeId', id);
    } catch (e) { /* preview */ }
    if (this.ws) { this.ws.onclose = null; this.ws.close(); this.ws = null; }
    this.open = false;
    this.start();
  };

  // Asks the Android side to find bridges on the Wi-Fi (UDP broadcast). Takes
  // the one this screen used before, or the only one there is; with several
  // and none chosen yet it takes none, and the setup screen lists them.
  // done(chosen or null, all found).
  WsTransport.prototype.find = function (done) {
    var self = this;
    if (!root.XBNative || !root.XBNative.findBridge) { if (done) done(null, []); return; }
    root.xbNative.onBridges = function (list) {
      self.found = list || [];
      var pick = null;
      self.found.forEach(function (b) { if (self.id && b.id === self.id) pick = b; });
      if (!pick && !self.id && self.found.length === 1) pick = self.found[0];
      if (pick && (pick.ip !== self.host || !self.open)) self.setHost(pick.ip, pick.id);
      if (done) done(pick, self.found);
    };
    root.XBNative.findBridge();
  };

  WsTransport.prototype.choose = function (bridge) { this.setHost(bridge.ip, bridge.id); };

  WsTransport.prototype.start = function () {
    var self = this;
    clearTimeout(this.retry);
    if (!this.host) {
      // Not known yet: look for it, and keep looking.
      this.find(function (pick) { if (!pick) self.retry = setTimeout(function () { self.start(); }, 5000); });
      return;
    }
    var ws;
    try { ws = new WebSocket('ws://' + (this.host.indexOf(':') >= 0 ? this.host : this.host + ':' + PORT) + '/'); } catch (e) { return this.later(); }
    this.ws = ws;
    ws.onopen = function () { self.open = true; ws.send('hello'); };
    ws.onmessage = function (ev) { self.onLine(String(ev.data)); };
    ws.onclose = function () {
      var was = self.open;
      self.open = false;
      self.ws = null;
      if (was) self.cb().onState('disconnected', 'bridge_offline');
      self.later();
    };
    ws.onerror = function () { /* onclose follows */ };
  };

  WsTransport.prototype.later = function () {
    var self = this;
    clearTimeout(this.retry);
    // The bridge's address can change after a router restart: re-find it now and then.
    this.fails = (this.fails || 0) + 1;
    if (this.fails % 6 === 0) this.find();
    this.retry = setTimeout(function () { self.start(); }, 3000);
  };

  WsTransport.prototype.onLine = function (line) {
    var cb = this.cb(), sp = line.indexOf(' ');
    var verb = sp < 0 ? line : line.slice(0, sp), rest = sp < 0 ? '' : line.slice(sp + 1);
    this.fails = 0;
    if (verb === 'notify') cb.onNotify(rest);
    else if (verb === 'state') {
      var p = rest.split(' ');
      cb.onState(p[0], p.slice(1).join(' '));
    } else if (verb === 'scan') {
      var q = rest.split(' ');
      cb.onScan(q.slice(2).join(' '), q[1], parseInt(q[0], 10));
    } else if (verb === 'hello') {
      var id = rest.split(' ')[1];
      if (id && id !== this.id) {
        this.id = id;
        try { localStorage.setItem('xb.bridgeId', id); } catch (e) { /* preview */ }
      }
      if (cb.onBridgeHello) cb.onBridgeHello(id);
    }
  };

  WsTransport.prototype.send = function (line) {
    if (!this.open) return false;
    this.ws.send(line);
    return true;
  };

  WsTransport.prototype.status = function () { return this.open ? 'ok' : 'no_bridge'; };
  WsTransport.prototype.startScan = function () { this.send('scan'); };
  WsTransport.prototype.stopScan = function () { this.send('stop'); };
  WsTransport.prototype.connect = function (addr) {
    if (this.send('connect ' + addr)) this.cb().onState('connecting', '');
  };
  WsTransport.prototype.disconnect = function () { this.send('disconnect'); };
  WsTransport.prototype.write = function (hex) { return this.send('write ' + hex); };

  root.WsTransport = WsTransport;
})(window);
