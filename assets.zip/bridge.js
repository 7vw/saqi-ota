/*
 * Transport through the ESP32 Wi-Fi bridge (bridge/src/main.cpp), for screens
 * without Bluetooth such as the Memoria-10 frame. Same API as the Android
 * bridge, so Link does not know the difference.
 */
(function (root) {
  'use strict';

  var PORT = 81;

  function WsTransport() {
    this.ws = null;
    this.open = false;
    this.host = null;
    this.id = null;   // the bridge's own id, e.g. "7A3F" (last digits of its MAC)
    this.found = [];  // bridges seen by the last search: [{ip, id}]
    try {
      this.host = localStorage.getItem('xb.bridge');
      this.id = localStorage.getItem('xb.bridgeId');
    } catch (e) { /* preview */ }
  }

  WsTransport.prototype.cb = function () { return root.xbNative; };

  WsTransport.prototype.setHost = function (host, id) {
    this.host = host;
    if (id) this.id = id;
    try {
      localStorage.setItem('xb.bridge', host);
      if (id) localStorage.setItem('xb.bridgeId', id);
    } catch (e) { /* preview */ }
    if (this.ws) { var old = this.ws; this.ws = null; old.onclose = null; try { old.close(); } catch (e) { /* */ } }
    clearInterval(this.beat);
    this.open = false;
    this.start();
  };

  // Asks the Android side to find bridges on the Wi-Fi (UDP broadcast). Takes
  // the one this screen used before, or the only one there is; with several
  // and none chosen yet it takes none, and the setup screen lists them.
  // done(chosen or null, all found).
  // The bridge's Wi-Fi naps between beacons (it shares the radio with
  // Bluetooth), so one broadcast can go unheard: ask up to three times
  // before saying there's none.
  WsTransport.prototype.find = function (done, tries) {
    var self = this;
    tries = tries || 1;
    if (!root.XBNative || !root.XBNative.findBridge) { if (done) done(null, []); return; }
    root.xbNative.onBridges = function (list) {
      if ((!list || !list.length) && tries < 3) { setTimeout(function () { self.find(done, tries + 1); }, 400); return; }
      self.found = list || [];
      var pick = null;
      self.found.forEach(function (b) { if (self.id && b.id === self.id) pick = b; });
      if (!pick && !self.id && self.found.length === 1) pick = self.found[0];
      if (pick && (pick.ip !== self.host || !self.open)) self.setHost(pick.ip, pick.id);
      if (done) done(pick, self.found);
    };
    root.XBNative.findBridge();
  };

  WsTransport.prototype.choose = function (bridge) { this.setHost(bridge.ip, bridge.id); };

  WsTransport.prototype.start = function () {
    var self = this;
    clearTimeout(this.retry);
    if (!this.host) {
      // Not known yet: look for it, and keep looking.
      this.find(function (pick) { if (!pick) self.retry = setTimeout(function () { self.start(); }, 5000); });
      return;
    }
    var ws;
    try { ws = new WebSocket('ws://' + (this.host.indexOf(':') >= 0 ? this.host : this.host + ':' + PORT) + '/'); } catch (e) { return this.later(); }
    this.ws = ws;
    // A link can die without a close (the bridge lost power or Wi-Fi): the
    // socket then looks open for minutes. Say hello every 8 s; the bridge
    // answers every hello, so 20 s of silence means it's gone: drop the
    // socket and look again.
    var opened = setTimeout(function () { if (!self.open) { try { ws.close(); } catch (e) { /* */ } } }, 8000);
    ws.onopen = function () {
      clearTimeout(opened);
      self.open = true; self.heard = Date.now(); ws.send('hello');
      clearInterval(self.beat);
      self.beat = setInterval(function () {
        if (self.ws !== ws) return clearInterval(self.beat);
        if (Date.now() - self.heard > 20000) { try { ws.close(); } catch (e) { /* */ } ws.onclose(); return; }
        try { ws.send('hello'); } catch (e) { /* */ }
      }, 8000);
    };
    ws.onmessage = function (ev) { self.heard = Date.now(); self.onLine(String(ev.data)); };
    ws.onclose = function () {
      clearTimeout(opened);
      if (self.ws !== ws) return;  // an old socket closing late
      clearInterval(self.beat);
      var was = self.open;
      self.open = false;
      self.ws = null;
      if (was) self.cb().onState('disconnected', 'bridge_offline');
      self.later();
    };
    ws.onerror = function () { /* onclose follows */ };
  };

  WsTransport.prototype.later = function () {
    var self = this;
    clearTimeout(this.retry);
    // The bridge's address can change after a router restart: re-find it now and then.
    this.fails = (this.fails || 0) + 1;
    if (this.fails % 3 === 0) this.find();
    this.retry = setTimeout(function () { self.start(); }, 3000);
  };

  WsTransport.prototype.onLine = function (line) {
    var cb = this.cb(), sp = line.indexOf(' ');
    var verb = sp < 0 ? line : line.slice(0, sp), rest = sp < 0 ? '' : line.slice(sp + 1);
    this.fails = 0;
    if (verb === 'notify') cb.onNotify(rest);
    else if (verb === 'state') {
      var p = rest.split(' ');
      cb.onState(p[0], p.slice(1).join(' '));
    } else if (verb === 'scan') {
      var q = rest.split(' ');
      cb.onScan(q.slice(2).join(' '), q[1], parseInt(q[0], 10));
    } else if (verb === 'info') {
      // "info wifi=-62 ble=-71" (bridge firmware 2+): signal strengths in dBm, 0 = none.
      var info = { at: Date.now() };
      rest.split(' ').forEach(function (kv) { var e = kv.split('='); if (e.length === 2) info[e[0]] = parseInt(e[1], 10) || 0; });
      this.info = info;
    } else if (verb === 'hello') {
      var hp = rest.split(' '), id = hp[1];
      this.version = hp[0] || '';
      if (id && id !== this.id) {
        this.id = id;
        try { localStorage.setItem('xb.bridgeId', id); } catch (e) { /* preview */ }
      }
      if (cb.onBridgeHello) cb.onBridgeHello(id);
    }
  };

  WsTransport.prototype.send = function (line) {
    if (!this.open) return false;
    this.ws.send(line);
    return true;
  };

  WsTransport.prototype.status = function () { return this.open ? 'ok' : 'no_bridge'; };
  WsTransport.prototype.startScan = function () { this.send('scan'); };
  WsTransport.prototype.stopScan = function () { this.send('stop'); };
  WsTransport.prototype.connect = function (addr) {
    if (this.send('connect ' + addr)) this.cb().onState('connecting', '');
  };
  WsTransport.prototype.disconnect = function () { this.send('disconnect'); };
  WsTransport.prototype.write = function (hex) { return this.send('write ' + hex); };

  root.WsTransport = WsTransport;
})(window);
