/* Screens: recipes, recipe editor, live brew, settings. */
(function () {
  'use strict';

  // Bluetooth in this screen -> use it. No Bluetooth (the Memoria-10 frame) ->
  // go through the ESP32 Wi-Fi bridge. In a desktop browser: the pretend
  // machine, or a bridge given as ?bridge=host[:port].
  var query = /[?&]bridge=([^&]+)/.exec(location.search);
  var native = window.XBNative && XBNative.status() !== 'no_bluetooth';
  var viaBridge = !native && (!!window.XBNative || !!query);
  var transport = native ? window.XBNative : viaBridge ? new WsTransport() : new XBMock();
  if (query) transport.host = decodeURIComponent(query[1]);
  var link = new Link(transport);
  var $view = document.getElementById('view');

  // ---------------------------------------------------------------- text
  var PATTERN_AR = { 1: 'وسط', 2: 'حلزوني', 3: 'دائري' };
  var CUP_AR = { 1: 'xPod', 2: 'Omni', 3: 'آخر', 4: 'شاي' };
  var REASON_AR = {
    no_water: 'الماء ناقص — عبّ الخزان', not_on_home_screen: 'رجّع المكينة للشاشة الرئيسية وحاول مرة ثانية',
    not_ready: 'المكينة مو جاهزة — طفّها وشغّلها', restore_incomplete: 'المكينة مو جاهزة — طفّها وشغّلها',
    recipe_rejected: 'المكينة رفضت الوصفة — راجع كمية الماء والدفعات', machine_busy: 'المكينة مشغولة، انتظر شوي',
    no_reply: 'المكينة ما ردّت — تأكد إنها شغالة وقريبة', not_connected: 'مو متصل بالمكينة',
    no_beans: 'ما فيه بن في المطحنة', refused: 'المكينة رفضت الأمر', dose_water_error: 'خطأ في كمية البن أو الماء',
    gear_position_error: 'خطأ في وضع المطحنة'
  };
  var PHASE_AR = {
    starting: 'نجهّز الوصفة…', grinding: 'يطحن البن', pouring: 'يصب الماء', paused: 'متوقف مؤقتاً',
    done: 'قهوتك جاهزة', stopped: 'تم الإيقاف', failed: 'ما اكتمل التحضير'
  };

  function esc(s) {
    return String(s === undefined || s === null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function fmt(n, d) { return (Math.round(n * Math.pow(10, d || 0)) / Math.pow(10, d || 0)).toString(); }
  function ratioOf(r) { var w = XB.totalWater(r); return r.dose_g ? w / r.dose_g : 0; }

  // -------------------------------------------------------- language (AR/EN)
  // The whole UI is authored in Arabic. For English we translate on the fly:
  // a dictionary + L() for strings built in code (toasts, confirms), and a
  // MutationObserver that rewrites rendered Arabic text to English after every
  // render. Arabic is the default and its path is untouched (L returns the
  // input and the observer early-exits), so nothing changes unless lang==='en'.
  function curLang() { try { return localStorage.getItem('xb.lang') === 'en' ? 'en' : 'ar'; } catch (e) { return 'ar'; } }
  // Short units / single standalone labels: translated ONLY when a text node
  // equals the key exactly, so they never corrupt a substring of other words.
  var EXACT = {
    'جم': 'g', 'مل': 'ml', 'ث': 's', '°م': '°C', '°ف': '°F', 'جرام': 'Grams',
    'وسط': 'Center', 'حلزوني': 'Spiral', 'دائري': 'Circular',
    'نعم': 'Yes', 'لا': 'No', 'صوت': 'Sound', 'صامت': 'Silent', 'آخر': 'Other'
  };
  // Multi-character phrases, safe to replace anywhere (applied longest-first).
  var DICT = {
    // header / tabs / status
    'الوصفات': 'Recipes', 'وصفة جديدة': 'New recipe', 'الشرح': 'Guide', 'الإعدادات': 'Settings',
    'غير متصل': 'Offline', 'الماء تمام': 'Water OK', 'الماء ناقص': 'Low water', 'الماء —': 'Water —',
    'متصل': 'Connected', 'يتصل بالمكينة…': 'Connecting to machine…', 'يتصل…': 'Connecting…',
    'جاري الاتصال…': 'Connecting…', 'يدوّر…': 'Scanning…',
    // cup type / drink / sections
    'شاي': 'Tea', 'قهوة': 'Coffee',
    // phases
    'نجهّز الوصفة…': 'Preparing the recipe…', 'يطحن البن': 'Grinding the beans', 'يصب الماء': 'Pouring water',
    'متوقف مؤقتاً': 'Paused', 'قهوتك جاهزة': 'Your coffee is ready', 'تم الإيقاف': 'Stopped', 'ما اكتمل التحضير': "Brew didn't finish",
    // reasons / faults
    'الماء ناقص — عبّ الخزان': 'Low water — fill the tank',
    'رجّع المكينة للشاشة الرئيسية وحاول مرة ثانية': 'Return the machine to its home screen and try again',
    'المكينة مو جاهزة — طفّها وشغّلها': 'Machine not ready — turn it off and on',
    'المكينة رفضت الوصفة — راجع كمية الماء والدفعات': 'Machine rejected the recipe — check the water and pours',
    'المكينة مشغولة، انتظر شوي': 'Machine is busy, wait a moment',
    'المكينة ما ردّت — تأكد إنها شغالة وقريبة': "No reply — make sure it's on and nearby",
    'مو متصل بالمكينة': 'Not connected to the machine', 'ما فيه بن في المطحنة': 'No beans in the grinder',
    'المكينة رفضت الأمر': 'Machine refused the command', 'خطأ في كمية البن أو الماء': 'Error in coffee or water amount',
    'خطأ في وضع المطحنة': 'Grinder position error',
    // brew center / labels
    'يرسل الوصفة': 'Sending recipe', 'يطحن': 'Grinding', ' من ': ' of ',
    'التشريب (دفعة 1)': 'Bloom (pour 1)', 'تشريب': 'Bloom',
    'دفعات': 'pours', 'دفعة ': 'Pour ', 'دفعة': 'pour', 'نقعة ': 'Steep ', 'نقعة': 'steep', 'صبّات': 'pours',
    'الوقت': 'Time', 'جرام في الكوب': 'Grams in cup',
    'جم شاي': 'g tea', 'جم بن': 'g coffee', 'مل ماء': 'ml water', 'جم ·': 'g ·',
    'نقعات': 'steeps', 'الحرارة': 'Temp', 'النسبة': 'Ratio', 'الطحنة': 'Grind',
    // OTA
    'تحديث جديد متوفر': 'Update available', ' · تحديث النظام': ' · System update', ' (تحديث النظام)': ' (system update)',
    'تحديث النظام': 'System update', 'تحديث الآن': 'Update now', 'لاحقًا': 'Later',
    'يُنزّل تحديث النظام…': 'Downloading system update…', 'يُحدّث الآن…': 'Updating now…',
    'بعد التنزيل اضغط «تثبيت»': 'After the download, tap «Install»', 'لا تطفئ الشاشة': "Don't turn off the screen",
    'تعذّر بدء التحديث': "Couldn't start the update", 'جاهز للتثبيت': 'Ready to install',
    'اضغط «تثبيت» في نافذة النظام': 'Tap «Install» in the system dialog',
    'ما قدرنا نتحقق — تأكد من الإنترنت': "Couldn't check — check your internet",
    'ما نجح التحديث — جرّب لاحقًا': 'Update failed — try again later', 'تحديث ': 'Update ',
    'التحديثات': 'Updates', 'التحديث التلقائي يشتغل على شاشة الساقي.': 'Automatic updates run on the Al-Saqi screen.',
    'إصدار الواجهة: ': 'Interface version: ', 'يتوفر تحديث: ': 'Update available: ',
    'تحقق': 'Check', 'أنت على آخر إصدار.': "You're on the latest version.", 'التحقق من التحديثات': 'Check for updates',
    'نتحقق من التحديثات…': 'Checking for updates…',
    // default recipe names / dup
    'تحميص فاتح': 'Light roast', 'تحميص متوسط': 'Medium roast', 'تحميص غامق': 'Dark roast', 'كوب كبير': 'Large cup',
    ' (نسخة)': ' (copy)', 'ما قدرت أحفظ': "Couldn't save",
    // library
    'مكتبة الوصفات': 'Recipe library', 'وصفات جاهزة — أضفها لوصفاتك وعدّلها زي ما تحب.': 'Ready-made recipes — add them to yours and tweak freely.',
    'V60 كلاسيك': 'V60 Classic', 'نظيفة ومتوازنة': 'Clean and balanced',
    'هوفمان كوب واحد': 'Hoffmann one cup', 'حلاوة أعلى، ٤ صبّات': 'Sweeter, 4 pours',
    'فاتح مشرق': 'Bright light', 'حموضة وفواكه': 'Acidity and fruit',
    'غامق ناعم': 'Smooth dark', 'جسم أثقل، أقل حموضة': 'Heavier body, less acidity',
    'قهوة مثلّجة': 'Iced coffee', 'تُصبّ على ثلج': 'Poured over ice',
    'كوب مزدوج': 'Double cup', 'كوبين، كمية أكبر': 'Two cups, larger amount',
    'شاي أخضر': 'Green tea', 'حرارة ٨٠° · نقعة واحدة': '80° · one steep',
    'شاي أسود': 'Black tea', 'حرارة ٩٥° · نقعة واحدة': '95° · one steep',
    'أولونغ': 'Oolong', 'حرارة ٩٠° · نقعتين': '90° · two steeps',
    'أعشاب/كركديه': 'Herbal / Hibiscus', 'حرارة ٩٨° · نقعة واحدة': '98° · one steep', 'أضف': 'Add',
    // home
    'ما فيه وصفات للحين.': 'No recipes yet.', ' أضف أول وصفة': ' Add your first recipe',
    'مفضلة': 'Favorite', 'تعديل': 'Edit', 'نسخ': 'Copy', 'شارك': 'Share', 'زر بالمكينة': 'Machine button', 'حذف': 'Delete',
    'وصفاتك': 'Your recipes', ' المكتبة': ' Library', ' استلام وصفة': ' Receive recipe',
    // brew button
    'الوصفة تحتاج تعديل': 'Recipe needs editing', 'حضّر الحين': 'Brew now',
    'المكينة مو متصلة — اضغط هنا': 'Machine offline — tap here',
    // editor
    'نوع المشروب': 'Drink type', 'اسم الوصفة': 'Recipe name', 'حفظ': 'Save', 'إلغاء': 'Cancel',
    'الشاي': 'Tea', 'البن': 'Beans', 'نوع الكوب': 'Cup type', 'كمية الشاي (أوراق)': 'Tea amount (leaves)', 'كمية البن': 'Coffee amount',
    'المطحنة': 'Grinder', 'تطحن': 'Grind', 'بن مطحون': 'Pre-ground', 'درجة الطحن (أقل = أنعم)': 'Grind size (lower = finer)', 'سرعة المطحنة': 'Grinder speed',
    'كل نقعة تُصبّ ماء على الأوراق في مصفاة الشاي.': 'Each steep pours water over the leaves in the tea strainer.',
    'وزّع الماء تلقائياً:': 'Auto-distribute water:',
    'ماء النقعة': 'Steep water', 'الماء': 'Water', 'انتظار بين النقعات': 'Wait between steeps', 'انتظار بعدها': 'Wait after',
    'سرعة الصب': 'Flow rate', 'طريقة الصب': 'Pour pattern', 'هز قبل': 'Agitate before', 'هز بعد': 'Agitate after',
    // errors
    'كمية البن خارج حدود الكوب': 'Coffee amount out of cup range', 'النسبة لازم بين 1:5 و 1:25': 'Ratio must be between 1:5 and 1:25',
    'ما فيه ماء': 'No water', 'إعدادات المطحنة': 'Grinder settings',
    // welcome
    'قهوتك المختصة، بضغطة زر': 'Your specialty coffee, one tap away', 'ابدأ': 'Start',
    'أول مرة؟ بنربط الشاشة بمكينتك بخطوات بسيطة': "First time? We'll pair the screen with your machine in a few steps",
    'المكينة جاهزة': 'Machine ready', 'نتصل بالمكينة…': 'Connecting to machine…', 'المكينة غير متصلة': 'Machine offline',
    'خزان الماء ناقص — عبّه قبل التحضير': 'Water tank low — fill it before brewing',
    // setup
    'رجوع': 'Back', 'أهلاً بك': 'Welcome', 'خطوات بسيطة ونربط الشاشة بمكينتك': 'A few simple steps to pair the screen with your machine',
    '١. جهاز الجسر (ESP32)': '1. Bridge device (ESP32)',
    'هذي الشاشة ما فيها بلوتوث، فتكلّم المكينة عن طريق قطعة ESP32 صغيرة.': 'This screen has no Bluetooth, so it talks to the machine through a small ESP32 device.',
    'واي فاي الشاشة: ': 'Screen Wi-Fi: ', 'إعدادات الواي فاي': 'Wi-Fi settings',
    'وصّل القطعة بالكهرباء قريب من المكينة.': 'Plug the device into power near the machine.',
    'من جوالك ادخل شبكة الواي فاي ': 'From your phone, join the Wi-Fi network ', ' — تطلع صفحة.': ' — a page appears.',
    'اختر فيها شبكة البيت (نفس شبكة الشاشة) واكتب كلمة السر.': 'Pick your home network (same as the screen) and enter the password.',
    'ارجع هنا واضغط "دوّر على الجسر".': 'Come back here and tap "Find the bridge".',
    'دوّر على الجسر': 'Find the bridge',
    'لقيت أكثر من جسر — اختر اللي رقمه مكتوب على صفحة الإعداد في جوالك:': 'Found more than one bridge — pick the one whose number is shown on the setup page on your phone:',
    'جسر ': 'Bridge ', 'ما لقيته؟ اكتب عنوانه': "Didn't find it? Enter its address", 'مثل 192.168.1.50': 'e.g. 192.168.1.50', 'اتصل': 'Connect',
    'هذي الشاشة ما فيها بلوتوث — تحتاج جسر ESP32.': 'This screen has no Bluetooth — it needs an ESP32 bridge.',
    'البلوتوث مقفل — شغّله من إعدادات أندرويد.': 'Bluetooth is off — turn it on in Android settings.',
    'التطبيق يحتاج صلاحية الموقع/البلوتوث عشان يدوّر على المكينة.': 'The app needs location/Bluetooth permission to find the machine.',
    '٢. اختر مكينتك': '2. Pick your machine', '١. اختر مكينتك': '1. Pick your machine',
    'شغّل المكينة، وسكّر تطبيق xBloom في الجوال (المكينة تقبل اتصال واحد بس).': 'Turn on the machine and close the xBloom app on your phone (the machine accepts only one connection).',
    'رقم مكينتك: آخر ٦ حروف من الرقم التسلسلي — مكتوب تحت المكينة، وتلقاه في تطبيق xBloom.': 'Your machine number: the last 6 characters of the serial — printed under the machine and shown in the xBloom app.',
    'دوّر': 'Scan', 'تم الربط': 'Paired', 'الشاشة مربوطة بمكينة ': 'The screen is paired with machine ', 'يلا نحضّر': "Let's brew",
    'أدوّر على المكاين القريبة…': 'Scanning for nearby machines…', 'ما فيه مكينة بهذا الرقم قريبة.': 'No machine with that number nearby.', 'اضغط "دوّر".': 'Tap "Scan".',
    // settings
    'الإحصائيات': 'Statistics', 'أكواب اليوم': 'Cups today', 'الإجمالي': 'Total',
    'الحماية والتنبيهات': 'Protection & alerts', 'قفل الإعدادات برقم سري': 'Lock settings with a PIN',
    'تغيير الرقم': 'Change PIN', 'إزالة القفل': 'Remove lock', 'تعيين رقم سري': 'Set a PIN', 'صوت التنبيه عند الانتهاء': 'Alert sound when done',
    'جهاز الجسر (ESP32)': 'Bridge device (ESP32)', 'الجسر: ': 'Bridge: ', 'أو اكتب عنوانه، مثل 192.168.8.50': 'Or enter its address, e.g. 192.168.8.50',
    'الاتصال بالمكينة': 'Machine connection', 'هذي الشاشة ما فيها بلوتوث شغّال.': 'This screen has no working Bluetooth.',
    'ما وصلت لجهاز الجسر (ESP32) — تأكد إنه موصول بالكهرباء وعلى نفس شبكة الواي فاي.': "Couldn't reach the bridge (ESP32) — make sure it's plugged in and on the same Wi-Fi.",
    'المكينة: ': 'Machine: ', 'قطع الاتصال': 'Disconnect', 'دوّر على المكينة': 'Scan for the machine', 'ربط مكينة ثانية': 'Pair another machine',
    'المكينة تقبل اتصال واحد بس. إذا تبي تستخدم تطبيق الجوال، اقطع الاتصال من هنا أول.': 'The machine accepts only one connection. To use the phone app, disconnect here first.',
    'إعدادات المكينة': 'Machine settings', 'مصدر الماء': 'Water source', 'الخزان': 'Tank', 'الحنفية': 'Tap',
    'الوضع': 'Mode', 'وحدة الوزن': 'Weight unit', 'أونصة': 'Ounce', 'وحدة الحرارة': 'Temp unit', 'تصفير الميزان': 'Tare the scale',
    'الرقم التسلسلي: ': 'Serial: ', 'النسخة: ': 'Firmware: ', 'اللغة': 'Language',
    // guide
    'قبل ما نبدأ 👋': "Before we start 👋",
    'هذي طريقة تحضير القهوة بالمكينة خطوة بخطوة. تقدر ترجع لها أي وقت من تبويب «الشرح».': 'This is how to brew coffee step by step. You can come back to it any time from the «Guide» tab.',
    'فهمت، يلا نبدأ': "Got it, let's start", 'تخطّي': 'Skip',
    'كيف تسوّي قهوتك': 'How to make your coffee', 'خطوة بخطوة': 'Step by step', 'تلميحات': 'Tips',
    'حطّ الفلتر ورطّبه': 'Place the filter and rinse it',
    'حطّ فلتر الورق في القمع، وصبّ عليه ماء حار يبلّله كله. هذا يشيل طعم الورق ويسخّن الكوب. كبّ الماء اللي تجمّع تحت.': 'Put the paper filter in the dripper and pour hot water to wet it fully. This removes the paper taste and warms the cup. Discard the water collected below.',
    'وزن البن': 'Weigh the coffee',
    'لو تطحن في المكينة: حطّ حبّ البن في فتحة الطحن. لو عندك بن مطحون جاهز: حطّه مباشرة في الفلتر، واختر «بن مطحون» في الوصفة.': "If you grind in the machine: put the beans in the grinder opening. If you have pre-ground coffee: put it straight in the filter and pick «Pre-ground» in the recipe.",
    'الماء والكوب': 'Water and cup',
    'تأكّد إن خزان الماء مليان (تشوف حالته فوق في الشاشة). وحطّ الكوب تحت القمع على الميزان.': 'Make sure the water tank is full (its status shows at the top of the screen). Put the cup under the dripper on the scale.',
    'اختر الوصفة': 'Pick the recipe',
    'من «الوصفات» اختر وصفتك، وتشوف تفاصيلها: كمية البن، النسبة، الحرارة، وكل دفعة.': 'From «Recipes» pick your recipe and see its details: coffee amount, ratio, temperature and each pour.',
    'اضغط «حضّر الحين»': 'Tap «Brew now»',
    'المكينة تطحن (لو مفعّل الطحن)، وبعدها تصبّ الماء على دفعات. تابع الدائرة والوقت والوزن في الشاشة.': 'The machine grinds (if grinding is on), then pours water in stages. Follow the ring, the time and the weight on screen.',
    'أول ما تخلص تطلع «قهوتك جاهزة». اضغط «تمام» وارجع للوصفات. بالهناء ☕': 'When it finishes you see «Your coffee is ready». Tap «Done» and go back to the recipes. Enjoy ☕',
    'لإنشاء وصفة جديدة: بوّب «وصفة جديدة» وعدّل كمية البن والنسبة وكل دفعة.': 'To create a new recipe: open «New recipe» and adjust the coffee amount, the ratio and each pour.',
    'لحفظ وصفة في أزرار المكينة A/B/C: افتح الوصفة واضغط «زر بالمكينة».': 'To save a recipe to the machine buttons A/B/C: open the recipe and tap «Machine button».',
    'لو المكينة «غير متصلة»: تأكد إنها مشغّلة وقريبة، واقفل تطبيق xBloom في جوالك (تقبل اتصال واحد بس).': 'If the machine is «Offline»: make sure it is on and nearby, and close the xBloom app on your phone (it accepts only one connection).',
    // diag
    'تشخيص (أرقام المكينة الخام)': 'Diagnostics (raw machine numbers)',
    'سوِّ تحضير والأرقام تتعبّى هنا. العمود الأول القيمة كفلوت، والثاني كعدد صحيح.': 'Run a brew and the numbers fill in here. The first column is the float value, the second is the integer.',
    'النوع': 'Type', 'ماء': 'Water', 'وزن': 'Weight', 'تحديث': 'Refresh',
    // share / receive
    'شارك «': 'Share «', 'وجّه كاميرا جهاز ثاني (يشغّل الساقي) على الباركود، واضغط «استلام وصفة» فيه.': 'Point another device (running Al-Saqi) camera at the barcode and tap «Receive recipe» on it.',
    'تعذّر إنشاء الباركود': "Couldn't create the barcode", 'استلام وصفة': 'Receive recipe',
    'وجّه الكاميرا على باركود الوصفة…': 'Point the camera at the recipe barcode…',
    'ما سمحت للكاميرا. فعّلها من إعدادات التطبيق وحاول ثانية.': "Camera wasn't allowed. Enable it in the app settings and try again.",
    'ما فيه كاميرا تشتغل على هذا الجهاز.': 'No working camera on this device.', 'انحفظت وصفة «': 'Saved recipe «',
    // toasts / confirms / prompts
    'انشال القفل': 'Lock removed', 'تم تعيين الرقم السري': 'PIN set', 'رقم غلط': 'Wrong PIN', 'الرقمان ما تطابقا': "The two PINs didn't match",
    'إزالة القفل عن الإعدادات؟': 'Remove the settings lock?', 'أضفنا «': 'Added «',
    'اكتب اسم للوصفة': 'Enter a recipe name', 'انحفظت': 'Saved', 'الوصفة فيها مشكلة — عدّلها أول': 'The recipe has a problem — edit it first',
    'أي زر بالمكينة؟ اكتب A أو B أو C': 'Which machine button? Enter A, B or C', 'اكتب A أو B أو C': 'Enter A, B or C',
    'انحفظت في زر ': 'Saved to button ', ' — تقدر تشغلها من المكينة بوضع Auto': ' — you can run it from the machine in Auto mode',
    'توقف التحضير؟': 'Stop brewing?', 'تحذف "': 'Delete "', '"؟': '"?', 'تربط الشاشة بمكينة ثانية؟': 'Pair the screen with another machine?',
    'أدوّر على الجسر…': 'Looking for the bridge…', 'لقيت الجسر ': 'Found bridge ', 'لقيت ': 'Found ', ' — اختر جسرك': ' — pick your bridge',
    'ما لقيته — تأكد إنه على نفس الشبكة': "Didn't find it — make sure it's on the same network", 'أتصل بالجسر…': 'Connecting to the bridge…',
    'ما قدرت أتصل — قرّب الشاشة/الجسر من المكينة وجرّب ثانية': "Couldn't connect — move the screen/bridge closer to the machine and try again",
    'اتصلت بالمكينة': 'Connected to the machine', 'الجسر مو متصل': 'Bridge not connected', 'البلوتوث مو جاهز': 'Bluetooth not ready',
    'تم تصفير الميزان': 'Scale tared', 'صار خطأ': 'An error occurred', 'إعدادات أندرويد (على الشاشة فقط)': 'Android settings (on the screen only)',
    // PIN lock
    'الإعدادات مقفلة': 'Settings locked', 'أعد كتابة الرقم': 'Re-enter the PIN', 'اختر رقمًا سريًا': 'Choose a PIN',
    'ادخل الرقم السري لفتح الإعدادات': 'Enter the PIN to open settings', 'أربعة أرقام': 'Four digits',
    // brew controls, units, punctuation, misc
    'تمام': 'Done', 'كمّل': 'Resume', 'إيقاف مؤقت': 'Pause', 'مل/ث': 'ml/s', '، ': ', ', '→ رجوع': '← Back',
    'وصفة مشاركة': 'Shared recipe', 'الوصفة كبيرة على الباركود': 'The recipe is too big for a barcode',
    // update errors
    'تاريخ ووقت الشاشة غلط — عدّلهم من إعدادات أندرويد': "The screen's date and time are wrong — fix them in Android settings",
    'مشكلة في شهادة الأمان مع سيرفر التحديثات': 'Security certificate problem with the update server',
    'ما فيه إنترنت — تأكد إن الواي فاي متصل بالنت': 'No internet — make sure the Wi-Fi has internet access',
    'ما لقينا التحديث على السيرفر': "Couldn't find the update on the server",
    'ملف التحديث وصل ناقص — جرّب مرة ثانية': 'The update file arrived incomplete — try again',
    'ما قدرنا نتحقق من التحديثات': "Couldn't check for updates"
  };
  var PH = null;
  function phrases() {
    if (PH) return PH;
    PH = []; for (var k in DICT) if (DICT.hasOwnProperty(k)) PH.push([k, DICT[k]]);
    PH.sort(function (a, b) { return b[0].length - a[0].length; });
    return PH;
  }
  // Translate a string built in code (toast / confirm / prompt / brew bits).
  function L(s) {
    if (curLang() !== 'en' || s == null) return s;
    s = String(s);
    if (EXACT.hasOwnProperty(s)) return EXACT[s];
    var out = s, p = phrases();
    for (var i = 0; i < p.length; i++) if (out.indexOf(p[i][0]) >= 0) out = out.split(p[i][0]).join(p[i][1]);
    return out;
  }
  var AR_RE = /[؀-ۿ]/;
  function trTextNode(t) {
    var v = t.nodeValue;
    if (!v || !AR_RE.test(v)) return;
    var nv = EXACT.hasOwnProperty(v) ? EXACT[v] : L(v);
    if (nv !== v) t.nodeValue = nv;
  }
  // Rewrite all Arabic text (and Arabic placeholders) under a node to English.
  function translateTree(root) {
    if (curLang() !== 'en' || !root || !root.querySelectorAll) return;
    try {
      var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false), n, list = [];
      while ((n = w.nextNode())) list.push(n);
      for (var i = 0; i < list.length; i++) trTextNode(list[i]);
      Array.prototype.forEach.call(root.querySelectorAll('[placeholder]'), function (el) {
        var v = el.getAttribute('placeholder'); if (v && AR_RE.test(v)) el.setAttribute('placeholder', L(v));
      });
    } catch (e) { /* */ }
  }
  function applyLangChrome() {
    var en = curLang() === 'en';
    try {
      document.documentElement.setAttribute('lang', en ? 'en' : 'ar');
      document.documentElement.setAttribute('dir', en ? 'ltr' : 'rtl');
      document.documentElement.className = en ? 'lang-en' : '';
    } catch (e) { /* */ }
  }
  var langObs = null;
  // Whole body: the view, the header, the tabs and the update banner (#ota).
  function observeLang() {
    if (langObs) langObs.observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  // Static HTML (the tab labels) is never re-rendered, so keep its Arabic to
  // put back when switching from English to Arabic.
  function markStatic() {
    Array.prototype.forEach.call(document.querySelectorAll('.tabs button > span:last-child'), function (s) {
      if (!s.getAttribute('data-ar')) s.setAttribute('data-ar', s.textContent);
    });
  }
  function restoreStatic() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-ar]'), function (el) { el.textContent = el.getAttribute('data-ar'); });
  }
  function startLangObserver() {
    markStatic();
    applyLangChrome();
    if (langObs || !window.MutationObserver) return;
    langObs = new MutationObserver(function (muts) {
      if (curLang() !== 'en') return;
      langObs.disconnect();
      for (var i = 0; i < muts.length; i++) {
        var mm = muts[i];
        if (mm.type === 'characterData') { if (mm.target && mm.target.nodeType === 3) trTextNode(mm.target); }
        else for (var j = 0; j < mm.addedNodes.length; j++) {
          var a = mm.addedNodes[j];
          if (a.nodeType === 3) trTextNode(a);
          else if (a.nodeType === 1) translateTree(a);
        }
      }
      observeLang();
    });
    observeLang();
  }
  function setLang(l) {
    try { localStorage.setItem('xb.lang', l === 'en' ? 'en' : 'ar'); } catch (e) { /* */ }
    applyLangChrome();
    restoreStatic();
    renderBar(); render(); OTA.refresh();
    translateTree(document.body);
  }

  // Line icons, 24x24, drawn in the current text colour.
  var ICONS = {
    cup: '<path d="M4 9h13v4a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z"/><path d="M17 10.5h1.5a2.5 2.5 0 0 1 0 5H17"/><path d="M8 3.5c0 1 1 1.3 1 2.5M12 3.5c0 1 1 1.3 1 2.5"/><path d="M5 21h11"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    sliders: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13 7l4 4"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="3"/><path d="M16 4H7a3 3 0 0 0-3 3v9"/>',
    slot: '<path d="M12 4v10M7.5 9.5L12 14l4.5-4.5"/><path d="M5 15v2a3 3 0 0 0 3 3h8a3 3 0 0 0 3-3v-2"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M9 7V4.5h6V7M6 7l1 13h10l1-13"/>',
    drop: '<path d="M12 3.5s6 6.8 6 10.8a6 6 0 0 1-12 0C6 10.3 12 3.5 12 3.5z"/>',
    scale: '<rect x="3.5" y="10" width="17" height="10" rx="3"/><path d="M8 10a4 4 0 0 1 8 0"/><path d="M12 13.5v2"/>',
    play: '<path d="M8 5.5v13l11-6.5z"/>',
    pause: '<path d="M9 6v12M15 6v12"/>',
    stop: '<rect x="6.5" y="6.5" width="11" height="11" rx="2"/>',
    check: '<circle cx="12" cy="12" r="9.5"/><path d="M7.5 12.5l3 3 6-6.5"/>',
    wifi: '<path d="M3.5 9.5a12 12 0 0 1 17 0M6.5 12.5a8 8 0 0 1 11 0M9.5 15.5a4 4 0 0 1 5 0"/><circle cx="12" cy="18.5" r="1"/>',
    alert: '<path d="M12 4L2.8 19.5h18.4z"/><path d="M12 10v4.5M12 17v.01"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    book: '<path d="M5 4h9a2 2 0 0 1 2 2v14H7a2 2 0 0 0-2 2z"/><path d="M19 4v16"/><path d="M9 8h4M9 11h4"/>',
    filter: '<path d="M6 5h12l-4.5 6v6l-3 1.5v-7.5z"/>',
    beans: '<ellipse cx="9.5" cy="10" rx="4" ry="5.5" transform="rotate(-25 9.5 10)"/><path d="M8 6.5c1.5 1.5 1.5 5.5 0 7"/><ellipse cx="15" cy="14.5" rx="3.5" ry="5" transform="rotate(-25 15 14.5)"/>',
    tap: '<path d="M9 11.5V6a3 3 0 0 1 6 0v.5"/><rect x="5.5" y="11.5" width="13" height="4" rx="1.5"/><path d="M9 15.5v2a3 3 0 0 0 6 0v-2"/><circle cx="12" cy="21" r="0.8"/>',
    pour: '<path d="M4 7h10v3a5 5 0 0 1-10 0z"/><path d="M14 8h3l2 3-2 1"/><path d="M8 15v3M11 15v4"/>',
    share: '<rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><path d="M14 14h2v2M18 14v0M14 18h0M18 18h2v-2M16 20h0"/>',
    scan: '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M4 12h16"/>',
    download: '<path d="M12 4v10"/><path d="M8 10l4 4 4-4"/><path d="M5 18h14"/>'
  };
  function icon(name) {
    return '<span class="ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round">' + (ICONS[name] || '') + '</svg></span>';
  }
  function pourLabel(r, i) { return i === 0 && r.pours.length > 1 ? 'تشريب' : 'دفعة ' + (i + 1); }

  var toastTimer;
  function toast(msg, bad) {
    var t = document.getElementById('toast');
    t.textContent = L(msg); t.className = 'show' + (bad ? ' bad' : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.className = ''; }, 3500);
  }

  // ------------------------------------------------------------- OTA updates
  // The screen checks a fixed server for a newer web layer (or, rarely, a new
  // APK) through the native XBOTA bridge. Updates are OPT-IN: a banner shows
  // what is new with «تحديث الآن» / «لاحقًا», and Settings always has an entry
  // to update later. The native side downloads, verifies and swaps; this just
  // decides what to offer and shows progress.
  var WEB_VERSION = 1; // fallback shown in a plain browser (no native bridge)
  var OTA = (function () {
    var bridge = window.XBOTA || null;
    var manifest = null, pending = null, dismissed = false, busy = false, lastPct = 0, manual = false, lastErr = '';

    // Say what actually went wrong, from the native exception text — "check
    // the internet" is wrong when the real cause is the clock or a certificate.
    function reasonOf(msg, stage) {
      var m = String(msg || '');
      if (/not yet valid|expired|timestamp check failed/i.test(m)) return 'تاريخ ووقت الشاشة غلط — عدّلهم من إعدادات أندرويد';
      if (/trust anchor|certif|SSL|handshake/i.test(m)) return 'مشكلة في شهادة الأمان مع سيرفر التحديثات';
      if (/UnknownHost|resolve host|ConnectException|timed? ?out|unreachable|ENETUNREACH|No route/i.test(m)) return 'ما فيه إنترنت — تأكد إن الواي فاي متصل بالنت';
      if (/http 404/.test(m)) return 'ما لقينا التحديث على السيرفر';
      if (/checksum/.test(m)) return 'ملف التحديث وصل ناقص — جرّب مرة ثانية';
      return stage === 'check' ? 'ما قدرنا نتحقق من التحديثات' : 'ما نجح التحديث — جرّب لاحقًا';
    }

    function present() { return !!bridge; }
    function curWeb() { try { return bridge ? bridge.version() : WEB_VERSION; } catch (e) { return WEB_VERSION; } }
    function curApp() { try { return bridge ? bridge.appVersion() : 0; } catch (e) { return 0; } }
    // manual=true when the user tapped «تحقق» — then we report failures; the
    // automatic background check at startup stays silent (e.g. no internet yet).
    function check(isManual) { manual = !!isManual; if (bridge) { try { bridge.check(); } catch (e) { /* offline */ } } }

    // Prefer a web update (instant, silent swap); fall back to an APK update
    // (needs one tap from the user) only when the native version is behind.
    function decide() {
      if (!manifest) return null;
      var w = manifest.web, a = manifest.apk;
      if (w && typeof w.version === 'number' && w.version > curWeb() && w.url)
        return { kind: 'web', version: w.version, title: w.title || ('تحديث ' + w.version), notes: w.notes || [], url: w.url, sha256: w.sha256 || '' };
      if (a && typeof a.version === 'number' && a.version > curApp() && a.url)
        return { kind: 'apk', version: a.version, title: a.title || ('تحديث ' + a.version), notes: a.notes || [], url: a.url, sha256: a.sha256 || '' };
      return null;
    }

    function box() {
      var el = document.getElementById('ota');
      if (!el) { el = document.createElement('div'); el.id = 'ota'; document.body.appendChild(el); }
      return el;
    }
    function hide() { var el = box(); el.innerHTML = ''; el.className = ''; }

    function canShow() {
      return pending && !dismissed && !busy && view !== 'edit' && !(link && link.isBrewing && link.isBrewing());
    }

    function renderBanner() {
      if (busy) return; // the progress UI owns the box while applying
      if (!canShow()) { hide(); return; }
      var notes = (pending.notes || []).map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('');
      box().className = 'show';
      box().innerHTML = '<div class="ota-card"><div class="ota-h">' + icon('download') +
        '<div class="ota-t"><b>تحديث جديد متوفر</b><small>' + esc(pending.title) +
        (pending.kind === 'apk' ? ' · تحديث النظام' : '') + '</small></div>' +
        '<button class="ota-x" data-act="otalater">✕</button></div>' +
        (notes ? '<ul class="ota-notes">' + notes + '</ul>' : '') +
        '<div class="ota-btns"><button class="primary" data-act="otaapply">' + icon('download') + 'تحديث الآن</button>' +
        '<button class="ghost" data-act="otalater">لاحقًا</button></div></div>';
    }

    function renderProgress(pct, apk) {
      busy = true;
      box().className = 'show';
      box().innerHTML = '<div class="ota-card"><div class="ota-h">' + icon('download') +
        '<div class="ota-t"><b>' + (apk ? 'يُنزّل تحديث النظام…' : 'يُحدّث الآن…') + '</b>' +
        '<small>' + (apk ? 'بعد التنزيل اضغط «تثبيت»' : 'لا تطفئ الشاشة') + '</small></div></div>' +
        '<div class="ota-bar"><i style="width:' + Math.max(5, Math.min(100, pct)) + '%"></i></div></div>';
    }

    function apply() {
      if (!pending || !bridge) return;
      busy = true; lastPct = 5;
      renderProgress(5, pending.kind === 'apk');
      try {
        if (pending.kind === 'apk') bridge.applyApk(pending.url, pending.sha256);
        else bridge.applyWeb(pending.url, pending.sha256, pending.version);
      } catch (e) { busy = false; toast('تعذّر بدء التحديث', true); renderBanner(); }
    }

    function later() { dismissed = true; hide(); }

    function onEvent(ev, json) {
      var data = {};
      try { data = JSON.parse(json); } catch (e) { /* non-JSON */ }
      if (ev === 'manifest') {
        try { manifest = JSON.parse(json); } catch (e) { manifest = null; }
        lastErr = '';
        pending = decide();
        if (!busy) renderBanner();
        if (view === 'settings') renderSettings();
      } else if (ev === 'progress') {
        lastPct = typeof data.pct === 'number' ? data.pct : lastPct;
        renderProgress(lastPct, !!data.apk);
      } else if (ev === 'ready') {
        renderProgress(100, false); // web applied: native reloads the page next
      } else if (ev === 'apkready') {
        busy = false;
        box().className = 'show';
        box().innerHTML = '<div class="ota-card"><div class="ota-h">' + icon('download') +
          '<div class="ota-t"><b>جاهز للتثبيت</b><small>اضغط «تثبيت» في نافذة النظام</small></div></div></div>';
      } else if (ev === 'error') {
        busy = false;
        // Report only an apply failure, or a check the user asked for; a silent
        // background check that can't reach the server says nothing.
        lastErr = data.msg || '';
        if ((data.stage && data.stage !== 'check') || manual) toast(reasonOf(lastErr, data.stage), true);
        manual = false;
        if (view === 'settings') renderSettings();
        renderBanner();
      }
    }

    return {
      present: present, check: check, apply: apply, later: later, onEvent: onEvent,
      curWeb: curWeb, curApp: curApp, pending: function () { return pending; },
      lastError: function () { return lastErr; }, reason: reasonOf,
      refresh: function () { if (!busy) renderBanner(); },
      init: function () { if (bridge) check(); }
    };
  })();
  window.__ota = function (ev, json) { OTA.onEvent(ev, json); };

  // ------------------------------------------------------------- recipes
  function starter(name, dose, ratio, grind, temp, n) {
    return { id: 'r' + Math.random().toString(36).slice(2, 9), name: name, dose_g: dose, cup_type: 2,
      grinder_size: grind, grinder_size_enabled: 1, rpm: 90, pours: XB.autoPours(dose, ratio, n, temp) };
  }
  function loadRecipes() {
    try {
      var r = JSON.parse(localStorage.getItem('xb.recipes'));
      if (r && r.length) return r;
    } catch (e) { /* first run */ }
    return [
      starter('تحميص فاتح', 15, 16, 45, 94, 3),
      starter('تحميص متوسط', 15, 15.5, 55, 92, 3),
      starter('تحميص غامق', 15, 15, 62, 88, 3),
      starter('كوب كبير', 18, 16, 52, 92, 4)
    ];
  }
  var recipes = loadRecipes();
  function saveRecipes() {
    try { localStorage.setItem('xb.recipes', JSON.stringify(recipes)); } catch (e) { toast('ما قدرت أحفظ', true); }
  }
  function byId(id) { return recipes.filter(function (r) { return r.id === id; })[0]; }

  // ----------------------------------------------------- stats & library
  // How many cups the machine has made — total, and today — kept on the screen.
  function today() { var d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
  function cupStats() {
    var total = 0, day = 0;
    try { total = parseInt(localStorage.getItem('xb.cups.total') || '0', 10) || 0; } catch (e) { /* */ }
    try { var d = JSON.parse(localStorage.getItem('xb.cups.day') || '{}'); if (d.date === today()) day = d.n || 0; } catch (e) { /* */ }
    return { total: total, today: day };
  }
  function bumpCup() {
    try {
      localStorage.setItem('xb.cups.total', String((parseInt(localStorage.getItem('xb.cups.total') || '0', 10) || 0) + 1));
      var d = {}; try { d = JSON.parse(localStorage.getItem('xb.cups.day') || '{}'); } catch (e) { /* */ }
      if (d.date !== today()) d = { date: today(), n: 0 };
      d.n = (d.n || 0) + 1;
      localStorage.setItem('xb.cups.day', JSON.stringify(d));
    } catch (e) { /* storage off */ }
  }
  var countedBrewAt = 0; // so one finished brew is counted once

  // Whether this screen can scan a QR. Real camera detection isn't reliable
  // (the frame reports phantom cameras it can't actually use), so we go by how
  // it talks to the machine: through the bridge == a photo frame, no camera;
  // its own Bluetooth == a phone/POS-type device that has one. A desktop
  // browser (for testing) counts as having one.
  function hasCamera() {
    if (viaBridge) return false;
    return !!(navigator.mediaDevices || navigator.getUserMedia || navigator.webkitGetUserMedia);
  }

  // ------------------------------------------------- sound, PIN, alerts
  function soundOn() { try { return localStorage.getItem('xb.sound') !== '0'; } catch (e) { return true; } }
  function setSound(on) { try { localStorage.setItem('xb.sound', on ? '1' : '0'); } catch (e) { /* */ } }
  // A short two-note chime when the coffee is ready — no audio file needed.
  function chime() {
    if (!soundOn()) return;
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      var ac = new AC();
      [[880, 0], [1320, 0.16]].forEach(function (p) {
        var o = ac.createOscillator(), g = ac.createGain();
        o.type = 'sine'; o.frequency.value = p[0];
        o.connect(g); g.connect(ac.destination);
        var t = ac.currentTime + p[1];
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(0.35, t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
        o.start(t); o.stop(t + 0.37);
      });
      setTimeout(function () { try { ac.close(); } catch (e) { /* */ } }, 1200);
    } catch (e) { /* no audio */ }
  }

  // PIN lock for Settings, so staff/customers can't change machine settings.
  function pinSet() { try { return localStorage.getItem('xb.pin') || ''; } catch (e) { return ''; } }
  function hasPin() { return !!pinSet(); }
  function savePin(p) { try { localStorage.setItem('xb.pin', p); } catch (e) { /* */ } }
  function clearPin() { try { localStorage.removeItem('xb.pin'); } catch (e) { /* */ } }
  var settingsUnlocked = false, pinInput = '', pinMode = 'enter', pinFirst = '';

  function renderLock() {
    var title = pinMode === 'enter' ? 'الإعدادات مقفلة' : pinMode === 'confirm' ? 'أعد كتابة الرقم' : 'اختر رقمًا سريًا';
    var sub = pinMode === 'enter' ? 'ادخل الرقم السري لفتح الإعدادات' : 'أربعة أرقام';
    var dots = '';
    for (var i = 0; i < 4; i++) dots += '<i class="' + (i < pinInput.length ? 'on' : '') + '"></i>';
    var keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map(function (k) {
      var act = k === 'C' ? 'pinclear' : k === '⌫' ? 'pinback' : 'pinkey';
      return '<button class="keypad-k' + (k === 'C' || k === '⌫' ? ' aux' : '') + '" data-act="' + act + '" data-k="' + k + '">' + k + '</button>';
    }).join('');
    $view.innerHTML = '<div class="lock"><div class="lock-box">' +
      '<div class="lock-ic">' + icon('slot') + '</div><h2>' + title + '</h2><p class="hint">' + sub + '</p>' +
      '<div class="pin-dots">' + dots + '</div>' +
      '<div class="keypad">' + keys + '</div>' +
      '<button class="ghost" data-act="towelcome">رجوع</button></div></div>';
  }

  function pinDigit(k) {
    if (pinInput.length >= 4) return;
    pinInput += k;
    renderLock();
    if (pinInput.length === 4) setTimeout(pinSubmit, 120);
  }
  function pinSubmit() {
    var v = pinInput; pinInput = '';
    if (pinMode === 'enter') {
      if (v === pinSet()) { settingsUnlocked = true; go('settings'); }
      else { toast('رقم غلط', true); renderLock(); }
    } else if (pinMode === 'set') {
      pinFirst = v; pinMode = 'confirm'; renderLock();
    } else { // confirm
      if (v === pinFirst) { savePin(v); settingsUnlocked = true; toast('تم تعيين الرقم السري'); go('settings'); }
      else { toast('الرقمان ما تطابقا', true); pinMode = 'set'; renderLock(); }
    }
  }

  // A clear, actionable machine alert for the home/welcome screens, or null.
  function machineAlert() {
    var m = link.machine;
    if (m && m.waterEnough === false) return 'خزان الماء ناقص — عبّه قبل التحضير';
    return null;
  }

  function isTea(r) { return r && r.cup_type === 4; }

  // Ready-made recipes the user can add with one tap, then tweak freely.
  // Coffee entries carry a ratio + grind; tea entries steep leaves (no grind,
  // leaf grams, a temperature and one or more steeps).
  var LIBRARY = [
    { name: 'V60 كلاسيك', desc: 'نظيفة ومتوازنة', dose: 15, ratio: 16, grind: 50, temp: 93, n: 3 },
    { name: 'هوفمان كوب واحد', desc: 'حلاوة أعلى، ٤ صبّات', dose: 15, ratio: 16.6, grind: 55, temp: 94, n: 4 },
    { name: 'فاتح مشرق', desc: 'حموضة وفواكه', dose: 14, ratio: 16.5, grind: 45, temp: 95, n: 3 },
    { name: 'غامق ناعم', desc: 'جسم أثقل، أقل حموضة', dose: 16, ratio: 15, grind: 62, temp: 88, n: 3 },
    { name: 'قهوة مثلّجة', desc: 'تُصبّ على ثلج', dose: 18, ratio: 15, grind: 48, temp: 94, n: 3 },
    { name: 'كوب مزدوج', desc: 'كوبين، كمية أكبر', dose: 22, ratio: 16, grind: 55, temp: 92, n: 4 },
    { tea: true, name: 'شاي أخضر', desc: 'حرارة ٨٠° · نقعة واحدة', leaf: 4, temp: 80, vol: 150, n: 1 },
    { tea: true, name: 'شاي أسود', desc: 'حرارة ٩٥° · نقعة واحدة', leaf: 4, temp: 95, vol: 150, n: 1 },
    { tea: true, name: 'أولونغ', desc: 'حرارة ٩٠° · نقعتين', leaf: 5, temp: 90, vol: 140, n: 2 },
    { tea: true, name: 'أعشاب/كركديه', desc: 'حرارة ٩٨° · نقعة واحدة', leaf: 5, temp: 98, vol: 150, n: 1 }
  ];
  // Build a tea recipe: no grinding, leaves in the siphon brewer, each steep a pour.
  function teaRecipe(p) {
    var pours = [];
    for (var i = 0; i < p.n; i++) pours.push({
      volume_ml: p.vol, temperature_c: p.temp, pattern: 2, flow_rate: 3.0,
      pause_s: p.n > 1 ? 10 : 0, agitate_before: 2, agitate_after: 2
    });
    return { id: 'r' + Math.random().toString(36).slice(2, 9), name: p.name, dose_g: p.leaf,
      cup_type: 4, grinder_size: 0, grinder_size_enabled: 0, rpm: 90, pours: pours };
  }
  function renderLibrary() {
    function card(p, i) {
      var meta = p.tea
        ? p.leaf + ' جم شاي · ' + p.temp + '° · ' + p.n + ' نقعة'
        : p.dose + ' جم · 1:' + p.ratio + ' · ' + p.temp + '° · ' + p.n + ' صبّات';
      return '<div class="card libitem"><div class="libtext"><h4>' + (p.tea ? '🍵 ' : '') + esc(p.name) + '</h4>' +
        '<p>' + esc(p.desc) + '</p><div class="meta">' + meta + '</div></div>' +
        '<button class="primary" data-act="addlib" data-i="' + i + '">' + icon('plus') + 'أضف</button></div>';
    }
    var coffee = '', tea = '';
    LIBRARY.forEach(function (p, i) { if (p.tea) tea += card(p, i); else coffee += card(p, i); });
    $view.innerHTML = '<div class="library"><div class="section-title"><h3>مكتبة الوصفات</h3>' +
      '<button class="mini" data-act="go" data-view="home">رجوع</button></div>' +
      '<p class="hint">وصفات جاهزة — أضفها لوصفاتك وعدّلها زي ما تحب.</p>' +
      '<div class="section-title"><h3>قهوة</h3></div>' + coffee +
      '<div class="section-title"><h3>شاي 🍵</h3></div>' + tea + '</div>';
  }

  // Favorites first, then the most-used, so the kitchen's go-to recipes rise up.
  function orderedRecipes() {
    return recipes.slice().sort(function (a, b) {
      var f = (b.fav ? 1 : 0) - (a.fav ? 1 : 0);
      if (f) return f;
      return (b.uses || 0) - (a.uses || 0);
    });
  }

  // ---------------------------------------------------------------- views
  var view = 'home', selected = null, draft = null, lastSettingsKey = '';

  function go(v) {
    if (view === 'scan' && v !== 'scan') stopScan();
    view = v;
    Array.prototype.forEach.call(document.querySelectorAll('.tabs button'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-view') === v);
    });
    render();
    OTA.refresh();
  }

  // -------------------------------------------------------- share / receive
  // Show a recipe as a QR for another الساقي screen or phone to scan.
  var shareId = null;
  function renderShare() {
    var r = byId(shareId);
    if (!r) { go('home'); return; }
    $view.innerHTML = '<div class="share-view"><div class="section-title"><h3>شارك «' + esc(r.name) + '»</h3>' +
      '<button class="mini" data-act="go" data-view="home">رجوع</button></div>' +
      '<div class="card qr-card"><div id="qrbox"></div>' +
      '<p class="hint">وجّه كاميرا جهاز ثاني (يشغّل الساقي) على الباركود، واضغط «استلام وصفة» فيه.</p></div></div>';
    var ok = Share.renderQR(document.getElementById('qrbox'), r);
    if (!ok) toast('تعذّر إنشاء الباركود', true);
  }

  // Open the camera and scan a recipe QR.
  var scanStop = null;
  function renderScan() {
    $view.innerHTML = '<div class="scan-view"><div class="section-title"><h3>استلام وصفة</h3>' +
      '<button class="mini" data-act="scancancel">إلغاء</button></div>' +
      '<div class="card scan-card"><div class="scan-frame"><video id="scanvid" muted playsinline></video>' +
      '<canvas id="scancanvas" style="display:none"></canvas><div class="scan-reticle"></div></div>' +
      '<p class="hint" id="scanhint">وجّه الكاميرا على باركود الوصفة…</p></div></div>';
    var vid = document.getElementById('scanvid'), cv = document.getElementById('scancanvas');
    scanStop = Share.scan(vid, cv, function (recipe) {
      recipes.push(recipe); selected = recipe.id; saveRecipes();
      scanStop = null;
      toast('انحفظت وصفة «' + recipe.name + '»');
      go('home');
    }, function (reason) {
      var h = document.getElementById('scanhint');
      if (h) h.innerHTML = '<span class="warn">' + (reason === 'denied'
        ? 'ما سمحت للكاميرا. فعّلها من إعدادات التطبيق وحاول ثانية.'
        : 'ما فيه كاميرا تشتغل على هذا الجهاز.') + '</span>';
    });
  }
  function stopScan() { if (scanStop) { scanStop(); scanStop = null; } }

  // ------------------------------------------------------------- guide
  // Plain how-to for whoever uses the machine: the physical prep, then the app.
  function guideSeen() {
    try { return localStorage.getItem('xb.guideSeen') === '1'; } catch (e) { return false; }
  }
  function markGuideSeen() {
    try { localStorage.setItem('xb.guideSeen', '1'); } catch (e) { /* preview */ }
  }
  // Whether the guide is being shown as the first-run walkthrough (gets a Skip /
  // Start button) versus opened later from the tab (plain reference).
  var guideIntro = false, fromWelcome = false;
  function renderGuide() {
    var steps = [
      { ic: 'filter', t: 'حطّ الفلتر ورطّبه', d: 'حطّ فلتر الورق في القمع، وصبّ عليه ماء حار يبلّله كله. هذا يشيل طعم الورق ويسخّن الكوب. كبّ الماء اللي تجمّع تحت.' },
      { ic: 'beans', t: 'وزن البن', d: 'لو تطحن في المكينة: حطّ حبّ البن في فتحة الطحن. لو عندك بن مطحون جاهز: حطّه مباشرة في الفلتر، واختر «بن مطحون» في الوصفة.' },
      { ic: 'tap', t: 'الماء والكوب', d: 'تأكّد إن خزان الماء مليان (تشوف حالته فوق في الشاشة). وحطّ الكوب تحت القمع على الميزان.' },
      { ic: 'cup', t: 'اختر الوصفة', d: 'من «الوصفات» اختر وصفتك، وتشوف تفاصيلها: كمية البن، النسبة، الحرارة، وكل دفعة.' },
      { ic: 'play', t: 'اضغط «حضّر الحين»', d: 'المكينة تطحن (لو مفعّل الطحن)، وبعدها تصبّ الماء على دفعات. تابع الدائرة والوقت والوزن في الشاشة.' },
      { ic: 'check', t: 'قهوتك جاهزة', d: 'أول ما تخلص تطلع «قهوتك جاهزة». اضغط «تمام» وارجع للوصفات. بالهناء ☕' }
    ];
    var tips = [
      'لإنشاء وصفة جديدة: بوّب «وصفة جديدة» وعدّل كمية البن والنسبة وكل دفعة.',
      'لحفظ وصفة في أزرار المكينة A/B/C: افتح الوصفة واضغط «زر بالمكينة».',
      'لو المكينة «غير متصلة»: تأكد إنها مشغّلة وقريبة، واقفل تطبيق xBloom في جوالك (تقبل اتصال واحد بس).'
    ];
    var intro = guideIntro
      ? '<div class="guide-intro card"><h3>قبل ما نبدأ 👋</h3>' +
        '<p>هذي طريقة تحضير القهوة بالمكينة خطوة بخطوة. تقدر ترجع لها أي وقت من تبويب «الشرح».</p>' +
        '<button class="primary" data-act="guidedone">فهمت، يلا نبدأ</button>' +
        '<button class="ghost" data-act="guideskip">تخطّي</button></div>'
      : '';
    var html = '<div class="guide">' + intro +
      '<div class="section-title"><h3>كيف تسوّي قهوتك</h3><small>خطوة بخطوة</small></div>' +
      '<ol class="guide-steps">' + steps.map(function (st, i) {
        return '<li class="card"><div class="gnum">' + (i + 1) + '</div>' + icon(st.ic) +
          '<div class="gtext"><h4>' + st.t + '</h4><p>' + st.d + '</p></div></li>';
      }).join('') + '</ol>' +
      '<div class="section-title"><h3>تلميحات</h3></div>' +
      '<div class="card guide-tips"><ul>' + tips.map(function (t) { return '<li>' + t + '</li>'; }).join('') + '</ul></div>' +
      '</div>';
    $view.innerHTML = html;
  }

  function renderDiag() {
    var rows = (link.rawLog || []).slice().reverse().map(function (e) {
      var name = e.code === XB.NOTIFY.WATER ? 'ماء' : 'وزن';
      return '<tr><td>' + name + '</td><td dir=ltr>' + (e.f) + '</td><td dir=ltr>' + e.u + '</td><td dir=ltr style="font-size:12px">' + e.hex + '</td></tr>';
    }).join('');
    $view.innerHTML = '<div class="settings"><section class="card"><h4>تشخيص (أرقام المكينة الخام)</h4>' +
      '<p class="hint">سوِّ تحضير والأرقام تتعبّى هنا. العمود الأول القيمة كفلوت، والثاني كعدد صحيح.</p>' +
      '<div style="overflow:auto"><table style="width:100%;border-collapse:collapse;font-size:15px">' +
      '<tr style="color:#5F6782"><td>النوع</td><td>float</td><td>uint</td><td>hex</td></tr>' + rows + '</table></div>' +
      '<div class="row"><button data-act="go" data-view="home">رجوع</button>' +
      '<button data-act="diagrefresh">تحديث</button></div></section></div>';
  }

  function render() {
    if (view === 'diag') { document.body.className = ''; return renderDiag(); }
    if (view === 'guide') { document.body.className = ''; guideIntro = fromWelcome; return renderGuide(); }
    if (view === 'share') { document.body.className = ''; return renderShare(); }
    if (view === 'scan') { document.body.className = ''; return renderScan(); }
    if (view === 'library') { document.body.className = ''; return renderLibrary(); }
    if (view === 'lock') { document.body.className = ''; return renderLock(); }
    var brewing = link.isBrewing() || ['done', 'stopped', 'failed'].indexOf(link.brew.phase) >= 0;
    // A brew started from the machine's own button shows even over the welcome screen.
    if (view === 'welcome' && !brewing) {
      document.body.className = 'in-welcome';
      return renderWelcome();
    }
    document.body.className = view === 'setup' ? 'in-setup' : '';
    if (view === 'setup') return renderSetup();
    if (link.isBrewing() || ['done', 'stopped', 'failed'].indexOf(link.brew.phase) >= 0) return renderBrew();
    if (view === 'edit') return renderEdit();
    if (view === 'settings') return renderSettings();
    renderHome();
  }

  function grindText(r) { return r.grinder_size_enabled !== 0 && r.grinder_size > 0 ? String(r.grinder_size) : '—'; }

  // One bar per pour, as tall as its share of the water: the recipe's shape at a glance.
  function shape(r) {
    var max = 0;
    r.pours.forEach(function (p) { max = Math.max(max, p.volume_ml); });
    var bars = r.pours.map(function (p) {
      var h = max ? Math.max(10, Math.round(p.volume_ml / max * 84)) : 10;
      return '<div class="p"><div class="vol">' + fmt(p.volume_ml) + '</div><div class="bar-in" style="height:' + h + 'px"></div></div>';
    }).join('');
    var labels = r.pours.map(function (p, i) {
      return '<span>' + pourLabel(r, i) + '<br>' + p.temperature_c + '°' + (p.pause_s ? ' · ' + p.pause_s + L('ث') : '') + '</span>';
    }).join('');
    return '<div class="shape">' + bars + '</div><div class="shape-labels">' + labels + '</div>';
  }

  // What the big button says and does, so it never sits disabled without saying why.
  function brewButton(r) {
    if (XB.validate(r).length) return '<button class="cta offline" data-act="edit">' + icon('alert') + 'الوصفة تحتاج تعديل</button>';
    if (link.state === 'connected') return '<button class="cta primary" data-act="brew">' + icon('play') + 'حضّر الحين</button>';
    if (link.state === 'connecting') return '<button class="cta offline" disabled>يتصل بالمكينة…</button>';
    return '<button class="cta offline" data-act="go" data-view="settings">' + icon('link') + 'المكينة مو متصلة — اضغط هنا</button>';
  }

  function renderHome() {
    if (!selected || !byId(selected)) selected = recipes[0] && recipes[0].id;
    var sel = byId(selected), m = link.machine;
    if (!sel) {
      $view.innerHTML = '<div class="card empty"><p>ما فيه وصفات للحين.</p>' +
        '<button class="primary" data-act="new">' + icon('plus') + ' أضف أول وصفة</button></div>';
      return;
    }
    var hero = '<div class="card hero"><div class="hero-top"><h2>' + esc(sel.name) + '</h2>' +
      '<span class="tag">' + esc(CUP_AR[sel.cup_type] || '') + '</span></div>' +
      '<div class="stats">' +
      (isTea(sel)
        ? '<div class="stat"><b>' + fmt(sel.dose_g, 1) + '</b><small>جم شاي</small></div>' +
          '<div class="stat"><b>' + sel.pours.length + '</b><small>نقعات</small></div>' +
          '<div class="stat"><b>' + fmt(XB.totalWater(sel)) + '</b><small>مل ماء</small></div>' +
          '<div class="stat"><b>' + (sel.pours[0] ? sel.pours[0].temperature_c + '°' : '—') + '</b><small>الحرارة</small></div>'
        : '<div class="stat"><b>' + fmt(sel.dose_g, 1) + '</b><small>جم بن</small></div>' +
          '<div class="stat"><b>1:' + fmt(ratioOf(sel), 1) + '</b><small>النسبة</small></div>' +
          '<div class="stat"><b>' + fmt(XB.totalWater(sel)) + '</b><small>مل ماء</small></div>' +
          '<div class="stat"><b>' + grindText(sel) + '</b><small>الطحنة</small></div>') + '</div>' +
      shape(sel) +
      (m.waterEnough === false ? '<div class="notice warn">' + icon('drop') + 'خزان الماء ناقص — عبّه قبل التحضير</div>' : '') +
      brewButton(sel) +
      '<div class="actions">' +
      '<button class="fav' + (sel.fav ? ' on' : '') + '" data-act="fav"><span class="star">' + (sel.fav ? '★' : '☆') + '</span>مفضلة</button>' +
      '<button data-act="edit">' + icon('edit') + 'تعديل</button>' +
      '<button data-act="dup">' + icon('copy') + 'نسخ</button>' +
      '<button data-act="share">' + icon('share') + 'شارك</button>' +
      '<button data-act="slot">' + icon('slot') + 'زر بالمكينة</button>' +
      '<button class="danger" data-act="del">' + icon('trash') + 'حذف</button></div></div>';
    var cards = orderedRecipes().map(function (r) {
      var max = 0;
      r.pours.forEach(function (p) { max = Math.max(max, p.volume_ml); });
      var mini = r.pours.map(function (p) { return '<i style="height:' + (max ? Math.max(4, Math.round(p.volume_ml / max * 26)) : 4) + 'px"></i>'; }).join('');
      var meta = isTea(r)
        ? '🍵 ' + fmt(r.dose_g, 1) + ' جم · ' + (r.pours[0] ? r.pours[0].temperature_c : '—') + '°'
        : fmt(r.dose_g, 1) + ' جم · 1:' + fmt(ratioOf(r), 1) + ' · ' + (r.pours[0] ? r.pours[0].temperature_c : '—') + '°';
      return '<button class="rcard' + (r.id === selected ? ' on' : '') + '" data-act="pick" data-id="' + r.id + '">' +
        '<h4>' + (r.fav ? '<span class="star">★</span> ' : '') + esc(r.name) + '</h4><div class="meta">' + meta +
        '</div><div class="mini-shape">' + mini + '</div></button>';
    }).join('');
    $view.innerHTML = '<div class="home">' + hero +
      '<div class="others"><div class="section-title"><h3>وصفاتك</h3>' +
      '<button class="mini" data-act="library">' + icon('book') + ' المكتبة</button>' +
      (hasCamera() ? '<button class="mini" data-act="receive">' + icon('scan') + ' استلام وصفة</button>' : '') + '</div>' +
      '<div class="rgrid">' + cards + '<button class="rcard add" data-act="new">' + icon('plus') + 'وصفة جديدة</button></div></div></div>';
  }

  // ---------------------------------------------------------------- editor
  function stepper(label, path, value, step, min, max, unit) {
    return '<div class="field"><label>' + label + '</label><div class="stepper">' +
      '<button data-act="step" data-path="' + path + '" data-d="' + step + '" data-min="' + min + '" data-max="' + max + '">+</button>' +
      '<output>' + fmt(value, 1) + (unit ? '<small>' + unit + '</small>' : '') + '</output>' +
      '<button data-act="step" data-path="' + path + '" data-d="' + (-step) + '" data-min="' + min + '" data-max="' + max + '">−</button>' +
      '</div></div>';
  }
  function choice(label, path, value, options) {
    return '<div class="field"><label>' + label + '</label><div class="seg">' + options.map(function (o) {
      return '<button data-act="set" data-path="' + path + '" data-v="' + o[0] + '" class="' + (String(o[0]) === String(value) ? 'on' : '') + '">' + o[1] + '</button>';
    }).join('') + '</div></div>';
  }

  function getPath(obj, path) { return path.split('.').reduce(function (o, k) { return o[k]; }, obj); }
  function setPath(obj, path, v) {
    var keys = path.split('.'), last = keys.pop();
    keys.reduce(function (o, k) { return o[k]; }, obj)[last] = v;
  }

  function renderEdit() {
    var r = draft, L = XB.LIMITS;
    var cup = XB.CUP_TYPES.filter(function (c) { return c.api === r.cup_type; })[0] || XB.CUP_TYPES[2];
    var grinds = r.grinder_size_enabled !== 0;
    var tea = isTea(r);
    var errs = XB.validate(r);
    var drink = '<div class="field"><label>نوع المشروب</label><div class="seg">' +
      '<button data-act="drink" data-v="coffee" class="' + (tea ? '' : 'on') + '">قهوة</button>' +
      '<button data-act="drink" data-v="tea" class="' + (tea ? 'on' : '') + '">شاي 🍵</button></div></div>';
    var html = '<div class="edit"><div class="edit-head">' +
      '<input id="name" value="' + esc(r.name) + '" placeholder="اسم الوصفة">' +
      '<button class="primary" data-act="save"' + (errs.length ? ' disabled' : '') + '>حفظ</button>' +
      '<button data-act="cancel">إلغاء</button></div>' +
      '<div class="totals"><div class="stat"><b>' + fmt(XB.totalWater(r)) + '</b><small>مل ماء</small></div>' +
      (tea
        ? '<div class="stat"><b>' + (r.pours[0] ? r.pours[0].temperature_c + '°' : '—') + '</b><small>الحرارة</small></div>' +
          '<div class="stat"><b>' + r.pours.length + '</b><small>نقعات</small></div></div>'
        : '<div class="stat"><b>1:' + fmt(ratioOf(r), 1) + '</b><small>النسبة</small></div>' +
          '<div class="stat"><b>' + r.pours.length + '</b><small>دفعات</small></div></div>') +
      (errs.length ? '<div class="notice bad">' + icon('alert') + errs.map(errText).join('، ') + '</div>' : '') +
      '<section class="card"><h4>' + (tea ? 'الشاي' : 'البن') + '</h4><div class="grid">' + drink +
      (tea ? '' : choice('نوع الكوب', 'cup_type', r.cup_type, XB.CUP_TYPES.filter(function (c) { return c.api !== 4; }).map(function (c) { return [c.api, CUP_AR[c.api]]; }))) +
      stepper(tea ? 'كمية الشاي (أوراق)' : 'كمية البن', 'dose_g', r.dose_g, 0.5, cup.dose[0], cup.dose[1], 'جم') +
      (tea ? '' : choice('المطحنة', 'grinder_size_enabled', grinds ? 1 : 0, [[1, 'تطحن'], [0, 'بن مطحون']])) +
      (!tea && grinds ? stepper('درجة الطحن (أقل = أنعم)', 'grinder_size', r.grinder_size, 1, L.grind_size[0], L.grind_size[1]) +
        stepper('سرعة المطحنة', 'rpm', r.rpm, 10, L.rpm[0], L.rpm[1], 'RPM') : '') +
      '</div><div class="auto-row">' +
      (tea ? '<span class="lbl">كل نقعة تُصبّ ماء على الأوراق في مصفاة الشاي.</span>'
           : '<span class="lbl">وزّع الماء تلقائياً:</span>' +
             [14, 15, 16, 17].map(function (x) { return '<button data-act="auto" data-ratio="' + x + '">1:' + x + '</button>'; }).join('')) +
      '<button data-act="addpour"' + (r.pours.length >= 9 ? ' disabled' : '') + '>+ ' + (tea ? 'نقعة' : 'دفعة') + '</button></div></section>';
    r.pours.forEach(function (p, i) {
      var b = 'pours.' + i + '.';
      var head = tea ? 'نقعة ' + (i + 1) : (i === 0 && r.pours.length > 1 ? 'التشريب (دفعة 1)' : 'دفعة ' + (i + 1));
      html += '<section class="card pour"><h4>' + head +
        (r.pours.length > 1 ? ' <button class="mini danger" data-act="delpour" data-i="' + i + '">حذف</button>' : '') +
        '</h4><div class="grid">' +
        stepper(tea ? 'ماء النقعة' : 'الماء', b + 'volume_ml', p.volume_ml, 5, 0, L.volume[1], 'مل') +
        stepper('الحرارة', b + 'temperature_c', p.temperature_c, 1, L.temp[0], L.temp[1], '°م') +
        stepper(tea ? 'انتظار بين النقعات' : 'انتظار بعدها', b + 'pause_s', p.pause_s, 5, 0, L.pause[1], 'ث') +
        stepper('سرعة الصب', b + 'flow_rate', p.flow_rate, 0.1, L.flow[0], L.flow[1], 'مل/ث') +
        (tea ? '' :
          choice('طريقة الصب', b + 'pattern', p.pattern, XB.PATTERNS.map(function (x) { return [x.api, PATTERN_AR[x.api]]; })) +
          choice('هز قبل', b + 'agitate_before', p.agitate_before, [[1, 'نعم'], [2, 'لا']]) +
          choice('هز بعد', b + 'agitate_after', p.agitate_after, [[1, 'نعم'], [2, 'لا']])) +
        '</div></section>';
    });
    $view.innerHTML = html + '</div>';
  }

  function errText(e) {
    if (e === 'dose') return 'كمية البن خارج حدود الكوب';
    if (e === 'ratio') return 'النسبة لازم بين 1:5 و 1:25';
    if (e === 'water') return 'ما فيه ماء';
    if (e === 'grinder') return 'إعدادات المطحنة';
    return e;
  }

  // ------------------------------------------------------------------ brew
  // One big ring: water poured out of the recipe's total, readable from across
  // the kitchen. Grinding has no measure, so the ring turns instead.
  //
  // The SVG ring is drawn ONCE per phase and then only its numbers and arc are
  // nudged each tick — rebuilding the whole node every second restarted the CSS
  // spin from zero, which looked like a stutter.
  var RING_R = 160, RING_C = 2 * Math.PI * 160;
  var brewTimer = null, brewPhaseKey = '';

  function ringSvg(spinning) {
    return '<svg viewBox="0 0 360 360">' +
      '<circle cx="180" cy="180" r="' + RING_R + '" fill="none" stroke="#E1E5F0" stroke-width="22"/>' +
      '<circle class="arc" cx="180" cy="180" r="' + RING_R + '" fill="none" stroke="#213E9A" stroke-width="22" ' +
      'stroke-linecap="round" stroke-dasharray="0 ' + RING_C.toFixed(1) + '" transform="rotate(-90 180 180)"/></svg>';
  }

  function brewWeight(m) { return m.weight === null ? '—' : fmt(m.weight, 1); }

  function renderBrew() {
    var b = link.brew, m = link.machine, r = b.recipe;
    var finished = ['done', 'stopped', 'failed'].indexOf(b.phase) >= 0;
    var spinning = b.phase === 'grinding' || b.phase === 'starting';
    // Full rebuild only when the phase changes; otherwise just update numbers.
    var key = b.phase + '|' + (r ? r.id : '') + '|' + (b.error || '') + '|' + (b.fault || '') + '|' + b.pour;
    if (key !== brewPhaseKey || !document.querySelector('.brew')) {
      brewPhaseKey = key;
      buildBrew(b, m, r, finished, spinning);
    }
    updateBrew(b, m, r, finished, spinning);
    clearTimeout(brewTimer);
    if (!finished) brewTimer = setTimeout(function () { if (link.isBrewing()) renderBrew(); }, 250);
  }

  function buildBrew(b, m, r, finished, spinning) {
    var total = r ? XB.totalWater(r) : 0;
    var title = PHASE_AR[b.phase] || '';
    var center = b.phase === 'done'
      ? icon('check')
      : spinning
        ? '<div class="big" id="bz">0:00</div><div class="unit">' + (b.phase === 'starting' ? L('يرسل الوصفة') : L('يطحن') + ' ' + (r ? fmt(r.dose_g, 1) + ' ' + L('جم') : '')) + '</div>'
        : '<div class="big" id="bz">0</div><div class="unit">' + L('مل') + (total ? L(' من ') + fmt(total) : '') + '</div>';
    var track = '';
    if (r && r.pours.length) {
      track = '<div class="pours-track">' + r.pours.map(function (p, i) {
        var n = i + 1;
        var cls = b.phase === 'done' || n < b.pour ? 'done' : (n === b.pour && b.phase === 'pouring') ? 'now' : '';
        return '<span class="' + cls + '">' + pourLabel(r, i) + ' · ' + fmt(p.volume_ml) + '</span>';
      }).join('') + '</div>';
    }
    var notice = b.error ? '<div class="notice bad">' + icon('alert') + (REASON_AR[b.error] || b.error) + '</div>'
      : b.fault ? '<div class="notice warn">' + icon('alert') + (REASON_AR[b.fault] || b.fault) + '</div>' : '';
    var controls = finished
      ? '<button class="primary" data-act="brewok">' + icon('check') + 'تمام</button>'
      : (b.phase === 'paused'
        ? '<button class="primary" data-act="resume">' + icon('play') + 'كمّل</button>'
        : '<button data-act="pause"' + (b.phase === 'starting' ? ' disabled' : '') + '>' + icon('pause') + 'إيقاف مؤقت</button>') +
        '<button class="danger" data-act="stop">' + icon('stop') + 'إلغاء</button>';
    $view.innerHTML = '<div class="brew ' + b.phase + '">' +
      '<div class="phase">' + title + '</div>' +
      (r ? '<div class="rname">' + esc(r.name) + '</div>' : '<div class="rname">&nbsp;</div>') +
      notice +
      '<div class="ring' + (spinning ? ' spin' : '') + '">' + ringSvg(spinning) + '<div class="center">' + center + '</div></div>' +
      track +
      '<div class="brew-stats">' +
      '<div class="card"><b id="btime">0:00</b><small>الوقت</small></div>' +
      '<div class="card"><b id="bweight">—</b><small>جرام في الكوب</small></div></div>' +
      '<div class="brew-controls">' + controls + '</div></div>';
  }

  function updateBrew(b, m, r, finished, spinning) {
    var total = r ? XB.totalWater(r) : 0;
    var water = m.water === null ? 0 : m.water;
    var end = b.endedAt || Date.now();
    var secs = Math.max(0, Math.floor((end - b.startedAt) / 1000));
    var time = Math.floor(secs / 60) + ':' + ('0' + secs % 60).slice(-2);
    var set = function (id, v) { var el = document.getElementById(id); if (el && el.textContent !== v) el.textContent = v; };
    set('btime', time);
    set('bweight', brewWeight(m));
    if (b.phase === 'done') set('bz', '');
    else if (spinning) set('bz', time);
    else set('bz', fmt(water));
    // Move the arc without redrawing: whole ring when done/spin-end, else the poured fraction.
    var arc = document.querySelector('.brew .arc');
    if (arc) {
      var frac = b.phase === 'done' ? 1 : spinning ? 0 : (total ? Math.max(0, Math.min(1, water / total)) : 0);
      arc.setAttribute('stroke', b.phase === 'done' ? '#1E9E62' : finished ? '#D6453D' : '#213E9A');
      arc.setAttribute('stroke-dasharray', (RING_C * frac).toFixed(1) + ' ' + RING_C.toFixed(1));
      arc.style.opacity = spinning ? '0' : '1';  // while grinding, only the CSS spinner shows
    }
  }

  // --------------------------------------------------------------- welcome
  // The first thing on screen at every start: all brand blue, the logo, a
  // greeting, one button. The link to the machine comes up behind it.
  function clockStr() {
    var d = new Date(), h = d.getHours(), m = ('0' + d.getMinutes()).slice(-2);
    var en = curLang() === 'en';
    var ap = h < 12 ? (en ? 'AM' : 'ص') : (en ? 'PM' : 'م'), h12 = h % 12; if (h12 === 0) h12 = 12;
    return h12 + ':' + m + ' ' + ap;
  }
  function renderWelcome() {
    var h = new Date().getHours();
    var en = curLang() === 'en';
    var greet = h < 12 ? (en ? 'Good morning' : 'صباح الخير') : (en ? 'Good evening' : 'مساء الخير');
    var ready = link.state === 'connected';
    var status = !link.savedAddress() ? 'أول مرة؟ بنربط الشاشة بمكينتك بخطوات بسيطة'
      : ready ? 'المكينة جاهزة' : link.state === 'connecting' ? 'نتصل بالمكينة…' : 'المكينة غير متصلة';
    var alert = machineAlert();
    $view.innerHTML = '<div class="splash">' +
      '<i class="deco d1"></i><i class="deco d2"></i><i class="deco d3"></i>' +
      '<div class="splash-clock" id="splashclock">' + clockStr() + '</div>' +
      '<div class="splash-body">' +
      '<img class="splash-logo" src="brand/logo-white.png" alt="الساقي">' +
      '<h1>' + greet + '</h1>' +
      '<p class="splash-sub">قهوتك المختصة، بضغطة زر</p>' +
      '<button class="splash-btn" data-act="enter">ابدأ</button>' +
      (alert ? '<p class="splash-alert">' + esc(alert) + '</p>' : '') +
      '<p class="splash-status"><i class="dot' + (ready ? ' on' : link.state === 'connecting' ? ' wait' : '') + '"></i>' + status + '</p>' +
      '</div><div class="splash-foot">xBloom Studio</div></div>';
  }

  // ----------------------------------------------------------------- setup
  // First run, or a new machine: (1) the bridge, only on a screen without
  // Bluetooth; (2) the owner's machine, picked by the code printed on it.
  var setupCode = '', setupPicked = null;

  function setupStep() {
    if (viaBridge && transport.status() !== 'ok') return 'bridge';
    if (setupPicked && link.state === 'connected') return 'done';
    return 'machine';
  }

  function wifiLine() {
    if (!window.XBNative || !XBNative.wifiName) return '';
    var name = XBNative.wifiName();
    return '<p>واي فاي الشاشة: <b>' + (name ? esc(name) : 'غير متصل') + '</b> ' +
      '<button class="mini" data-act="wifi">إعدادات الواي فاي</button></p>';
  }

  function renderSetup() {
    var step = setupStep();
    var steps = (viaBridge ? ['bridge'] : []).concat(['machine']);
    var dots = steps.map(function (st, i) {
      var cur = steps.indexOf(step);
      return '<i class="' + (step === 'done' || i < cur ? 'done' : i === cur ? 'now' : '') + '"></i>';
    }).join('');
    var html = '<div class="setup"><button class="ghost back" data-act="towelcome">→ رجوع</button>' +
      '<div class="welcome"><img src="brand/logo-blue.png" alt="الساقي">' +
      '<h2>أهلاً بك</h2><p>خطوات بسيطة ونربط الشاشة بمكينتك</p></div><div class="steps">' + dots + '</div>';
    if (step === 'bridge') {
      var many = transport.found.length > 1;
      html += '<section class="card"><h4>١. جهاز الجسر (ESP32)</h4>' +
        '<p class="hint">هذي الشاشة ما فيها بلوتوث، فتكلّم المكينة عن طريق قطعة ESP32 صغيرة.</p>' +
        wifiLine() +
        '<ol class="howto"><li>وصّل القطعة بالكهرباء قريب من المكينة.</li>' +
        '<li>من جوالك ادخل شبكة الواي فاي <b>xBloom-Bridge-…</b> — تطلع صفحة.</li>' +
        '<li>اختر فيها شبكة البيت (نفس شبكة الشاشة) واكتب كلمة السر.</li>' +
        '<li>ارجع هنا واضغط "دوّر على الجسر".</li></ol>' +
        '<div class="row"><button class="primary" data-act="findbridge">دوّر على الجسر</button></div>' +
        (many ? '<p>لقيت أكثر من جسر — اختر اللي رقمه مكتوب على صفحة الإعداد في جوالك:</p><div class="devs">' +
          transport.found.map(function (b, i) {
            return '<button class="dev" data-act="pickbridge" data-i="' + i + '">جسر <b>' + esc(b.id || '?') + '</b> <small>' + esc(b.ip) + '</small></button>';
          }).join('') + '</div>' : '') +
        '<details><summary>ما لقيته؟ اكتب عنوانه</summary><div class="row">' +
        '<input id="bridgehost" placeholder="مثل 192.168.1.50" value="' + esc(transport.host || '') + '">' +
        '<button data-act="setbridge">اتصل</button></div></details></section>';
    } else if (step === 'machine') {
      var st = link.status();
      var problem = { no_bluetooth: 'هذي الشاشة ما فيها بلوتوث — تحتاج جسر ESP32.', off: 'البلوتوث مقفل — شغّله من إعدادات أندرويد.',
        no_permission: 'التطبيق يحتاج صلاحية الموقع/البلوتوث عشان يدوّر على المكينة.' }[st];
      html += '<section class="card"><h4>' + (viaBridge ? '٢' : '١') + '. اختر مكينتك</h4>' +
        (problem ? '<div class="notice bad">' + icon('alert') + problem + '</div>' : '') +
        '<ol class="howto"><li>شغّل المكينة، وسكّر تطبيق xBloom في الجوال (المكينة تقبل اتصال واحد بس).</li>' +
        '<li>رقم مكينتك: آخر ٦ حروف من الرقم التسلسلي — مكتوب تحت المكينة، وتلقاه في تطبيق xBloom.</li></ol>' +
        '<div class="code-row"><input id="mcode" placeholder="A1B2C3" value="' + esc(setupCode) + '" maxlength="12">' +
        '<button class="primary" data-act="scan"' + (link.scanning ? ' disabled' : '') + '>' + (link.scanning ? 'يدوّر…' : 'دوّر') + '</button></div>' +
        '<div id="devlist" class="devs">' + machineList() + '</div></section>';
    } else {
      html += '<section class="card done-card">' + icon('check') + '<h3>تم الربط</h3><p>الشاشة مربوطة بمكينة <b>' +
        esc(Link.machineCode(link.savedName())) + '</b></p><button class="primary cta" data-act="setupdone">يلا نحضّر</button></section>';
    }
    $view.innerHTML = html + '</div>';
  }

  function machineList() {
    var code = setupCode.toUpperCase().replace(/\s/g, '');
    var items = Object.keys(link.found).map(function (a) { return link.found[a]; })
      .filter(function (d) { return !code || Link.machineCode(d.name).toUpperCase().indexOf(code) >= 0; });
    if (!items.length) {
      return '<p class="hint">' + (link.scanning ? 'أدوّر على المكاين القريبة…' :
        Object.keys(link.found).length ? 'ما فيه مكينة بهذا الرقم قريبة.' : 'اضغط "دوّر".') + '</p>';
    }
    return items.map(function (d) {
      var busy = setupPicked === d.address && link.state === 'connecting';
      return '<button class="dev" data-act="pickmachine" data-addr="' + esc(d.address) + '">xBloom <b>' +
        esc(Link.machineCode(d.name)) + '</b>' + (busy ? ' <small>يتصل…</small>' : '') + '</button>';
    }).join('');
  }

  // -------------------------------------------------------------- settings
  function renderSettings() {
    var m = link.machine, st = link.status(), conn = link.state === 'connected';
    var problem = { no_bluetooth: 'هذي الشاشة ما فيها بلوتوث شغّال.', off: 'البلوتوث مقفل — شغّله من إعدادات أندرويد.',
      no_permission: 'التطبيق يحتاج صلاحية الموقع/البلوتوث عشان يدوّر على المكينة.',
      no_bridge: 'ما وصلت لجهاز الجسر (ESP32) — تأكد إنه موصول بالكهرباء وعلى نفس شبكة الواي فاي.' }[st];
    var found = Object.keys(link.found).map(function (a) {
      var d = link.found[a];
      return '<button class="dev" data-act="connect" data-addr="' + esc(a) + '">' + esc(d.name) + ' <small>' + esc(a) + '</small></button>';
    }).join('');
    function seg(label, act, cur, opts) {
      return '<div class="field"><label>' + label + '</label><div class="seg">' + opts.map(function (o) {
        return '<button data-act="' + act + '" data-v="' + o[0] + '" class="' + (cur === o[0] ? 'on' : '') + '"' + (conn ? '' : ' disabled') + '>' + o[1] + '</button>';
      }).join('') + '</div></div>';
    }
    var up = (function () {
      var p = OTA.pending();
      var head = '<section class="card"><h4>' + icon('download') + 'التحديثات</h4>';
      if (!OTA.present()) return head + '<p class="hint">التحديث التلقائي يشتغل على شاشة الساقي.</p></section>';
      var cur = '<p>إصدار الواجهة: <b>' + OTA.curWeb() + '</b></p>';
      if (p) {
        var notes = (p.notes || []).map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('');
        return head + cur +
          '<div class="notice ok">' + icon('download') + 'يتوفر تحديث: ' + esc(p.title) + (p.kind === 'apk' ? ' (تحديث النظام)' : '') + '</div>' +
          (notes ? '<ul class="ota-notes">' + notes + '</ul>' : '') +
          '<div class="row"><button class="primary" data-act="otaapply">تحديث الآن</button>' +
          '<button data-act="otacheck">تحقق</button></div></section>';
      }
      var err = OTA.lastError();
      if (err) return head + cur + '<div class="notice bad">' + icon('alert') + esc(OTA.reason(err, 'check')) + '</div>' +
        '<p class="hint" dir="ltr" style="font-size:13px">' + esc(err) + '</p>' +
        '<div class="row"><button data-act="otacheck">التحقق من التحديثات</button></div></section>';
      return head + cur + '<p class="hint">أنت على آخر إصدار.</p>' +
        '<div class="row"><button data-act="otacheck">التحقق من التحديثات</button></div></section>';
    })();
    var cs = cupStats();
    var statsCard = '<section class="card"><h4>' + icon('cup') + 'الإحصائيات</h4>' +
      '<div class="stats"><div class="stat"><b>' + cs.today + '</b><small>أكواب اليوم</small></div>' +
      '<div class="stat"><b>' + cs.total + '</b><small>الإجمالي</small></div></div></section>';
    var guard = '<section class="card"><h4>' + icon('slot') + 'الحماية والتنبيهات</h4>' +
      '<div class="field"><label>قفل الإعدادات برقم سري</label><div class="row">' +
      (hasPin()
        ? '<button data-act="pinset">تغيير الرقم</button><button class="danger" data-act="pinremove">إزالة القفل</button>'
        : '<button class="primary" data-act="pinset">تعيين رقم سري</button>') +
      '</div></div>' +
      '<div class="field"><label>صوت التنبيه عند الانتهاء</label><div class="seg">' +
      '<button data-act="sound" data-v="on" class="' + (soundOn() ? 'on' : '') + '">صوت</button>' +
      '<button data-act="sound" data-v="off" class="' + (soundOn() ? '' : 'on') + '">صامت</button></div></div></section>';
    var langCard = '<section class="card"><h4>' + icon('book') + (curLang() === 'en' ? 'Language' : 'اللغة / Language') + '</h4><div class="seg">' +
      '<button data-act="lang" data-v="ar" class="' + (curLang() === 'ar' ? 'on' : '') + '">العربية</button>' +
      '<button data-act="lang" data-v="en" class="' + (curLang() === 'en' ? 'on' : '') + '">English</button></div></section>';
    $view.innerHTML = '<div class="settings">' + langCard + up + statsCard + guard +
      (viaBridge ? '<section class="card"><h4>جهاز الجسر (ESP32)</h4>' +
        '<p>الجسر: <b>' + esc(transport.id || '—') + '</b> · ' + (st === 'ok' ? 'متصل' : 'غير متصل') +
        (transport.host ? ' <small>' + esc(transport.host) + '</small>' : '') + '</p>' + wifiLine() +
        '<div class="row"><button data-act="findbridge">دوّر على الجسر</button>' +
        '<input id="bridgehost" placeholder="أو اكتب عنوانه، مثل 192.168.8.50" value="' + esc(transport.host || '') + '">' +
        '<button data-act="setbridge">اتصل</button></div></section>' : '') +
      '<section class="card"><h4>الاتصال بالمكينة</h4>' +
      (problem ? '<div class="notice bad">' + icon('alert') + problem + '</div>' : '') +
      '<p>المكينة: <b>' + (link.savedName() ? esc(Link.machineCode(link.savedName())) : '—') + '</b> · ' +
      ({ connected: 'متصل', connecting: 'جاري الاتصال…', disconnected: 'غير متصل' }[link.state]) + '</p>' +
      '<div class="row">' +
      (conn ? '<button data-act="disconnect">قطع الاتصال</button>'
        : '<button class="primary" data-act="scan"' + (link.scanning ? ' disabled' : '') + '>' + (link.scanning ? 'يدوّر…' : 'دوّر على المكينة') + '</button>') +
      '<button data-act="resetup">ربط مكينة ثانية</button></div>' +
      (found ? '<div class="devs">' + found + '</div>' : '') +
      '<p class="hint">المكينة تقبل اتصال واحد بس. إذا تبي تستخدم تطبيق الجوال، اقطع الاتصال من هنا أول.</p></section>' +
      '<section class="card"><h4>إعدادات المكينة</h4><div class="grid">' +
      seg('مصدر الماء', 'water', m.waterSource, [['tank', 'الخزان'], ['tap', 'الحنفية']]) +
      seg('الوضع', 'mode', m.mode, [['auto', 'Auto'], ['pro', 'Pro']]) +
      seg('وحدة الوزن', 'wunit', m.weightUnit, [['g', 'جرام'], ['ml', 'مل'], ['oz', 'أونصة']]) +
      seg('وحدة الحرارة', 'tunit', m.tempUnit, [['c', '°م'], ['f', '°ف']]) +
      '</div><div class="row"><button data-act="tare"' + (conn ? '' : ' disabled') + '>تصفير الميزان</button></div>' +
      '<p class="hint">' + (m.serial ? 'الرقم التسلسلي: ' + esc(m.serial) + ' · ' : '') + (m.fw ? 'النسخة: ' + esc(m.fw) : '') + '</p></section>' +
      '</div>';
  }

  // ------------------------------------------------------------ header bar
  function renderBar() {
    var m = link.machine;
    var wt = document.getElementById('st-weight'), wa = document.getElementById('st-water');
    wt.querySelector('.ic').innerHTML = icon('scale').replace(/^<span class="ic">|<\/span>$/g, '');
    wt.querySelector('b').textContent = m.weight === null ? '—' : fmt(m.weight, 1) + ' ' + L('جم');
    wa.querySelector('.ic').innerHTML = icon('drop').replace(/^<span class="ic">|<\/span>$/g, '');
    wa.querySelector('b').textContent = m.waterEnough === null ? 'الماء —' : (m.waterEnough ? 'الماء تمام' : 'الماء ناقص');
    wa.className = 'pill' + (m.waterEnough === false ? ' bad' : '');
    var c = document.getElementById('st-conn');
    c.querySelector('b').textContent = { connected: 'متصل', connecting: 'يتصل…', disconnected: link.scanning ? 'يدوّر…' : 'غير متصل' }[link.state];
    c.className = 'pill conn ' + link.state;
  }

  // ---------------------------------------------------------------- actions
  function fail(err) { toast(REASON_AR[err && err.reason] || 'صار خطأ', true); }

  function act(el) {
    var a = el.getAttribute('data-act');
    var r = byId(selected);
    switch (a) {
      case 'go':
        draft = null;
        var dv = el.getAttribute('data-view');
        if (dv !== 'guide') fromWelcome = false;
        // Settings behind a PIN: show the lock first (once per session).
        if (dv === 'settings' && hasPin() && !settingsUnlocked) { pinInput = ''; pinMode = 'enter'; go('lock'); break; }
        go(dv); break;
      case 'pinkey': pinDigit(el.getAttribute('data-k')); break;
      case 'pinclear': pinInput = ''; renderLock(); break;
      case 'pinback': pinInput = pinInput.slice(0, -1); renderLock(); break;
      case 'pinset': pinInput = ''; pinMode = 'set'; go('lock'); break;
      case 'pinremove':
        if (confirm(L('إزالة القفل عن الإعدادات؟'))) { clearPin(); toast('انشال القفل'); renderSettings(); }
        break;
      case 'lang': setLang(el.getAttribute('data-v')); break;
      case 'sound': setSound(el.getAttribute('data-v') === 'on'); renderSettings(); if (el.getAttribute('data-v') === 'on') chime(); break;
      case 'enter':
        if (!link.savedAddress()) { go('setup'); break; }
        fromWelcome = true;  // came via the Start button -> show the guide intro
        go('guide');
        break;
      case 'diagrefresh': renderDiag(); break;
      case 'otaapply': OTA.apply(); break;
      case 'otalater': OTA.later(); break;
      case 'otacheck': toast('نتحقق من التحديثات…'); OTA.check(true); break;
      case 'guidedone': case 'guideskip': fromWelcome = false; guideIntro = false; go('home'); break;
      case 'share': shareId = r.id; go('share'); break;
      case 'fav': r.fav = !r.fav; saveRecipes(); renderHome(); break;
      case 'library': go('library'); break;
      case 'addlib':
        var lp = LIBRARY[Number(el.getAttribute('data-i'))];
        if (!lp) break;
        var nr = lp.tea ? teaRecipe(lp) : starter(lp.name, lp.dose, lp.ratio, lp.grind, lp.temp, lp.n);
        recipes.push(nr); selected = nr.id; saveRecipes(); toast('أضفنا «' + lp.name + '»'); go('home'); break;
      case 'receive': go('scan'); break;
      case 'scancancel': stopScan(); go('home'); break;
      case 'towelcome': goWelcome(); break;
      case 'pick': selected = el.getAttribute('data-id'); renderHome(); break;
      case 'new':
        draft = starter('وصفة جديدة', 15, 16, 50, 92, 3); draft.isNew = true; go('edit'); break;
      case 'edit': draft = JSON.parse(JSON.stringify(r)); go('edit'); break;
      case 'dup':
        var copy = JSON.parse(JSON.stringify(r));
        copy.id = 'r' + Math.random().toString(36).slice(2, 9); copy.name = r.name + ' (نسخة)';
        recipes.push(copy); selected = copy.id; saveRecipes(); renderHome(); break;
      case 'del':
        if (!confirm(L('تحذف "') + r.name + L('"؟'))) return;
        recipes = recipes.filter(function (x) { return x.id !== r.id; }); selected = null; saveRecipes(); renderHome(); break;
      case 'brew':
        if (XB.validate(r).length) return toast('الوصفة فيها مشكلة — عدّلها أول', true);
        link.startBrew(JSON.parse(JSON.stringify(r))).catch(function () {});
        break;
      case 'slot':
        var s = prompt(L('أي زر بالمكينة؟ اكتب A أو B أو C'), 'A');
        if (!s) return;
        var idx = { A: 0, B: 1, C: 2 }[s.trim().toUpperCase()];
        if (idx === undefined) return toast('اكتب A أو B أو C', true);
        link.send('slot', XB.packets.slotWrite(idx, r, true), { timeout: 3000 })
          .then(function () { toast('انحفظت في زر ' + s.trim().toUpperCase() + ' — تقدر تشغلها من المكينة بوضع Auto'); }, fail);
        break;
      case 'pause': link.pauseBrew().catch(fail); break;
      case 'resume': link.resumeBrew().catch(fail); break;
      case 'stop':
        if (confirm(L('توقف التحضير؟'))) link.stopBrew().catch(fail);
        break;
      case 'brewok': link.clearBrew(); go('home'); break;
      // editor
      case 'step':
        var path = el.getAttribute('data-path'), d = parseFloat(el.getAttribute('data-d'));
        var v = Math.round((Number(getPath(draft, path)) + d) * 10) / 10;
        v = Math.min(parseFloat(el.getAttribute('data-max')), Math.max(parseFloat(el.getAttribute('data-min')), v));
        setPath(draft, path, v); keepName(); renderEdit(); break;
      case 'set':
        var p2 = el.getAttribute('data-path'), raw = el.getAttribute('data-v');
        setPath(draft, p2, Number(raw));
        if (p2 === 'cup_type') {
          var cup = XB.CUP_TYPES.filter(function (c) { return c.api === draft.cup_type; })[0];
          draft.dose_g = Math.min(cup.dose[1], Math.max(cup.dose[0], draft.dose_g));
        }
        keepName(); renderEdit(); break;
      case 'drink':
        keepName();
        var toTea = el.getAttribute('data-v') === 'tea';
        if (toTea && !isTea(draft)) {
          draft.cup_type = 4; draft.grinder_size_enabled = 0;
          if (draft.dose_g > 5 || draft.dose_g < 1) draft.dose_g = 4;
          draft.pours.forEach(function (p) { if (p.temperature_c < 70) p.temperature_c = 90; if (p.volume_ml < 80) p.volume_ml = 150; });
        } else if (!toTea && isTea(draft)) {
          draft.cup_type = 2; draft.grinder_size_enabled = 1;
          if (draft.dose_g < 5) draft.dose_g = 15;
        }
        renderEdit(); break;
      case 'auto':
        keepName();
        draft.pours = XB.autoPours(draft.dose_g, Number(el.getAttribute('data-ratio')), draft.pours.length,
          draft.pours[0] ? draft.pours[0].temperature_c : 92);
        renderEdit(); break;
      case 'addpour':
        keepName();
        var last = draft.pours[draft.pours.length - 1];
        draft.pours.push(JSON.parse(JSON.stringify(last))); renderEdit(); break;
      case 'delpour':
        keepName(); draft.pours.splice(Number(el.getAttribute('data-i')), 1); renderEdit(); break;
      case 'save':
        keepName();
        if (!draft.name.trim()) return toast('اكتب اسم للوصفة', true);
        var isNew = draft.isNew; delete draft.isNew;
        if (isNew) recipes.push(draft);
        else recipes = recipes.map(function (x) { return x.id === draft.id ? draft : x; });
        selected = draft.id; draft = null; saveRecipes(); toast('انحفظت'); go('home'); break;
      case 'cancel': draft = null; go('home'); break;
      // settings
      case 'findbridge':
        toast('أدوّر على الجسر…');
        transport.find(function (pick, all) {
          if (pick) toast('لقيت الجسر ' + (pick.id || pick.ip));
          else if (all.length > 1) toast('لقيت ' + all.length + ' — اختر جسرك');
          else toast('ما لقيته — تأكد إنه على نفس الشبكة', true);
          render();
        });
        break;
      case 'pickbridge': transport.choose(transport.found[Number(el.getAttribute('data-i'))]); toast('أتصل بالجسر…'); break;
      case 'wifi': XBNative.openWifiSettings(); break;
      case 'pickmachine':
        setupPicked = el.getAttribute('data-addr');
        link.connect(setupPicked);
        renderSetup();
        break;
      case 'setupdone': setupPicked = null; go('home'); break;
      case 'resetup':
        if (!confirm(L('تربط الشاشة بمكينة ثانية؟'))) return;
        link.forget(); setupCode = ''; setupPicked = null; go('setup');
        if (link.status() === 'ok') link.scan();
        break;
      case 'setbridge':
        var h = document.getElementById('bridgehost').value.trim();
        if (h) { transport.setHost(h); toast('أتصل بالجسر…'); }
        break;
      case 'scan':
        var st = link.status();
        if (st !== 'ok') { render(); return toast(viaBridge ? 'الجسر مو متصل' : 'البلوتوث مو جاهز', true); }
        link.scan(); render(); break;
      case 'connect': link.connect(el.getAttribute('data-addr')); break;
      case 'disconnect': link.disconnect(); break;
      case 'forget': link.forget(); renderSettings(); break;
      case 'water': link.send('water', XB.packets.waterSource(el.getAttribute('data-v'))).catch(fail); break;
      case 'mode': link.send('mode', XB.packets.mode(el.getAttribute('data-v'))).catch(fail); break;
      case 'wunit': link.send('unit', XB.packets.weightUnit(el.getAttribute('data-v'))).catch(fail); break;
      case 'tunit': link.send('unit', XB.packets.tempUnit(el.getAttribute('data-v'))).catch(fail); break;
      case 'tare': link.send('tare', XB.packets.tare()).then(function () { toast('تم تصفير الميزان'); }, fail); break;
    }
  }
  function keepName() { var n = document.getElementById('name'); if (n && draft) draft.name = n.value; }

  document.addEventListener('input', function (e) {
    if (e.target.id !== 'mcode') return;
    setupCode = e.target.value;
    var list = document.getElementById('devlist');
    if (list) list.innerHTML = machineList();
  });

  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('[data-act]') : null;
    if (el && !el.disabled) act(el);
  });

  link.on(function (what) {
    renderBar();
    // Count a cup once, the moment a brew finishes, and bump that recipe's use.
    if (link.brew.phase === 'done' && link.brew.startedAt && link.brew.startedAt !== countedBrewAt) {
      countedBrewAt = link.brew.startedAt;
      bumpCup();
      chime(); // a ready chime
      var done = link.brew.recipe && byId(link.brew.recipe.id);
      if (done) { done.uses = (done.uses || 0) + 1; saveRecipes(); }
    }
    if (view === 'welcome') { if (what === 'state' || what === 'brew') render(); return; }
    if (view === 'setup') {
      if (what === 'scan') {
        var list = document.getElementById('devlist');
        if (list) return void (list.innerHTML = machineList());
      }
      if (what === 'state') {
        if (setupPicked && link.state === 'disconnected' && link.detail && link.detail !== 'bridge_offline') {
          toast('ما قدرت أتصل — قرّب الشاشة/الجسر من المكينة وجرّب ثانية', true);
        }
        renderSetup();
        // The bridge just answered: look for machines straight away.
        if (setupStep() === 'machine' && !link.scanning && !Object.keys(link.found).length && link.status() === 'ok') link.scan();
      }
      return;
    }
    if (what === 'brew') { render(); OTA.refresh(); return; }
    if (what === 'state' || what === 'scan') {
      if (view === 'settings' || view === 'home') render();
      if (what === 'state' && link.state === 'connected') toast('اتصلت بالمكينة');
    }
    if (what === 'machine' && link.isBrewing()) return renderBrew();
    if (what === 'machine' && view === 'settings') {
      // Redraw only when a shown value changed: a redraw under a finger eats the tap.
      var m = link.machine;
      var key = [m.waterSource, m.mode, m.weightUnit, m.tempUnit, m.serial, m.fw].join('|');
      if (key !== lastSettingsKey) { lastSettingsKey = key; renderSettings(); }
    }
  });

  Array.prototype.forEach.call(document.querySelectorAll('[data-icon]'), function (el) {
    el.outerHTML = icon(el.getAttribute('data-icon'));
  });

  // The logo: a tap goes back to the welcome screen; holding it 3 seconds is
  // the way out of the kiosk to Android settings.
  var brand = document.querySelector('.brand'), holdTimer, held = false;
  function holdStart() {
    held = false;
    holdTimer = setTimeout(function () {
      held = true;
      if (window.XBNative && XBNative.openSettings) XBNative.openSettings();
      else toast('إعدادات أندرويد (على الشاشة فقط)');
    }, 3000);
  }
  function holdEnd() { clearTimeout(holdTimer); }
  brand.addEventListener('touchstart', holdStart);
  brand.addEventListener('mousedown', holdStart);
  ['touchend', 'touchcancel', 'mouseup', 'mouseleave'].forEach(function (e) { brand.addEventListener(e, holdEnd); });
  brand.addEventListener('click', function () { if (!held) goWelcome(); });

  // Tap the small "xBloom" word in the header 5 times to open the diagnosis screen.
  var prodTaps = 0, prodTimer;
  var product = document.querySelector('.product');
  if (product) product.addEventListener('click', function (e) {
    e.stopPropagation();
    prodTaps++;
    clearTimeout(prodTimer);
    prodTimer = setTimeout(function () { prodTaps = 0; }, 1200);
    if (prodTaps >= 5) { prodTaps = 0; go('diag'); }
  });

  function goWelcome() {
    if (link.isBrewing()) return; // the brew screen stays up while coffee is being made
    draft = null;
    go('welcome');
  }

  // Left alone for a while, the screen goes back to the welcome screen — but
  // never mid-brew or with an unsaved recipe open.
  var IDLE_MS = 5 * 60 * 1000, idleTimer;
  function resetIdle() {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(function () {
      if (view !== 'welcome' && view !== 'edit' && !link.isBrewing()) goWelcome();
      else resetIdle();
    }, IDLE_MS);
  }
  ['touchstart', 'mousedown', 'keydown'].forEach(function (e) { document.addEventListener(e, resetIdle, true); });
  resetIdle();

  // Keep the welcome-screen clock ticking.
  setInterval(function () {
    if (view === 'welcome') { var c = document.getElementById('splashclock'); if (c) c.textContent = clockStr(); }
  }, 15000);

  startLangObserver(); // sets lang/dir; rewrites rendered text when English
  renderBar();
  view = 'welcome';
  render();
  translateTree(document.body); // static bits (tabs, header) outside the re-rendered view
  OTA.init(); // check for updates in the background
  if (viaBridge) {
    // The bridge reports its link as soon as it answers; if that link is down,
    // connect to the remembered machine (or look for one) straight away.
    var looked = false;
    link.on(function (what) {
      if (what === 'state' && !looked && transport.status() === 'ok') {
        looked = true;
        if (link.state !== 'connected' && !link.autoConnect()) link.scan();
      }
    });
    transport.start();
  } else if (link.status() === 'ok') {
    if (!link.autoConnect()) link.scan();
  } else go('setup');
})();
