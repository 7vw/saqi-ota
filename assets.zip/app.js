/* Screens: recipes, recipe editor, live brew, settings. */
(function () {
  'use strict';

  // The web-layer version this code IS. publish-update.sh stamps it, so it
  // always equals assets/web-version of the same release.
  var WEB_BUILD = 20;
  // The version people see: 1, 1.1, 1.2… (also stamped by publish-update.sh).
  // WEB_BUILD stays the plain counter the update system compares.
  var WEB_LABEL = '1.9';
  // After an over-the-air update the old WebView can hand back its in-memory
  // copy of the previous page instead of the new files. If the files on disk
  // are newer than the code running, reload once to pick them up — so nobody
  // has to switch the screen off and on after an update.
  try {
    var onDisk = window.XBOTA ? Number(XBOTA.version()) : 0;
    if (onDisk > WEB_BUILD && localStorage.getItem('xb.healed') !== String(onDisk)) {
      localStorage.setItem('xb.healed', String(onDisk)); // one try per version, never a loop
      location.reload(true);
      return;
    }
  } catch (e) { /* no bridge / storage off: just run */ }

  // Bluetooth in this screen -> use it. No Bluetooth (the Memoria-10 frame) ->
  // go through the ESP32 Wi-Fi bridge. In a desktop browser: the pretend
  // machine, or a bridge given as ?bridge=host[:port].
  var query = /[?&]bridge=([^&]+)/.exec(location.search);
  var native = window.XBNative && XBNative.status() !== 'no_bluetooth';
  var viaBridge = !native && (!!window.XBNative || !!query);
  var transport = native ? window.XBNative : viaBridge ? new WsTransport() : new XBMock();
  if (query) transport.host = decodeURIComponent(query[1]);
  var link = new Link(transport);
  var $view = document.getElementById('view');

  // ---------------------------------------------------------------- text
  var PATTERN_AR = { 1: 'وسط', 2: 'حلزوني', 3: 'دائري' };
  var CUP_AR = { 1: 'xPod', 2: 'Omni', 3: 'آخر', 4: 'شاي' };
  var REASON_AR = {
    no_water: 'الماء ناقص — عبّ الخزان', not_on_home_screen: 'رجّع المكينة للشاشة الرئيسية وحاول مرة ثانية',
    not_ready: 'المكينة مو جاهزة — طفّها وشغّلها', restore_incomplete: 'المكينة مو جاهزة — طفّها وشغّلها',
    recipe_rejected: 'المكينة رفضت الوصفة — راجع كمية الماء والدفعات', machine_busy: 'المكينة مشغولة، انتظر شوي',
    no_reply: 'المكينة ما ردّت — تأكد إنها شغالة وقريبة', not_connected: 'مو متصل بالمكينة',
    no_beans: 'ما فيه بن في المطحنة', refused: 'المكينة رفضت الأمر', dose_water_error: 'خطأ في كمية البن أو الماء',
    gear_position_error: 'خطأ في وضع المطحنة'
  };
  var PHASE_AR = {
    starting: 'نجهّز الوصفة…', grinding: 'يطحن البن', pouring: 'يصب الماء', paused: 'متوقف مؤقتاً',
    done: 'قهوتك جاهزة', stopped: 'تم الإيقاف', failed: 'ما اكتمل التحضير'
  };
  // Tea brews say tea things; anything not listed falls back to PHASE_AR.
  var PHASE_TEA = { pouring: 'ينقع الشاي', done: 'شايك جاهز' };

  function esc(s) {
    return String(s === undefined || s === null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function fmt(n, d) { return (Math.round(n * Math.pow(10, d || 0)) / Math.pow(10, d || 0)).toString(); }
  function ratioOf(r) { var w = XB.totalWater(r); return r.dose_g ? w / r.dose_g : 0; }

  // -------------------------------------------------------- language (AR/EN)
  // The whole UI is authored in Arabic. For English we translate on the fly:
  // a dictionary + L() for strings built in code (toasts, confirms), and a
  // MutationObserver that rewrites rendered Arabic text to English after every
  // render. Arabic is the default and its path is untouched (L returns the
  // input and the observer early-exits), so nothing changes unless lang==='en'.
  function curLang() { try { return localStorage.getItem('xb.lang') === 'en' ? 'en' : 'ar'; } catch (e) { return 'ar'; } }
  // Short units / single standalone labels: translated ONLY when a text node
  // equals the key exactly, so they never corrupt a substring of other words.
  var EXACT = {
    'جم': 'g', 'مل': 'ml', 'ث': 's', '°م': '°C', '°ف': '°F', 'جرام': 'Grams',
    'وسط': 'Center', 'حلزوني': 'Spiral', 'دائري': 'Circular',
    'نعم': 'Yes', 'لا': 'No', 'صوت': 'Sound', 'صامت': 'Silent', 'آخر': 'Other', 'تم': 'Done',
    'ما عجبني': "Didn't like it", 'عادي': 'OK', 'حلو': 'Good'
  };
  // Multi-character phrases, safe to replace anywhere (applied longest-first).
  var DICT = {
    // header / tabs / status
    'الوصفات': 'Recipes', 'وصفة جديدة': 'New recipe', 'الشرح': 'Guide', 'الإعدادات': 'Settings',
    'غير متصل': 'Offline', 'الماء تمام': 'Water OK', 'الماء ناقص': 'Low water', 'الماء —': 'Water —',
    'متصل': 'Connected', 'يتصل بالمكينة…': 'Connecting to machine…', 'يتصل…': 'Connecting…',
    'جاري الاتصال…': 'Connecting…', 'يدوّر…': 'Scanning…',
    // cup type / drink / sections
    'شاي': 'Tea', 'قهوة': 'Coffee',
    // phases
    'نجهّز الوصفة…': 'Preparing the recipe…', 'يطحن البن': 'Grinding the beans', 'يصب الماء': 'Pouring water',
    'متوقف مؤقتاً': 'Paused', 'قهوتك جاهزة': 'Your coffee is ready', 'تم الإيقاف': 'Stopped', 'ما اكتمل التحضير': "Brew didn't finish",
    // reasons / faults
    'الماء ناقص — عبّ الخزان': 'Low water — fill the tank',
    'رجّع المكينة للشاشة الرئيسية وحاول مرة ثانية': 'Return the machine to its home screen and try again',
    'المكينة مو جاهزة — طفّها وشغّلها': 'Machine not ready — turn it off and on',
    'المكينة رفضت الوصفة — راجع كمية الماء والدفعات': 'Machine rejected the recipe — check the water and pours',
    'المكينة مشغولة، انتظر شوي': 'Machine is busy, wait a moment',
    'المكينة ما ردّت — تأكد إنها شغالة وقريبة': "No reply — make sure it's on and nearby",
    'مو متصل بالمكينة': 'Not connected to the machine', 'ما فيه بن في المطحنة': 'No beans in the grinder',
    'المكينة رفضت الأمر': 'Machine refused the command', 'خطأ في كمية البن أو الماء': 'Error in coffee or water amount',
    'خطأ في وضع المطحنة': 'Grinder position error',
    // brew center / labels
    'يرسل الوصفة': 'Sending recipe', 'يطحن': 'Grinding', ' من ': ' of ',
    'التشريب (دفعة 1)': 'Bloom (pour 1)', 'تشريب': 'Bloom',
    'دفعات': 'pours', 'دفعة ': 'Pour ', 'دفعة': 'pour', 'نقعة ': 'Steep ', 'نقعة': 'steep', 'صبّات': 'pours',
    'الوقت': 'Time', 'جرام في الكوب': 'Grams in cup',
    'جم شاي': 'g tea', 'جم بن': 'g coffee', 'مل ماء': 'ml water', 'جم ·': 'g ·',
    'نقعات': 'steeps', 'الحرارة': 'Temp', 'النسبة': 'Ratio', 'الطحنة': 'Grind',
    // OTA
    'تحديث جديد متوفر': 'Update available', ' · تحديث النظام': ' · System update', ' (تحديث النظام)': ' (system update)',
    'تحديث النظام': 'System update', 'تحديث الآن': 'Update now', 'لاحقًا': 'Later',
    'يُنزّل تحديث النظام…': 'Downloading system update…', 'يُحدّث الآن…': 'Updating now…',
    'بعد التنزيل اضغط «تثبيت»': 'After the download, tap «Install»', 'لا تطفئ الشاشة': "Don't turn off the screen",
    'تعذّر بدء التحديث': "Couldn't start the update", 'جاهز للتثبيت': 'Ready to install',
    'اضغط «تثبيت» في نافذة النظام': 'Tap «Install» in the system dialog',
    'ما قدرنا نتحقق — تأكد من الإنترنت': "Couldn't check — check your internet",
    'ما نجح التحديث — جرّب لاحقًا': 'Update failed — try again later', 'تحديث ': 'Update ',
    'التحديثات': 'Updates', 'التحديث التلقائي يشتغل على شاشة الساقي.': 'Automatic updates run on the Al-Saqi screen.',
    'إصدار الواجهة: ': 'Interface version: ', 'يتوفر تحديث: ': 'Update available: ',
    'تحقق': 'Check', 'أنت على آخر إصدار.': "You're on the latest version.", 'التحقق من التحديثات': 'Check for updates',
    'نتحقق من التحديثات…': 'Checking for updates…',
    // default recipe names / dup
    'تحميص فاتح': 'Light roast', 'تحميص متوسط': 'Medium roast', 'تحميص غامق': 'Dark roast', 'كوب كبير': 'Large cup',
    ' (نسخة)': ' (copy)', 'ما قدرت أحفظ': "Couldn't save",
    // library
    'مكتبة الوصفات': 'Recipe library', 'وصفات جاهزة — أضفها لوصفاتك وعدّلها زي ما تحب.': 'Ready-made recipes — add them to yours and tweak freely.',
    'V60 كلاسيك': 'V60 Classic', 'نظيفة ومتوازنة': 'Clean and balanced',
    'هوفمان كوب واحد': 'Hoffmann one cup', 'حلاوة أعلى، ٤ صبّات': 'Sweeter, 4 pours',
    'فاتح مشرق': 'Bright light', 'حموضة وفواكه': 'Acidity and fruit',
    'غامق ناعم': 'Smooth dark', 'جسم أثقل، أقل حموضة': 'Heavier body, less acidity',
    'قهوة مثلّجة': 'Iced coffee', 'تُصبّ على ثلج': 'Poured over ice',
    'كوب مزدوج': 'Double cup', 'كوبين، كمية أكبر': 'Two cups, larger amount',
    'شاي أخضر': 'Green tea', 'حرارة ٨٠° · نقعة واحدة': '80° · one steep',
    'شاي أسود': 'Black tea', 'حرارة ٩٥° · نقعة واحدة': '95° · one steep',
    'أولونغ': 'Oolong', 'حرارة ٩٠° · نقعتين': '90° · two steeps',
    'أعشاب/كركديه': 'Herbal / Hibiscus', 'حرارة ٩٨° · نقعة واحدة': '98° · one steep', 'أضف': 'Add',
    // home
    'ما فيه وصفات للحين.': 'No recipes yet.', ' أضف أول وصفة': ' Add your first recipe',
    'مفضلة': 'Favorite', 'تعديل': 'Edit', 'نسخ': 'Copy', 'شارك': 'Share', 'زر بالمكينة': 'Machine button', 'حذف': 'Delete',
    'وصفاتك': 'Your recipes', ' المكتبة': ' Library', ' استلام وصفة': ' Receive recipe',
    // brew button
    'الوصفة تحتاج تعديل': 'Recipe needs editing', 'حضّر الحين': 'Brew now',
    'المكينة مو متصلة — اضغط هنا': 'Machine offline — tap here',
    // editor
    'نوع المشروب': 'Drink type', 'اسم الوصفة': 'Recipe name', 'حفظ': 'Save', 'إلغاء': 'Cancel',
    'الشاي': 'Tea', 'البن': 'Beans', 'نوع الكوب': 'Cup type', 'كمية الشاي (أوراق)': 'Tea amount (leaves)', 'كمية البن': 'Coffee amount',
    'المطحنة': 'Grinder', 'تطحن': 'Grind', 'بن مطحون': 'Pre-ground', 'درجة الطحن (أقل = أنعم)': 'Grind size (lower = finer)', 'سرعة المطحنة': 'Grinder speed',
    'كل نقعة تُصبّ ماء على الأوراق في مصفاة الشاي.': 'Each steep pours water over the leaves in the tea strainer.',
    'وزّع الماء تلقائياً:': 'Auto-distribute water:',
    'ماء النقعة': 'Steep water', 'الماء': 'Water', 'انتظار بين النقعات': 'Wait between steeps', 'انتظار بعدها': 'Wait after',
    'سرعة الصب': 'Flow rate', 'طريقة الصب': 'Pour pattern', 'هز قبل': 'Agitate before', 'هز بعد': 'Agitate after',
    // errors
    'كمية البن خارج حدود الكوب': 'Coffee amount out of cup range', 'النسبة لازم بين 1:5 و 1:25': 'Ratio must be between 1:5 and 1:25',
    'ما فيه ماء': 'No water', 'إعدادات المطحنة': 'Grinder settings',
    // welcome
    'قهوتك المختصة، بضغطة زر': 'Your specialty coffee, one tap away', 'ابدأ': 'Start',
    'أول مرة؟ بنربط الشاشة بمكينتك بخطوات بسيطة': "First time? We'll pair the screen with your machine in a few steps",
    'المكينة جاهزة': 'Machine ready', 'نتصل بالمكينة…': 'Connecting to machine…', 'المكينة غير متصلة': 'Machine offline',
    'خزان الماء ناقص — عبّه قبل التحضير': 'Water tank low — fill it before brewing',
    // setup
    'رجوع': 'Back', 'أهلاً بك': 'Welcome', 'خطوات بسيطة ونربط الشاشة بمكينتك': 'A few simple steps to pair the screen with your machine',
    '١. جهاز الجسر (ESP32)': '1. Bridge device (ESP32)',
    'هذي الشاشة ما فيها بلوتوث، فتكلّم المكينة عن طريق قطعة ESP32 صغيرة.': 'This screen has no Bluetooth, so it talks to the machine through a small ESP32 device.',
    'واي فاي الشاشة: ': 'Screen Wi-Fi: ', 'إعدادات الواي فاي': 'Wi-Fi settings',
    'وصّل القطعة بالكهرباء قريب من المكينة.': 'Plug the device into power near the machine.',
    'من جوالك ادخل شبكة الواي فاي ': 'From your phone, join the Wi-Fi network ', ' — تطلع صفحة.': ' — a page appears.',
    'اختر فيها شبكة البيت (نفس شبكة الشاشة) واكتب كلمة السر.': 'Pick your home network (same as the screen) and enter the password.',
    'ارجع هنا واضغط "دوّر على الجسر".': 'Come back here and tap "Find the bridge".',
    'دوّر على الجسر': 'Find the bridge',
    'لقيت أكثر من جسر — اختر اللي رقمه مكتوب على صفحة الإعداد في جوالك:': 'Found more than one bridge — pick the one whose number is shown on the setup page on your phone:',
    'جسر ': 'Bridge ', 'ما لقيته؟ اكتب عنوانه': "Didn't find it? Enter its address", 'مثل 192.168.1.50': 'e.g. 192.168.1.50', 'اتصل': 'Connect',
    'هذي الشاشة ما فيها بلوتوث — تحتاج جسر ESP32.': 'This screen has no Bluetooth — it needs an ESP32 bridge.',
    'البلوتوث مقفل — شغّله من إعدادات أندرويد.': 'Bluetooth is off — turn it on in Android settings.',
    'التطبيق يحتاج صلاحية الموقع/البلوتوث عشان يدوّر على المكينة.': 'The app needs location/Bluetooth permission to find the machine.',
    '٢. اختر مكينتك': '2. Pick your machine', '١. اختر مكينتك': '1. Pick your machine',
    'شغّل المكينة، وسكّر تطبيق xBloom في الجوال (المكينة تقبل اتصال واحد بس).': 'Turn on the machine and close the xBloom app on your phone (the machine accepts only one connection).',
    'رقم مكينتك: آخر ٦ حروف من الرقم التسلسلي — مكتوب تحت المكينة، وتلقاه في تطبيق xBloom.': 'Your machine number: the last 6 characters of the serial — printed under the machine and shown in the xBloom app.',
    'دوّر': 'Scan', 'تم الربط': 'Paired', 'الشاشة مربوطة بمكينة ': 'The screen is paired with machine ', 'يلا نحضّر': "Let's brew",
    'أدوّر على المكاين القريبة…': 'Scanning for nearby machines…', 'ما فيه مكينة بهذا الرقم قريبة.': 'No machine with that number nearby.', 'اضغط "دوّر".': 'Tap "Scan".',
    // settings
    'الإحصائيات': 'Statistics', 'أكواب اليوم': 'Cups today', 'الإجمالي': 'Total',
    'الحماية والتنبيهات': 'Protection & alerts', 'قفل الإعدادات برقم سري': 'Lock settings with a PIN',
    'تغيير الرقم': 'Change PIN', 'إزالة القفل': 'Remove lock', 'تعيين رقم سري': 'Set a PIN', 'صوت التنبيه عند الانتهاء': 'Alert sound when done',
    'جهاز الجسر (ESP32)': 'Bridge device (ESP32)', 'الجسر: ': 'Bridge: ', 'أو اكتب عنوانه، مثل 192.168.8.50': 'Or enter its address, e.g. 192.168.8.50',
    'الاتصال بالمكينة': 'Machine connection', 'هذي الشاشة ما فيها بلوتوث شغّال.': 'This screen has no working Bluetooth.',
    'ما وصلت لجهاز الجسر (ESP32) — تأكد إنه موصول بالكهرباء وعلى نفس شبكة الواي فاي.': "Couldn't reach the bridge (ESP32) — make sure it's plugged in and on the same Wi-Fi.",
    'المكينة: ': 'Machine: ', 'قطع الاتصال': 'Disconnect', 'دوّر على المكينة': 'Scan for the machine', 'ربط مكينة ثانية': 'Pair another machine',
    'المكينة تقبل اتصال واحد بس. إذا تبي تستخدم تطبيق الجوال، اقطع الاتصال من هنا أول.': 'The machine accepts only one connection. To use the phone app, disconnect here first.',
    'إعدادات المكينة': 'Machine settings', 'مصدر الماء': 'Water source', 'الخزان': 'Tank', 'الحنفية': 'Tap',
    'الوضع': 'Mode', 'وحدة الوزن': 'Weight unit', 'أونصة': 'Ounce', 'وحدة الحرارة': 'Temp unit', 'تصفير الميزان': 'Tare the scale',
    'الرقم التسلسلي: ': 'Serial: ', 'النسخة: ': 'Firmware: ', 'اللغة': 'Language',
    // guide
    'قبل ما نبدأ 👋': "Before we start 👋",
    'ركّب مصفاة الشاي': 'Fit the tea brewer', 'مكان القمع على المكينة.': 'In place of the dripper on the machine.',
    'حطّ الأوراق': 'Add the leaves', 'من ٣ إلى ٥ جرام في المصفاة.': '3 to 5 g in the brewer.',
    'الماء والكوب': 'Water and cup', 'الخزان مليان، والكوب على الميزان.': 'Tank full, cup on the scale.',
    'اختر وصفة 🍵 واضغط «حضّر»': 'Pick a 🍵 recipe and tap «Brew»', 'الأخضر ٨٠° والأسود ٩٥°. بالعافية!': 'Green 80°, black 95°. Enjoy!',
    'افتح الوصفة واضغط 🎯': 'Open the recipe and tap 🎯', 'تطلب الرقم السري، الميزة لك بس.': 'It asks for the PIN: it is yours only.',
    'اختر الطحنة أو الحرارة': 'Pick grind or temperature', 'شي واحد يتغيّر بين الأكواب.': 'One thing changes between cups.',
    '٣ أكواب صغيرة، وقيّم كل واحد': '3 small cups, rate each one', '١٠ جرام بن وكوب فاضي لكل كوب.': '10 g of coffee and an empty cup for each.',
    'احفظ الأحلى': 'Save the best', 'تنحفظ وصفة جديدة، والأصلية ما تتغيّر.': 'It saves as a new recipe; the original stays.',
    'جهّز الفلتر': 'Ready the filter', 'فلتر ورق في القمع، ورطّبه بماء حار.': 'Paper filter in the dripper, rinsed with hot water.',
    'حطّ البن': 'Add the coffee', 'حبوب في المطحنة، أو مطحون في الفلتر.': 'Beans in the grinder, or ground coffee in the filter.',
    'اختر وصفتك واضغط «حضّر»': 'Pick your recipe and tap «Brew»', 'وتابع التحضير على الشاشة. بالهناء!': 'Follow it on the screen. Enjoy!',
    'وصفة جديدة: «الوصفات» ← «وصفة جديدة».': 'New recipe: «Recipes» → «New recipe».',
    'المكينة غير متصلة؟ اقفل تطبيق xBloom في جوالك.': 'Machine offline? Close the xBloom app on your phone.',
    'أربع خطوات وتصير جاهز.': 'Four steps and you are ready.', 'خطوات': 'steps',
    'هذي طريقة تحضير القهوة بالمكينة خطوة بخطوة. تقدر ترجع لها أي وقت من تبويب «الشرح».': 'This is how to brew coffee step by step. You can come back to it any time from the «Guide» tab.',
    'فهمت، يلا نبدأ': "Got it, let's start", 'تخطّي': 'Skip',
    'كيف تسوّي قهوتك': 'How to make your coffee', 'خطوة بخطوة': 'Step by step', 'تلميحات': 'Tips',
    'حطّ الفلتر ورطّبه': 'Place the filter and rinse it',
    'حطّ فلتر الورق في القمع، وصبّ عليه ماء حار يبلّله كله. هذا يشيل طعم الورق ويسخّن الكوب. كبّ الماء اللي تجمّع تحت.': 'Put the paper filter in the dripper and pour hot water to wet it fully. This removes the paper taste and warms the cup. Discard the water collected below.',
    'وزن البن': 'Weigh the coffee',
    'لو تطحن في المكينة: حطّ حبّ البن في فتحة الطحن. لو عندك بن مطحون جاهز: حطّه مباشرة في الفلتر، واختر «بن مطحون» في الوصفة.': "If you grind in the machine: put the beans in the grinder opening. If you have pre-ground coffee: put it straight in the filter and pick «Pre-ground» in the recipe.",
    'الماء والكوب': 'Water and cup',
    'تأكّد إن خزان الماء مليان (تشوف حالته فوق في الشاشة). وحطّ الكوب تحت القمع على الميزان.': 'Make sure the water tank is full (its status shows at the top of the screen). Put the cup under the dripper on the scale.',
    'اختر الوصفة': 'Pick the recipe',
    'من «الوصفات» اختر وصفتك، وتشوف تفاصيلها: كمية البن، النسبة، الحرارة، وكل دفعة.': 'From «Recipes» pick your recipe and see its details: coffee amount, ratio, temperature and each pour.',
    'اضغط «حضّر الحين»': 'Tap «Brew now»',
    'المكينة تطحن (لو مفعّل الطحن)، وبعدها تصبّ الماء على دفعات. تابع الدائرة والوقت والوزن في الشاشة.': 'The machine grinds (if grinding is on), then pours water in stages. Follow the ring, the time and the weight on screen.',
    'أول ما تخلص تطلع «قهوتك جاهزة». اضغط «تمام» وارجع للوصفات. بالهناء ☕': 'When it finishes you see «Your coffee is ready». Tap «Done» and go back to the recipes. Enjoy ☕',
    'لإنشاء وصفة جديدة: بوّب «وصفة جديدة» وعدّل كمية البن والنسبة وكل دفعة.': 'To create a new recipe: open «New recipe» and adjust the coffee amount, the ratio and each pour.',
    'لحفظ وصفة في أزرار المكينة A/B/C: افتح الوصفة واضغط «زر بالمكينة».': 'To save a recipe to the machine buttons A/B/C: open the recipe and tap «Machine button».',
    'لو المكينة «غير متصلة»: تأكد إنها مشغّلة وقريبة، واقفل تطبيق xBloom في جوالك (تقبل اتصال واحد بس).': 'If the machine is «Offline»: make sure it is on and nearby, and close the xBloom app on your phone (it accepts only one connection).',
    // diag
    'تشخيص (أرقام المكينة الخام)': 'Diagnostics (raw machine numbers)',
    'سوِّ تحضير والأرقام تتعبّى هنا. العمود الأول القيمة كفلوت، والثاني كعدد صحيح.': 'Run a brew and the numbers fill in here. The first column is the float value, the second is the integer.',
    'النوع': 'Type', 'ماء': 'Water', 'وزن': 'Weight', 'تحديث': 'Refresh',
    // share / receive
    'شارك «': 'Share «', 'وجّه كاميرا جهاز ثاني (يشغّل الساقي) على الباركود، واضغط «استلام وصفة» فيه.': 'Point another device (running Al-Saqi) camera at the barcode and tap «Receive recipe» on it.',
    'تعذّر إنشاء الباركود': "Couldn't create the barcode", 'استلام وصفة': 'Receive recipe',
    'وجّه الكاميرا على باركود الوصفة…': 'Point the camera at the recipe barcode…',
    'ما سمحت للكاميرا. فعّلها من إعدادات التطبيق وحاول ثانية.': "Camera wasn't allowed. Enable it in the app settings and try again.",
    'ما فيه كاميرا تشتغل على هذا الجهاز.': 'No working camera on this device.', 'انحفظت وصفة «': 'Saved recipe «',
    // toasts / confirms / prompts
    'انشال القفل': 'Lock removed', 'تم تعيين الرقم السري': 'PIN set', 'رقم غلط': 'Wrong PIN', 'الرقمان ما تطابقا': "The two PINs didn't match",
    'إزالة القفل عن الإعدادات؟': 'Remove the settings lock?', 'أضفنا «': 'Added «',
    'اكتب اسم للوصفة': 'Enter a recipe name', 'انحفظت': 'Saved', 'الوصفة فيها مشكلة — عدّلها أول': 'The recipe has a problem — edit it first',
    'أي زر بالمكينة؟ اكتب A أو B أو C': 'Which machine button? Enter A, B or C', 'اكتب A أو B أو C': 'Enter A, B or C',
    'انحفظت في زر ': 'Saved to button ', ' — تقدر تشغلها من المكينة بوضع Auto': ' — you can run it from the machine in Auto mode',
    'توقف التحضير؟': 'Stop brewing?', 'تحذف "': 'Delete "', '"؟': '"?', 'تربط الشاشة بمكينة ثانية؟': 'Pair the screen with another machine?',
    'أدوّر على الجسر…': 'Looking for the bridge…', 'لقيت الجسر ': 'Found bridge ', 'لقيت ': 'Found ', ' — اختر جسرك': ' — pick your bridge',
    'ما لقيته — تأكد إنه على نفس الشبكة': "Didn't find it — make sure it's on the same network", 'أتصل بالجسر…': 'Connecting to the bridge…',
    'ما قدرت أتصل — قرّب الشاشة/الجسر من المكينة وجرّب ثانية': "Couldn't connect — move the screen/bridge closer to the machine and try again",
    'اتصلت بالمكينة': 'Connected to the machine', 'الجسر مو متصل': 'Bridge not connected', 'البلوتوث مو جاهز': 'Bluetooth not ready',
    'تم تصفير الميزان': 'Scale tared', 'صار خطأ': 'An error occurred', 'إعدادات أندرويد (على الشاشة فقط)': 'Android settings (on the screen only)',
    // PIN lock
    'الإعدادات مقفلة': 'Settings locked', 'أعد كتابة الرقم': 'Re-enter the PIN', 'اختر رقمًا سريًا': 'Choose a PIN',
    'ادخل الرقم السري لفتح الإعدادات': 'Enter the PIN to open settings', 'أربعة أرقام': 'Four digits',
    // brew controls, units, punctuation, misc
    'تمام': 'Done', 'ترجع الشاشة للبداية بعد': 'Back to the start screen in', 'كمّل': 'Resume', 'إيقاف مؤقت': 'Pause', 'مل/ث': 'ml/s', '، ': ', ', '→ رجوع': '← Back',
    'وصفة مشاركة': 'Shared recipe', 'الوصفة كبيرة على الباركود': 'The recipe is too big for a barcode',
    // update errors
    'تاريخ ووقت الشاشة غلط — عدّلهم من إعدادات أندرويد': "The screen's date and time are wrong — fix them in Android settings",
    'مشكلة في شهادة الأمان مع سيرفر التحديثات': 'Security certificate problem with the update server',
    'ما فيه إنترنت — تأكد إن الواي فاي متصل بالنت': 'No internet — make sure the Wi-Fi has internet access',
    'ما لقينا التحديث على السيرفر': "Couldn't find the update on the server",
    'ملف التحديث وصل ناقص — جرّب مرة ثانية': 'The update file arrived incomplete — try again',
    'ما قدرنا نتحقق من التحديثات': "Couldn't check for updates",
    // dose limits
    'كبسولة xPod كميتها ثابتة 15 جم': 'An xPod capsule is fixed at 15 g',
    'كوب Omni يتحمّل لين 18 جم. تبي أكثر؟': 'The Omni cup holds up to 18 g. Need more?',
    'حوّله لكوب «آخر» (لين 25 جم)': 'Switch to the «Other» cup (up to 25 g)',
    // tea throughout
    'قهوتك وشايك، بضغطة زر': 'Your coffee and tea, one tap away',
    'ينقع الشاي': 'Steeping the tea', 'شايك جاهز 🍵': 'Your tea is ready 🍵', 'شايك جاهز': 'Your tea is ready',
    'كيف تسوّي شايك': 'How to make your tea',
    'هذي طريقة التحضير بالمكينة خطوة بخطوة — للقهوة وللشاي. تقدر ترجع لها أي وقت من تبويب «الشرح».': 'This is how to brew step by step — for coffee and for tea. You can come back to it any time from the «Guide» tab.',
    'ركّب مصفاة الشاي': 'Fit the tea brewer',
    'حطّ مصفاة الشاي (Omni Tea Brewer) مكان القمع على المكينة.': 'Put the tea brewer (Omni Tea Brewer) in place of the dripper on the machine.',
    'حطّ أوراق الشاي': 'Add the tea leaves',
    'حطّ من ٣ إلى ٥ جرام أوراق شاي في المصفاة (تقريباً ملعقة إلى ملعقتين). المطحنة ما تشتغل مع الشاي.': 'Put 3 to 5 g of tea leaves in the brewer (about one to two spoons). The grinder is not used for tea.',
    'تأكّد إن خزان الماء مليان (تشوف حالته فوق في الشاشة). وحطّ الكوب تحت المصفاة على الميزان.': 'Make sure the water tank is full (its status shows at the top of the screen). Put the cup under the brewer on the scale.',
    'اختر وصفة شاي 🍵': 'Pick a tea recipe 🍵',
    'وصفات الشاي عليها 🍵. لو ما عندك، أضف وحدة من «المكتبة» ← قسم الشاي. كل نوع له حرارته: الأخضر ٨٠°، والأسود ٩٥°.': 'Tea recipes are marked 🍵. If you have none, add one from «Library» → Tea. Each kind has its temperature: green 80°, black 95°.',
    'المكينة تصبّ الماء على الأوراق بالحرارة اللي في الوصفة، ينقع، وبعدين ينزل الشاي للكوب. لو الوصفة فيها أكثر من نقعة، تتكرر.': "The machine pours water over the leaves at the recipe's temperature, it steeps, then the tea drains into the cup. If the recipe has more than one steep, it repeats.",
    'أول ما تخلص تطلع «شايك جاهز». اضغط «تمام» وارجع للوصفات. بالعافية 🍵': 'When it finishes you see «Your tea is ready». Tap «Done» and go back to the recipes. Enjoy 🍵',
    'لوصفة شاي جديدة: «وصفة جديدة» ← نوع المشروب «شاي 🍵» — أو أضف جاهزة من «المكتبة».': 'For a new tea recipe: «New recipe» → Drink type «Tea 🍵» — or add a ready one from «Library».',
    // add from your phone
    ' من جوالك': ' From your phone', 'أضف وصفة من جوالك': 'Add a recipe from your phone',
    'الشاشة مو متصلة بالواي فاي — وصّلها بنفس شبكة جوالك وجرّب ثانية': "The screen isn't on Wi-Fi — connect it to the same network as your phone and try again",
    'ما قدرنا نفتح الاستقبال — جرّب مرة ثانية': "Couldn't start receiving — try again",
    'جرّب مرة ثانية': 'Try again', 'انتهت مدة الباركود.': 'The barcode has expired.', 'باركود جديد': 'New barcode',
    'خلّ جوالك على ': 'Put your phone on ', 'نفس الواي فاي': 'the same Wi-Fi', ' اللي عليه الشاشة.': ' as the screen.',
    'صوّر الباركود بكاميرا الجوال، وافتح الرابط.': "Scan the barcode with your phone's camera and open the link.",
    'الصق رابط وصفة من تطبيق xBloom، أو اكتب وصفتك، واضغط «أرسل للبرواز».': 'Paste a recipe link from the xBloom app, or type your recipe, and tap «Send to the frame».',
    'الباركود يشتغل ': 'The barcode works for ', ' دقيقة.': ' minutes.', 'وصلت: ': 'Received: ',
    'وصلت وصفة «': 'Received recipe «', '» من الجوال': '» from the phone',
    // taste helper
    'كيف طعم القهوة؟': 'How did the coffee taste?', 'كيف الشاي؟': 'How was the tea?',
    '😋 ممتازة': '😋 Great', '😋 ممتاز': '😋 Great', 'حامضة': 'Sour', 'مرّة': 'Bitter', 'خفيفة': 'Weak', 'ثقيلة': 'Strong',
    'مرّ / قابض': 'Bitter / astringent', 'ممتاز': 'great', 'حامض': 'sour', 'مرّ': 'bitter', 'خفيف': 'weak', 'ثقيل': 'strong',
    'بالهناء! انحفظ رأيك في السجل.': 'Enjoy! Your rating is saved in the log.',
    'عدّلنا الوصفة — جرّبها المرة الجاية.': "Recipe updated — try it next time.",
    'ما عندنا اقتراح لهالوصفة — جرّب تعدّلها من «تعديل».': 'No suggestion for this recipe — try adjusting it from «Edit».',
    'جرّب المرة الجاية: ': 'Next time, try: ', 'طبّق على الوصفة': 'Apply to the recipe', 'لا، شكرًا': 'No, thanks',
    ' (أنعم)': ' (finer)', ' (أخشن)': ' (coarser)',
    'ما نقدر نطبّقه — يطلع برا حدود المكينة': "Can't apply it — it goes past the machine's limits", 'عدّلنا «': 'Updated «',
    // history
    'سجل التحضير': 'Brew log', ' السجل': ' Log', 'اليوم': 'Today', 'أمس': 'Yesterday', 'هالأسبوع': 'This week',
    'الأكثر هالأسبوع: ': 'Most brewed this week: ', 'انلغى': 'cancelled', 'ما اكتمل': 'incomplete',
    'ما فيه تحضير للحين — أول كوب بيطلع هنا.': 'No brews yet — your first cup will show up here.',
    // cleaning
    'حان وقت تنظيف المكينة — الخطوات في الإعدادات': 'Time to clean the machine — steps are in Settings',
    'حان وقت تنظيف المكينة': 'Time to clean the machine', 'حان وقت التنظيف': 'Time to clean', 'تنظيف المكينة': 'Machine cleaning',
    'آخر تنظيف: ': 'Last cleaned: ', ' كوب من بعده': ' cups since',
    'اغسل القمع ومصفاة الشاي وصينية الميزان بماء دافي.': 'Wash the dripper, the tea brewer and the scale tray in warm water.',
    'فرّغ خزان الماء واغسله، وعبّه بماء جديد.': 'Empty and wash the water tank, then refill it with fresh water.',
    'نظّف فتحة المطحنة من بقايا البن بفرشاة ناشفة.': 'Brush coffee residue out of the grinder opening with a dry brush.',
    "إزالة الترسبات: اتبع طريقة xBloom في دليل المكينة أو تطبيقهم.": "Descaling: follow xBloom's method in the machine manual or their app.",
    'مساعد الطعم بعد التحضير': 'Taste helper after brewing', 'مساعد الطعم': 'Taste helper', '🔒 قيّم الطعم': '🔒 Rate the taste',
    'لصاحب الشاشة — يحتاج الرقم السري': "For the screen's owner — needs the PIN",
    'ادخل الرقم السري — المساعد لصاحب الشاشة بس': "Enter the PIN — the helper is for the screen's owner only",
    '🔒 لي بس': '🔒 Only me', 'مقفول': 'Off', 'يشتغل بعد ما تعيّن رقم سري.': 'Works once you set a PIN.',
    // dial in a new bean
    '🎯 الضبط التلقائي': '🎯 Dial-in', 'ادخل الرقم السري — الضبط لصاحب الشاشة بس': "Enter the PIN — dial-in is for the screen's owner only",
    'اضبط': 'Dial in', '🎯 ضبط «': '🎯 Dial in «',
    'نحضّر ٣ أكواب شاي بنفس الوصفة، كل واحد بحرارة مختلفة، وتختار الأحلى.': "We'll brew 3 cups of tea from this recipe, each at a different temperature, and you pick the best.",
    'نحضّر ٣ أكواب صغيرة بنفس الوصفة والنسبة، كل واحد بطحنة مختلفة، وتختار الأحلى.': "We'll brew 3 small cups with the same recipe and ratio, each at a different grind, and you pick the best.",
    'البن مطحون، فنجرّب ٣ درجات حرارة بدل الطحنة، وتختار الأحلى.': "The coffee is pre-ground, so we'll try 3 temperatures instead of grinds, and you pick the best.",
    'اسم البن (اختياري)': 'Bean name (optional)', 'إثيوبي غوجي': 'Ethiopia Guji',
    'كل كوب تجريبي يحتاج ': 'Each test cup needs ', ' بن.': ' of coffee.', 'يلا نبدأ': "Let's start",
    'الكوب ': 'Cup ', 'حضّر الكوب ': 'Brew cup ', 'كيف كان الكوب ': 'How was cup ', '؟': '?',
    'حطّ ': 'Put ', ' جم أوراق شاي في المصفاة.': ' g of tea leaves in the brewer.',
    ' جم بن في المطحنة.': ' g of beans in the grinder.', ' جم بن في الفلتر.': ' g of coffee in the filter.',
    'حطّ كوب فاضي على الميزان.': 'Put an empty cup on the scale.',
    'ما ضبط التحضير — أعيد الكوب': "The brew didn't work — redo this cup",
    'الأحلى: ': 'Best: ', 'احفظها وصفة': 'Save as a recipe', 'جولة ثانية حول الأحلى': 'Another round around the best',
    'الكوب التجريبي يطلع برا حدود المكينة': "The test cup goes past the machine's limits",
    'ما قدرنا نحفظها — برا حدود المكينة': "Couldn't save it — past the machine's limits",
    'توقف الضبط؟ بتضيع التقييمات.': 'Stop dialing in? Your ratings will be lost.', 'انحفظت «': 'Saved «',
    'نحضّر ٣ أكواب صغيرة بنفس الوصفة والنسبة، كل واحد يختلف في شي واحد، وتختار الأحلى.': "We'll brew 3 small cups with the same recipe and ratio, each differing in one thing, and you pick the best.",
    'كل كوب لحاله: المكينة تحضّر كوب واحد وتوقف.': 'One cup at a time: the machine brews one cup and stops.',
    'تذوّقه وقيّمه، بعدين حطّ بن جديد وكوب فاضي واضغط «حضّر الكوب» اللي بعده.': 'Taste and rate it, then add fresh coffee and an empty cup and tap «Brew cup» for the next one.',
    'نغيّر شي واحد بس بين الأكواب، عشان تعرف وش اللي فرق في الطعم.': 'Only one thing changes between cups, so you know what made the difference.',
    'وش نجرّب؟': 'What do we try?', '🎯 الضبط': '🎯 Dial-in', 'كيف تضبط بن جديد': 'How to dial in a new bean',
    'افتح الوصفة واضغط «🎯 اضبط»': 'Open the recipe and tap «🎯 Dial in»',
    'الميزة لصاحب الشاشة بس: تطلب الرقم السري. اختر الوصفة اللي تبي تضبطها للبن الجديد.': "For the screen's owner only: it asks for the PIN. Pick the recipe you want to tune for the new bean.",
    'اختر وش تجرّب': 'Choose what to try',
    'الطحنة أو الحرارة — شي واحد بس، عشان تعرف وش اللي فرق. للشاي والبن المطحون نجرّب الحرارة. واكتب اسم البن لو تبي.': 'Grind or temperature — just one, so you know what made the difference. Tea and pre-ground coffee try temperature. Add the bean name if you like.',
    'الكوب الأول': 'The first cup',
    'حطّ ١٠ جرام بن وكوب فاضي على الميزان، واضغط «حضّر الكوب 1». المكينة تحضّر كوب صغير واحد وتوقف.': 'Add 10 g of coffee and an empty cup on the scale, and tap «Brew cup 1». The machine brews one small cup and stops.',
    'تذوّق وقيّم': 'Taste and rate',
    'اختر 😖 أو 😐 أو 🙂 أو 😋. لو صار شي في التحضير، اضغط «أعيد الكوب».': 'Pick 😖, 😐, 🙂 or 😋. If something went wrong in the brew, tap «redo this cup».',
    'الكوب الثاني والثالث': 'The second and third cups',
    'كل مرة: بن جديد وكوب فاضي، وبعدين «حضّر الكوب». نفس الوصفة، يتغيّر بس اللي اخترته.': 'Each time: fresh coffee and an empty cup, then «Brew cup». Same recipe — only what you chose changes.',
    'احفظ الأحلى': 'Save the best',
    '«احفظها وصفة» تسوّي وصفة جديدة بالكمية الكاملة — وصفتك الأصلية ما تتغيّر. أو «جولة ثانية» بفروق أدق حول الأحلى.': '«Save as a recipe» makes a new full-size recipe — your original stays as it is. Or «Another round» with finer steps around the best.',
    'الإصدار: ': 'Version: ', 'يتوفر تحديث': 'Update available',
    'قبل ما نبدأ': 'Before we start', 'اختر وصفة شاي واضغط «حضّر»': 'Pick a tea recipe and tap «Brew»',
    'افتح الوصفة واضغط «اضبط»': 'Open the recipe and tap «Dial in»', 'الضبط': 'Dial-in', 'الضبط التلقائي': 'Dial-in',
    'ضبط': 'Dial in', 'ممتازة': 'Great', 'قيّم الطعم': 'Rate the taste', 'لي بس': 'Only me',
    'تجهيز': 'Getting ready:', 'خطوتين اختيارية قبل الكوب، وتقدر تتخطاها.': 'Two optional steps before the cup — skip them if you like.',
    'وزّن البن': 'Weigh the beans', 'وزّن الشاي': 'Weigh the tea',
    'حط وعاء فاضي على الميزان، صفّره، وحط البن لين يوصل الرقم. بعدها صبّه في المطحنة.': 'Put an empty bowl on the scale, tare it, and add beans until you reach the number. Then pour them into the grinder.',
    'حط وعاء فاضي على الميزان، صفّره، وحط الشاي لين يوصل الرقم.': 'Put an empty bowl on the scale, tare it, and add tea until you reach the number.',
    'حط الوعاء على الميزان': 'Put the bowl on the scale', 'تمام، الوزن مضبوط': 'Spot on', 'باقي': 'Add', 'زايد': 'Over by',
    'صفّر الميزان': 'Tare the scale', 'رطّب الفلتر': 'Rinse the filter', 'سخّن المصفاة': 'Warm the strainer',
    'فلتر الورق في القمع بدون بن، والسيرفر تحته. المكينة تصب ': 'Paper filter in the dripper, no coffee, server underneath. The machine pours circularly ',
    'المصفاة فاضية والكوب تحتها. المكينة تصب ': 'Strainer empty, cup underneath. The machine pours ',
    'مل ماء حار.': 'ml of hot water.', 'رطّب الحين': 'Rinse now', 'سخّن الحين': 'Warm it now', 'مرة ثانية': 'Again',
    'تم الترطيب — كبّ الماء ورجّع السيرفر.': 'Rinsed — tip the water out and put the server back.',
    'تسخّنت المصفاة — كبّ الماء ورجّع الكوب.': 'Warmed — tip the water out and put the cup back.',
    'من': 'of', 'ابدأ التحضير': 'Start brewing', 'إيقاف': 'Stop', 'ترطيب الفلتر': 'Filter rinse', 'تسخين المصفاة': 'Strainer warm-up', 'مل من': 'ml of',
    'ذكّرني كل': 'Remind me every', 'نظّفتها الحين': 'I cleaned it now', 'تمام — بنذكّرك المرة الجاية': "Done — we'll remind you next time"
  };
  var PH = null;
  function phrases() {
    if (PH) return PH;
    PH = []; for (var k in DICT) if (DICT.hasOwnProperty(k)) PH.push([k, DICT[k]]);
    PH.sort(function (a, b) { return b[0].length - a[0].length; });
    return PH;
  }
  // Translate a string built in code (toast / confirm / prompt / brew bits).
  function L(s) {
    if (curLang() !== 'en' || s == null) return s;
    s = String(s);
    if (EXACT.hasOwnProperty(s)) return EXACT[s];
    var out = s, p = phrases();
    for (var i = 0; i < p.length; i++) if (out.indexOf(p[i][0]) >= 0) out = out.split(p[i][0]).join(p[i][1]);
    return out;
  }
  var AR_RE = /[؀-ۿ]/;
  function trTextNode(t) {
    var v = t.nodeValue;
    if (!v || !AR_RE.test(v)) return;
    var nv = EXACT.hasOwnProperty(v) ? EXACT[v] : L(v);
    if (nv !== v) t.nodeValue = nv;
  }
  // Rewrite all Arabic text (and Arabic placeholders) under a node to English.
  function translateTree(root) {
    if (curLang() !== 'en' || !root || !root.querySelectorAll) return;
    try {
      var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false), n, list = [];
      while ((n = w.nextNode())) list.push(n);
      for (var i = 0; i < list.length; i++) trTextNode(list[i]);
      Array.prototype.forEach.call(root.querySelectorAll('[placeholder]'), function (el) {
        var v = el.getAttribute('placeholder'); if (v && AR_RE.test(v)) el.setAttribute('placeholder', L(v));
      });
    } catch (e) { /* */ }
  }
  function applyLangChrome() {
    var en = curLang() === 'en';
    try {
      document.documentElement.setAttribute('lang', en ? 'en' : 'ar');
      document.documentElement.setAttribute('dir', en ? 'ltr' : 'rtl');
      document.documentElement.className = en ? 'lang-en' : '';
    } catch (e) { /* */ }
  }
  var langObs = null;
  // Whole body: the view, the header, the tabs and the update banner (#ota).
  function observeLang() {
    if (langObs) langObs.observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  // Static HTML (the tab labels) is never re-rendered, so keep its Arabic to
  // put back when switching from English to Arabic.
  function markStatic() {
    Array.prototype.forEach.call(document.querySelectorAll('.tabs button > span:last-child'), function (s) {
      if (!s.getAttribute('data-ar')) s.setAttribute('data-ar', s.textContent);
    });
  }
  function restoreStatic() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-ar]'), function (el) { el.textContent = el.getAttribute('data-ar'); });
  }
  function startLangObserver() {
    markStatic();
    applyLangChrome();
    if (langObs || !window.MutationObserver) return;
    langObs = new MutationObserver(function (muts) {
      if (curLang() !== 'en') return;
      langObs.disconnect();
      for (var i = 0; i < muts.length; i++) {
        var mm = muts[i];
        if (mm.type === 'characterData') { if (mm.target && mm.target.nodeType === 3) trTextNode(mm.target); }
        else for (var j = 0; j < mm.addedNodes.length; j++) {
          var a = mm.addedNodes[j];
          if (a.nodeType === 3) trTextNode(a);
          else if (a.nodeType === 1) translateTree(a);
        }
      }
      observeLang();
    });
    observeLang();
  }
  function setLang(l) {
    try { localStorage.setItem('xb.lang', l === 'en' ? 'en' : 'ar'); } catch (e) { /* */ }
    applyLangChrome();
    restoreStatic();
    OTA.relang();
    renderBar(); render(); OTA.refresh();
    translateTree(document.body);
  }

  // Line icons, 24x24, drawn in the current text colour.
  var ICONS = {
    cup: '<path d="M4 9h13v4a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z"/><path d="M17 10.5h1.5a2.5 2.5 0 0 1 0 5H17"/><path d="M8 3.5c0 1 1 1.3 1 2.5M12 3.5c0 1 1 1.3 1 2.5"/><path d="M5 21h11"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    sliders: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13 7l4 4"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="3"/><path d="M16 4H7a3 3 0 0 0-3 3v9"/>',
    slot: '<path d="M12 4v10M7.5 9.5L12 14l4.5-4.5"/><path d="M5 15v2a3 3 0 0 0 3 3h8a3 3 0 0 0 3-3v-2"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M9 7V4.5h6V7M6 7l1 13h10l1-13"/>',
    drop: '<path d="M12 3.5s6 6.8 6 10.8a6 6 0 0 1-12 0C6 10.3 12 3.5 12 3.5z"/>',
    scale: '<rect x="3.5" y="10" width="17" height="10" rx="3"/><path d="M8 10a4 4 0 0 1 8 0"/><path d="M12 13.5v2"/>',
    play: '<path d="M8 5.5v13l11-6.5z"/>',
    pause: '<path d="M9 6v12M15 6v12"/>',
    stop: '<rect x="6.5" y="6.5" width="11" height="11" rx="2"/>',
    check: '<circle cx="12" cy="12" r="9.5"/><path d="M7.5 12.5l3 3 6-6.5"/>',
    wifi: '<path d="M3.5 9.5a12 12 0 0 1 17 0M6.5 12.5a8 8 0 0 1 11 0M9.5 15.5a4 4 0 0 1 5 0"/><circle cx="12" cy="18.5" r="1"/>',
    alert: '<path d="M12 4L2.8 19.5h18.4z"/><path d="M12 10v4.5M12 17v.01"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    book: '<path d="M5 4h9a2 2 0 0 1 2 2v14H7a2 2 0 0 0-2 2z"/><path d="M19 4v16"/><path d="M9 8h4M9 11h4"/>',
    filter: '<path d="M6 5h12l-4.5 6v6l-3 1.5v-7.5z"/>',
    beans: '<ellipse cx="9.5" cy="10" rx="4" ry="5.5" transform="rotate(-25 9.5 10)"/><path d="M8 6.5c1.5 1.5 1.5 5.5 0 7"/><ellipse cx="15" cy="14.5" rx="3.5" ry="5" transform="rotate(-25 15 14.5)"/>',
    tap: '<path d="M9 11.5V6a3 3 0 0 1 6 0v.5"/><rect x="5.5" y="11.5" width="13" height="4" rx="1.5"/><path d="M9 15.5v2a3 3 0 0 0 6 0v-2"/><circle cx="12" cy="21" r="0.8"/>',
    pour: '<path d="M4 7h10v3a5 5 0 0 1-10 0z"/><path d="M14 8h3l2 3-2 1"/><path d="M8 15v3M11 15v4"/>',
    share: '<rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><path d="M14 14h2v2M18 14v0M14 18h0M18 18h2v-2M16 20h0"/>',
    scan: '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M4 12h16"/>',
    download: '<path d="M12 4v10"/><path d="M8 10l4 4 4-4"/><path d="M5 18h14"/>',
    phone: '<rect x="7" y="3" width="10" height="18" rx="2.5"/><path d="M11 18h2"/>',
    lock: '<rect x="5" y="11" width="14" height="9.5" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/><path d="M12 15v2"/>',
    tea: '<path d="M4 10.5h13v2.5a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z"/><path d="M17 11.5h1.5a2.3 2.3 0 0 1 0 4.6H17"/><path d="M8.5 8c0-2.8 2.2-4.5 5-4.5 0 2.8-2.2 4.5-5 4.5zM8.5 8l2.5-2.5"/><path d="M5 21h11"/>',
    target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><path d="M12 12h.01"/><path d="M12 1.5v3M12 19.5v3M1.5 12h3M19.5 12h3"/>',
    star: '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.8l-5.2 2.8 1-5.8-4.3-4.1 5.9-.9z"/>',
    close: '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
    face1: '<circle cx="12" cy="12" r="9.5"/><path d="M7.5 8.5l2.5 1.2M16.5 8.5L14 9.7"/><path d="M9 11.5v.5M15 11.5v.5"/><path d="M8.5 16.8c2-1.8 5-1.8 7 0"/>',
    face2: '<circle cx="12" cy="12" r="9.5"/><path d="M9 10v.5M15 10v.5"/><path d="M8.5 15.5h7"/>',
    face3: '<circle cx="12" cy="12" r="9.5"/><path d="M9 10v.5M15 10v.5"/><path d="M8 14c2 2.6 6 2.6 8 0"/>',
    face4: '<circle cx="12" cy="12" r="9.5"/><path d="M7.5 10.2c.8-1.3 2.2-1.3 3 0M13.5 10.2c.8-1.3 2.2-1.3 3 0"/><path d="M7.5 13.5h9c-.5 3-2.3 4.3-4.5 4.3s-4-1.3-4.5-4.3z"/>'
  };
  function icon(name, cls) {
    return '<span class="ic' + (cls ? ' ' + cls : '') + '"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round">' + (ICONS[name] || '') + '</svg></span>';
  }
  function pourLabel(r, i) {
    if (isTea(r)) return 'نقعة ' + (i + 1); // tea has steeps, not a bloom + pours
    return i === 0 && r.pours.length > 1 ? 'تشريب' : 'دفعة ' + (i + 1);
  }

  var toastTimer;
  function toast(msg, bad) {
    var t = document.getElementById('toast');
    t.textContent = L(msg); t.className = 'show' + (bad ? ' bad' : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.className = ''; }, 3500);
  }

  // ------------------------------------------------------------- OTA updates
  // The screen checks a fixed server for a newer web layer (or, rarely, a new
  // APK) through the native XBOTA bridge. Updates are OPT-IN: a banner shows
  // what is new with «تحديث الآن» / «لاحقًا», and Settings always has an entry
  // to update later. The native side downloads, verifies and swaps; this just
  // decides what to offer and shows progress.
  var WEB_VERSION = WEB_BUILD; // shown in a plain browser (no native bridge)
  var OTA = (function () {
    var bridge = window.XBOTA || null;
    var manifest = null, pending = null, dismissed = false, busy = false, lastPct = 0, manual = false, lastErr = '';

    // Say what actually went wrong, from the native exception text — "check
    // the internet" is wrong when the real cause is the clock or a certificate.
    function reasonOf(msg, stage) {
      var m = String(msg || '');
      if (/not yet valid|expired|timestamp check failed/i.test(m)) return 'تاريخ ووقت الشاشة غلط — عدّلهم من إعدادات أندرويد';
      if (/trust anchor|certif|SSL|handshake/i.test(m)) return 'مشكلة في شهادة الأمان مع سيرفر التحديثات';
      if (/UnknownHost|resolve host|ConnectException|timed? ?out|unreachable|ENETUNREACH|No route/i.test(m)) return 'ما فيه إنترنت — تأكد إن الواي فاي متصل بالنت';
      if (/http 404/.test(m)) return 'ما لقينا التحديث على السيرفر';
      if (/checksum/.test(m)) return 'ملف التحديث وصل ناقص — جرّب مرة ثانية';
      return stage === 'check' ? 'ما قدرنا نتحقق من التحديثات' : 'ما نجح التحديث — جرّب لاحقًا';
    }

    function present() { return !!bridge; }
    function curWeb() { try { return bridge ? bridge.version() : WEB_VERSION; } catch (e) { return WEB_VERSION; } }
    function curApp() { try { return bridge ? bridge.appVersion() : 0; } catch (e) { return 0; } }
    // manual=true when the user tapped «تحقق» — then we report failures; the
    // automatic background check at startup stays silent (e.g. no internet yet).
    function check(isManual) { manual = !!isManual; if (bridge) { try { bridge.check(); } catch (e) { /* offline */ } } }

    // Prefer a web update (instant, silent swap); fall back to an APK update
    // (needs one tap from the user) only when the native version is behind.
    // What's new, in the screen's language: title/notes are Arabic (what older
    // screens read), title_en/notes_en the English. English falls back to Arabic.
    function text(o, key) { return (curLang() === 'en' && o[key + '_en']) || o[key]; }

    function decide() {
      if (!manifest) return null;
      var w = manifest.web, a = manifest.apk;
      if (w && typeof w.version === 'number' && w.version > curWeb() && w.url)
        return { kind: 'web', version: w.version, label: w.label || '', title: text(w, 'title') || ('تحديث ' + (w.label || w.version)), notes: text(w, 'notes') || [], url: w.url, sha256: w.sha256 || '' };
      if (a && typeof a.version === 'number' && a.version > curApp() && a.url)
        return { kind: 'apk', version: a.version, title: text(a, 'title') || ('تحديث ' + a.version), notes: text(a, 'notes') || [], url: a.url, sha256: a.sha256 || '' };
      return null;
    }

    function box() {
      var el = document.getElementById('ota');
      if (!el) { el = document.createElement('div'); el.id = 'ota'; document.body.appendChild(el); }
      return el;
    }
    function hide() { var el = box(); el.innerHTML = ''; el.className = ''; }

    function canShow() {
      return pending && !dismissed && !busy && view !== 'edit' && !(link && link.isBrewing && link.isBrewing());
    }

    function renderBanner() {
      if (busy) return; // the progress UI owns the box while applying
      if (!canShow()) { hide(); return; }
      var notes = (pending.notes || []).map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('');
      box().className = 'show';
      box().innerHTML = '<div class="ota-card"><div class="ota-h">' + icon('download') +
        '<div class="ota-t"><b>تحديث جديد متوفر' + (pending.label ? ' · ' + esc(pending.label) : '') + '</b><small>' + esc(pending.title) +
        (pending.kind === 'apk' ? ' · تحديث النظام' : '') + '</small></div>' +
        '<button class="ota-x" data-act="otalater">' + icon('close') + '</button></div>' +
        (notes ? '<ul class="ota-notes">' + notes + '</ul>' : '') +
        '<div class="ota-btns"><button class="primary" data-act="otaapply">' + icon('download') + 'تحديث الآن</button>' +
        '<button class="ghost" data-act="otalater">لاحقًا</button></div></div>';
    }

    function renderProgress(pct, apk) {
      busy = true;
      box().className = 'show';
      box().innerHTML = '<div class="ota-card"><div class="ota-h">' + icon('download') +
        '<div class="ota-t"><b>' + (apk ? 'يُنزّل تحديث النظام…' : 'يُحدّث الآن…') + '</b>' +
        '<small>' + (apk ? 'بعد التنزيل اضغط «تثبيت»' : 'لا تطفئ الشاشة') + '</small></div></div>' +
        '<div class="ota-bar"><i style="width:' + Math.max(5, Math.min(100, pct)) + '%"></i></div></div>';
    }

    function apply() {
      if (!pending || !bridge) return;
      busy = true; lastPct = 5;
      renderProgress(5, pending.kind === 'apk');
      try {
        if (pending.kind === 'apk') bridge.applyApk(pending.url, pending.sha256);
        else bridge.applyWeb(pending.url, pending.sha256, pending.version);
      } catch (e) { busy = false; toast('تعذّر بدء التحديث', true); renderBanner(); }
    }

    function later() { dismissed = true; hide(); }

    function onEvent(ev, json) {
      var data = {};
      try { data = JSON.parse(json); } catch (e) { /* non-JSON */ }
      if (ev === 'manifest') {
        try { manifest = JSON.parse(json); } catch (e) { manifest = null; }
        lastErr = '';
        pending = decide();
        if (!busy) renderBanner();
        if (view === 'settings') renderSettings();
      } else if (ev === 'progress') {
        lastPct = typeof data.pct === 'number' ? data.pct : lastPct;
        renderProgress(lastPct, !!data.apk);
      } else if (ev === 'ready') {
        renderProgress(100, false); // web applied: native reloads the page next
      } else if (ev === 'apkready') {
        busy = false;
        box().className = 'show';
        box().innerHTML = '<div class="ota-card"><div class="ota-h">' + icon('download') +
          '<div class="ota-t"><b>جاهز للتثبيت</b><small>اضغط «تثبيت» في نافذة النظام</small></div></div></div>';
      } else if (ev === 'error') {
        busy = false;
        // Report only an apply failure, or a check the user asked for; a silent
        // background check that can't reach the server says nothing.
        lastErr = data.msg || '';
        if ((data.stage && data.stage !== 'check') || manual) toast(reasonOf(lastErr, data.stage), true);
        manual = false;
        if (view === 'settings') renderSettings();
        renderBanner();
      }
    }

    return {
      present: present, check: check, apply: apply, later: later, onEvent: onEvent,
      curWeb: curWeb, curApp: curApp, pending: function () { return pending; },
      lastError: function () { return lastErr; }, reason: reasonOf,
      relang: function () { if (manifest) pending = decide(); }, // language switched: re-pick the notes
      refresh: function () { if (!busy) renderBanner(); },
      init: function () {
        if (!bridge) return;
        check();
        setTimeout(function () { if (!pending && !busy) check(); }, 2 * 60 * 1000);
        setInterval(function () { if (!pending && !busy) check(); }, 6 * 60 * 60 * 1000);
      }
    };
  })();
  window.__ota = function (ev, json) { OTA.onEvent(ev, json); };

  // ------------------------------------------------------------- recipes
  function starter(name, dose, ratio, grind, temp, n) {
    // Omni holds up to 18 g; a bigger dose needs the «آخر» cup (up to 25 g).
    return { id: 'r' + Math.random().toString(36).slice(2, 9), name: name, dose_g: dose, cup_type: dose > 18 ? 3 : 2,
      grinder_size: grind, grinder_size_enabled: 1, rpm: 90, pours: XB.autoPours(dose, ratio, n, temp) };
  }
  function loadRecipes() {
    try {
      var r = JSON.parse(localStorage.getItem('xb.recipes'));
      if (r && r.length) {
        // Older builds saved >18 g recipes on the Omni cup, which it can't hold.
        r.forEach(function (x) { if (x.cup_type === 2 && x.dose_g > 18) x.cup_type = 3; });
        return r;
      }
    } catch (e) { /* first run */ }
    return [
      starter('تحميص فاتح', 15, 16, 45, 94, 3),
      starter('تحميص متوسط', 15, 15.5, 55, 92, 3),
      starter('تحميص غامق', 15, 15, 62, 88, 3),
      starter('كوب كبير', 18, 16, 52, 92, 4),
      teaRecipe({ name: 'شاي أسود', leaf: 4, temp: 95, vol: 150, n: 1 })
    ];
  }
  var recipes = loadRecipes();
  try { if (!localStorage.getItem('xb.recipes')) localStorage.setItem('xb.recipes', JSON.stringify(recipes)); } catch (e) { /* storage off */ }
  function saveRecipes() {
    try { localStorage.setItem('xb.recipes', JSON.stringify(recipes)); } catch (e) { toast('ما قدرت أحفظ', true); }
  }
  function byId(id) { return recipes.filter(function (r) { return r.id === id; })[0]; }

  // ----------------------------------------------------- stats & library
  // How many cups the machine has made — total, and today — kept on the screen.
  function today() { var d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
  function cupStats() {
    var total = 0, day = 0;
    try { total = parseInt(localStorage.getItem('xb.cups.total') || '0', 10) || 0; } catch (e) { /* */ }
    try { var d = JSON.parse(localStorage.getItem('xb.cups.day') || '{}'); if (d.date === today()) day = d.n || 0; } catch (e) { /* */ }
    return { total: total, today: day };
  }
  function bumpCup() {
    try {
      localStorage.setItem('xb.cups.total', String((parseInt(localStorage.getItem('xb.cups.total') || '0', 10) || 0) + 1));
      var d = {}; try { d = JSON.parse(localStorage.getItem('xb.cups.day') || '{}'); } catch (e) { /* */ }
      if (d.date !== today()) d = { date: today(), n: 0 };
      d.n = (d.n || 0) + 1;
      localStorage.setItem('xb.cups.day', JSON.stringify(d));
    } catch (e) { /* storage off */ }
  }
  var countedBrewAt = 0; // so one finished brew is counted once

  // ------------------------------------------------------- before the brew
  // Two optional steps the café asked for, between «حضّر الحين» and the brew:
  // weigh the beans on the machine's scale, and rinse the paper filter with
  // hot water (a pour-only "recipe", never logged or counted as a cup).
  // Either can be skipped: «ابدأ التحضير» is always there.
  var prep = null; // { id, rinse: ''|'done'|'failed', err }
  var RINSE_ML = 20; // a short circular pour, no shaking (the café's call)
  // (clearBrew keeps the last recipe, so an idle phase means no rinse is on.)
  function isRinse() { return !!(link.brew.recipe && link.brew.recipe.rinse) && link.brew.phase !== 'idle'; }
  function startRinse() {
    var r = prep && byId(prep.id);
    if (!r || !r.pours.length) return;
    var x = JSON.parse(JSON.stringify(r));
    x.rinse = true; x.name = L(isTea(r) ? 'تسخين المصفاة' : 'ترطيب الفلتر');
    x.grinder_size_enabled = 0; x.grinder_size = 0;
    var p0 = x.pours[0];
    p0.volume_ml = RINSE_ML; p0.temperature_c = Math.min(XB.LIMITS.temp[1], 96); p0.pause_s = 0;
    p0.pattern = 3; p0.agitate_before = 2; p0.agitate_after = 2; // circular, no shake before or after
    x.pours = [p0];
    prep.rinse = ''; prep.err = null;
    link.startBrew(x).catch(function () {});
  }
  function weighState(r) {
    var w = link.machine.weight, t = r.dose_g;
    if (w === null || w === undefined) return { w: null, frac: 0, cls: '', msg: L('حط الوعاء على الميزان') };
    var d = Math.round((t - w) * 10) / 10;
    if (Math.abs(d) <= 0.3) return { w: w, frac: 1, cls: 'ok', msg: L('تمام، الوزن مضبوط') };
    if (d > 0) return { w: w, frac: Math.max(0, w / t), cls: '', msg: L('باقي') + ' ' + fmt(d, 1) + ' ' + L('جم') };
    return { w: w, frac: 1, cls: 'over', msg: L('زايد') + ' ' + fmt(-d, 1) + ' ' + L('جم') };
  }
  function renderPrep() {
    var r = prep && byId(prep.id);
    if (!r) { prep = null; view = 'home'; return renderHome(); }
    var tea = isTea(r), conn = link.state === 'connected', running = isRinse();
    var ws = weighState(r);
    var weigh = '<section class="card prep-step" id="pweigh"><div class="prep-head"><span class="prep-n">1</span>' + icon('scale') +
      '<div><h4>' + (tea ? 'وزّن الشاي' : 'وزّن البن') + '</h4><p>' +
      (tea ? 'حط وعاء فاضي على الميزان، صفّره، وحط الشاي لين يوصل الرقم.' : 'حط وعاء فاضي على الميزان، صفّره، وحط البن لين يوصل الرقم. بعدها صبّه في المطحنة.') +
      '</p></div></div>' +
      '<div class="weigh"><div class="weigh-num ' + ws.cls + '" id="pwnum"><b id="pw">' + (ws.w === null ? '—' : fmt(ws.w, 1)) + '</b>' +
      '<small>' + L('من') + ' ' + fmt(r.dose_g, 1) + ' ' + L('جم') + '</small></div>' +
      '<div class="weigh-bar ' + ws.cls + '" id="pwbar"><i id="pwfill" style="-webkit-transform:scaleX(' + Math.min(1, ws.frac).toFixed(3) + ');transform:scaleX(' + Math.min(1, ws.frac).toFixed(3) + ')"></i></div>' +
      '<p class="weigh-msg" id="pwmsg">' + ws.msg + '</p>' +
      '<button data-act="preptare"' + (conn ? '' : ' disabled') + '>' + icon('scale') + 'صفّر الميزان</button></div></section>';
    var rinseBody;
    if (running) {
      rinseBody = '<div class="rinse-run"><div class="weigh-bar"><i id="prfill"></i></div>' +
        '<p class="weigh-msg"><b id="prml">0</b> ' + L('مل من') + ' ' + RINSE_ML + '</p>' +
        '<button class="danger" data-act="preprinsestop">' + icon('stop') + 'إيقاف</button></div>';
    } else if (prep.rinse === 'done') {
      rinseBody = '<p class="prep-ok">' + icon('check') + (tea ? 'تسخّنت المصفاة — كبّ الماء ورجّع الكوب.' : 'تم الترطيب — كبّ الماء ورجّع السيرفر.') + '</p>' +
        '<button data-act="preprinse"' + (conn ? '' : ' disabled') + '>' + icon('drop') + 'مرة ثانية</button>';
    } else {
      rinseBody = (prep.rinse === 'failed' ? '<div class="notice bad">' + icon('alert') + (REASON_AR[prep.err] || L('ما اكتمل التحضير')) + '</div>' : '') +
        '<button class="primary" data-act="preprinse"' + (conn ? '' : ' disabled') + '>' + icon('drop') + (tea ? 'سخّن الحين' : 'رطّب الحين') + '</button>';
    }
    var rinse = '<section class="card prep-step' + (running ? ' running' : '') + '"><div class="prep-head"><span class="prep-n">2</span>' + icon('filter') +
      '<div><h4>' + (tea ? 'سخّن المصفاة' : 'رطّب الفلتر') + '</h4><p>' +
      (tea ? 'المصفاة فاضية والكوب تحتها. المكينة تصب ' : 'فلتر الورق في القمع بدون بن، والسيرفر تحته. المكينة تصب ') + RINSE_ML + ' ' + L('مل ماء حار.') +
      '</p></div></div>' + rinseBody + '</section>';
    var goBtn = running ? '' : conn
      ? '<button class="cta primary" data-act="prepgo">' + icon('play') + 'ابدأ التحضير</button>'
      : '<button class="cta offline" data-act="go" data-view="settings">' + icon('link') + 'المكينة مو متصلة — اضغط هنا</button>';
    $view.innerHTML = '<div class="prep"><div class="section-title"><h3>' + L('تجهيز') + ' «' + esc(r.name) + '»</h3>' +
      '<button class="mini" data-act="prepback">رجوع</button></div>' +
      '<p class="prep-sub">' + L('خطوتين اختيارية قبل الكوب، وتقدر تتخطاها.') + '</p>' +
      weigh + rinse + goBtn + '</div>';
    updatePrep();
  }
  // Live numbers only, so a finger on a button isn't disturbed by a redraw.
  function updatePrep() {
    var r = prep && byId(prep.id);
    if (!r || view !== 'prep') return;
    var ws = weighState(r), el;
    if ((el = document.getElementById('pw'))) el.textContent = ws.w === null ? '—' : fmt(ws.w, 1);
    if ((el = document.getElementById('pwnum'))) el.className = 'weigh-num ' + ws.cls;
    if ((el = document.getElementById('pwbar'))) el.className = 'weigh-bar ' + ws.cls;
    if ((el = document.getElementById('pwmsg'))) el.textContent = ws.msg;
    if ((el = document.getElementById('pwfill'))) { var f = 'scaleX(' + Math.min(1, ws.frac).toFixed(3) + ')'; el.style.webkitTransform = f; el.style.transform = f; }
    if (isRinse()) {
      var ml = pouredMl(link.machine.water, RINSE_ML) || 0;
      if ((el = document.getElementById('prml'))) el.textContent = fmt(Math.min(ml, RINSE_ML));
      if ((el = document.getElementById('prfill'))) { var g = 'scaleX(' + Math.min(1, ml / RINSE_ML).toFixed(3) + ')'; el.style.webkitTransform = g; el.style.transform = g; }
    }
  }

  // A card grows into the next screen: a white sheet starts at the card's
  // place and size and fills the screen, the new screen is drawn under it,
  // and the sheet fades away. Transform and opacity only.
  function expandFrom(el, then) {
    var a = el && el.getBoundingClientRect ? el.getBoundingClientRect() : null;
    var W = window.innerWidth, H = window.innerHeight;
    if (!a || !a.width || !W) { then(); return; }
    var ov = document.createElement('div');
    ov.className = 'expand';
    var t0 = 'translate(' + Math.round(a.left) + 'px,' + Math.round(a.top) + 'px) scale(' + (a.width / W).toFixed(4) + ',' + (a.height / H).toFixed(4) + ')';
    ov.style.webkitTransform = t0; ov.style.transform = t0;
    document.body.appendChild(ov);
    void ov.offsetWidth;
    ov.classList.add('grow');
    setTimeout(function () {
      then();
      ov.classList.add('fade');
      setTimeout(function () { if (ov.parentNode) ov.parentNode.removeChild(ov); }, 450);
    }, 420);
  }

  // ------------------------------------------------------------ history
  // Every finished brew (done, stopped or failed), newest first, capped.
  var HISTORY_MAX = 150, loggedBrewAt = 0;
  function history() { try { return JSON.parse(localStorage.getItem('xb.history') || '[]') || []; } catch (e) { return []; } }
  function saveHistory(h) { try { localStorage.setItem('xb.history', JSON.stringify(h.slice(0, HISTORY_MAX))); } catch (e) { /* */ } }
  function logBrew(b, m) {
    var r = b.recipe || {};
    var h = history();
    h.unshift({
      at: b.startedAt, end: b.endedAt || Date.now(), status: b.phase, id: r.id, name: r.name || '', tea: isTea(r),
      dose: r.dose_g, water: r.pours ? XB.totalWater(r) : 0, weight: m.weight === null ? null : Math.round(m.weight * 10) / 10
    });
    saveHistory(h);
  }
  function setTaste(at, taste) {
    var h = history();
    h.forEach(function (e) { if (e.at === at) e.taste = taste; });
    saveHistory(h);
  }

  // ------------------------------------------------------------ cleaning
  // A reminder after N cups (or 60 days) since the last time someone tapped
  // «نظّفتها». Counting starts the first time this code runs.
  var CLEAN_DAYS = 60;
  // Right after power-on the frame's clock reads 2000-ish until it syncs from
  // the network; dates taken then are meaningless.
  var SANE_TIME = Date.UTC(2025, 0, 1);
  function clockOk() { return Date.now() > SANE_TIME; }
  function cleanState() {
    var s = {};
    try { s = JSON.parse(localStorage.getItem('xb.clean') || 'null') || null; } catch (e) { s = null; }
    if (!s) { s = { at: Date.now(), cups: 0, every: 100 }; if (clockOk()) saveClean(s); }
    // Started counting while the clock was wrong: restart the days from now.
    else if (s.at < SANE_TIME && clockOk()) { s.at = Date.now(); saveClean(s); }
    return s;
  }
  function saveClean(s) { try { localStorage.setItem('xb.clean', JSON.stringify(s)); } catch (e) { /* */ } }
  function cleanDays() { var at = cleanState().at; return clockOk() && at > SANE_TIME ? Math.floor((Date.now() - at) / 86400000) : 0; }
  function cleanDue() { var s = cleanState(); return s.cups >= s.every || cleanDays() >= CLEAN_DAYS; }
  function bumpClean() { var s = cleanState(); s.cups = (s.cups || 0) + 1; saveClean(s); }

  // ------------------------------------------------------- taste helper
  // After a brew: how did it taste? Classic pour-over fixes, one step at a
  // time, shown as an exact change the user can apply to the saved recipe.
  // Each returns {text, apply(recipe)} or null when it can't help.
  var tasteAt = 0, tasteChoice = '';
  function tasteFix(r, taste) {
    if (!r) return null;
    var tea = isTea(r), grind = r.grinder_size_enabled !== 0 && r.grinder_size > 0, L = XB.LIMITS;
    var t0 = r.pours[0] ? r.pours[0].temperature_c : 92;
    function temp(d) {
      var to = Math.max(tea ? 60 : 80, Math.min(L.temp[1], t0 + d));
      if (to === t0) return null;
      return { text: 'الحرارة ' + t0 + '° ← ' + to + '°', apply: function (x) { x.pours.forEach(function (p) { p.temperature_c = Math.max(L.temp[0], Math.min(L.temp[1], p.temperature_c + (to - t0))); }); } };
    }
    function grindBy(d) {
      if (!grind) return null;
      var to = Math.max(L.grind_size[0], Math.min(L.grind_size[1], r.grinder_size + d));
      if (to === r.grinder_size) return null;
      return { text: 'الطحنة ' + r.grinder_size + ' ← ' + to + (d < 0 ? ' (أنعم)' : ' (أخشن)'), apply: function (x) { x.grinder_size = to; } };
    }
    function dose(d) {
      var cup = XB.CUP_TYPES.filter(function (c) { return c.api === r.cup_type; })[0];
      var to = Math.round((r.dose_g + d) * 10) / 10;
      if (!cup || to < cup.dose[0] || to > cup.dose[1]) return null;
      return { text: (tea ? 'الشاي ' : 'البن ') + r.dose_g + ' ← ' + to + ' ' + L('جم'), apply: function (x) { x.dose_g = to; } };
    }
    function water(f) {
      var total = XB.totalWater(r), to = Math.round(total * f);
      if (r.pours.some(function (p) { return Math.round(p.volume_ml * f) > L.volume[1]; })) return null;
      return { text: 'الماء ' + total + ' ← ' + to + ' ' + L('مل'), apply: function (x) { x.pours.forEach(function (p) { p.volume_ml = Math.round(p.volume_ml * f); }); } };
    }
    if (tea) {
      if (taste === 'bitter') return temp(-5) || water(1.1);
      if (taste === 'weak') return dose(0.5) || temp(3);
      if (taste === 'strong') return water(1.1) || dose(-0.5);
      return null;
    }
    if (taste === 'sour') return grindBy(-3) || temp(2);
    if (taste === 'bitter') return grindBy(3) || temp(-2);
    if (taste === 'weak') return dose(1) || water(0.94);
    if (taste === 'strong') return water(1.06) || dose(-1);
    return null;
  }
  var TASTES_COFFEE = [['good', 'ممتازة'], ['sour', 'حامضة'], ['bitter', 'مرّة'], ['weak', 'خفيفة'], ['strong', 'ثقيلة']];
  var TASTES_TEA = [['good', 'ممتاز'], ['bitter', 'مرّ / قابض'], ['weak', 'خفيف'], ['strong', 'ثقيل']];
  var TASTE_WORD = { good: 'ممتاز', sour: 'حامض', bitter: 'مرّ', weak: 'خفيف', strong: 'ثقيل' };
  // The screen is shared and tastes differ, so the helper belongs to the owner:
  // 'owner' = behind the settings PIN (the default), 'off' = never shown. With
  // no PIN set there is no owner yet, so nobody sees it.
  var tasteUnlockedAt = 0;
  function tasteMode() { try { return localStorage.getItem('xb.taste') === 'off' ? 'off' : 'owner'; } catch (e) { return 'owner'; } }
  function tasteCard() {
    var b = link.brew, r = b.recipe;
    if (b.phase !== 'done' || !r) return '';
    if (tasteMode() === 'off' || !hasPin() || r.dial) return '';
    if (tasteUnlockedAt !== b.startedAt)
      return '<div class="card taste taste-locked"><button data-act="tasteunlock">' + icon('lock') + 'قيّم الطعم</button>' +
        '<p class="hint">لصاحب الشاشة — يحتاج الرقم السري</p></div>';
    var tea = isTea(r), saved = byId(r.id);
    if (tasteAt !== b.startedAt) { tasteAt = b.startedAt; tasteChoice = ''; }
    var head = '<h4>' + (tea ? 'كيف الشاي؟' : 'كيف طعم القهوة؟') + '</h4>';
    if (!tasteChoice) {
      return '<div class="card taste">' + head + '<div class="taste-opts">' + (tea ? TASTES_TEA : TASTES_COFFEE).map(function (o) {
        return '<button data-act="taste" data-v="' + o[0] + '">' + (o[0] === 'good' ? icon('face4') : '') + o[1] + '</button>';
      }).join('') + '</div></div>';
    }
    if (tasteChoice === 'good_skip') return '';
    if (tasteChoice === 'good') return '<div class="card taste"><p class="taste-ok">' + icon('check') + 'بالهناء! انحفظ رأيك في السجل.</p></div>';
    if (tasteChoice === 'applied') return '<div class="card taste"><p class="taste-ok">' + icon('check') + 'عدّلنا الوصفة — جرّبها المرة الجاية.</p></div>';
    var fix = saved ? tasteFix(saved, tasteChoice) : null;
    if (!fix) return '<div class="card taste"><p class="hint">ما عندنا اقتراح لهالوصفة — جرّب تعدّلها من «تعديل».</p></div>';
    return '<div class="card taste">' + head + '<p class="taste-fix">جرّب المرة الجاية: <b>' + esc(fix.text) + '</b></p>' +
      '<div class="row"><button class="primary" data-act="tasteapply">طبّق على الوصفة</button>' +
      '<button class="ghost" data-act="tasteskip">لا، شكرًا</button></div></div>';
  }
  function redrawTaste() { var el = document.getElementById('taste'); if (el) el.innerHTML = tasteCard(); }

  // ------------------------------------------------- dial in a new bean
  // Three small test cups of the selected recipe that differ in one thing —
  // grind (coffee ground by the machine) or temperature (tea, pre-ground) —
  // rated one by one; the best becomes a NEW recipe at full size, so the
  // original (maybe someone else's favourite) is never touched.
  var dial = null; // { baseId, bean, testDose, knob:'grind'|'temp', values:[], ratings:[], i, step:'intro'|'cup'|'rate'|'result' }
  var DIAL_FACES = [[1, icon('face1'), 'ما عجبني'], [2, icon('face2'), 'عادي'], [3, icon('face3'), 'حلو'], [4, icon('face4'), 'ممتاز']];
  function dialActive() { return !!dial && dial.step !== 'result'; }
  function dialCanGrind(r) { return !isTea(r) && r.grinder_size_enabled !== 0 && r.grinder_size > 0; }
  function dialKnob(r) { return dialCanGrind(r) ? 'grind' : 'temp'; }
  // Grind steps of 5, temperature steps of 3° (5° for tea) around the recipe's value.
  function dialSetKnob(knob) {
    var r = byId(dial.baseId);
    dial.knob = knob; dial.ratings = []; dial.i = 0;
    dial.values = dialValues(r, knob, knob === 'grind' ? r.grinder_size : (r.pours[0] ? r.pours[0].temperature_c : 92), knob === 'grind' ? 5 : (isTea(r) ? 5 : 3));
  }
  function dialValues(r, knob, center, spread) {
    var L = XB.LIMITS;
    if (knob === 'grind') {
      var c = Math.max(L.grind_size[0] + spread, Math.min(L.grind_size[1] - spread, center));
      return [c - spread, c, c + spread];
    }
    var lo = isTea(r) ? 60 : 80, hi = L.temp[1], t = Math.max(lo + spread, Math.min(hi - spread, center));
    return [t - spread, t, t + spread];
  }
  function dialStart() {
    var r = byId(selected);
    if (!r) return;
    var knob = dialKnob(r);
    var cup = XB.CUP_TYPES.filter(function (c) { return c.api === r.cup_type; })[0];
    var testDose = isTea(r) ? r.dose_g : Math.max(cup.dose[0], Math.min(r.dose_g, 10));
    dial = { baseId: r.id, bean: '', testDose: testDose, knob: knob, i: 0, ratings: [], step: 'intro', values: [] };
    dialSetKnob(knob);
  }
  // The base recipe scaled to the test dose (same ratio), with one knob set.
  function dialRecipe(full) {
    var base = byId(dial.baseId);
    var r = JSON.parse(JSON.stringify(base)), v = dial.values[dial.i];
    if (!full && !isTea(r) && dial.testDose !== r.dose_g) {
      var f = dial.testDose / r.dose_g;
      r.pours.forEach(function (p) { p.volume_ml = Math.round(p.volume_ml * f); });
      r.dose_g = dial.testDose;
    }
    if (dial.knob === 'grind') r.grinder_size = v;
    else { var d = v - (r.pours[0] ? r.pours[0].temperature_c : v); r.pours.forEach(function (p) { p.temperature_c += d; }); }
    return r;
  }
  function dialLabel(v) { return dial.knob === 'grind' ? 'الطحنة ' + v : 'الحرارة ' + v + '°'; }
  function renderDial() {
    var base = dial && byId(dial.baseId);
    if (!base) { dial = null; go('home'); return; }
    var tea = isTea(base), body = '', n = dial.values.length;
    var dots = dial.values.map(function (v, i) {
      var cls = i < dial.ratings.length ? 'done' : i === dial.i && dial.step !== 'intro' ? 'now' : '';
      return '<i class="' + cls + '"></i>';
    }).join('');
    if (dial.step === 'intro') {
      body = '<p>' + (tea ? 'نحضّر ٣ أكواب شاي بنفس الوصفة، كل واحد بحرارة مختلفة، وتختار الأحلى.'
        : dialCanGrind(base) ? 'نحضّر ٣ أكواب صغيرة بنفس الوصفة والنسبة، كل واحد يختلف في شي واحد، وتختار الأحلى.'
          : 'البن مطحون، فنجرّب ٣ درجات حرارة بدل الطحنة، وتختار الأحلى.') + '</p>' +
        '<ol class="howto dial-how"><li>كل كوب لحاله: المكينة تحضّر كوب واحد وتوقف.</li>' +
        '<li>تذوّقه وقيّمه، بعدين حطّ بن جديد وكوب فاضي واضغط «حضّر الكوب» اللي بعده.</li>' +
        '<li>نغيّر شي واحد بس بين الأكواب، عشان تعرف وش اللي فرق في الطعم.</li></ol>' +
        (dialCanGrind(base) ? '<div class="field"><label>وش نجرّب؟</label><div class="seg">' +
          '<button data-act="dialknob" data-v="grind" class="' + (dial.knob === 'grind' ? 'on' : '') + '">الطحنة</button>' +
          '<button data-act="dialknob" data-v="temp" class="' + (dial.knob === 'temp' ? 'on' : '') + '">الحرارة</button></div></div>' : '') +
        '<div class="dial-plan">' + dial.values.map(function (v, i) { return '<span>' + (i + 1) + '. ' + dialLabel(v) + '</span>'; }).join('') + '</div>' +
        '<div class="field"><label>اسم البن (اختياري)</label><input id="dialbean" value="' + esc(dial.bean) + '" placeholder="إثيوبي غوجي" maxlength="24"></div>' +
        (tea ? '' : '<p class="hint">كل كوب تجريبي يحتاج <b>' + dial.testDose + ' ' + L('جم') + '</b> بن.</p>') +
        '<button class="primary cta" data-act="dialgo">' + icon('play') + 'يلا نبدأ</button>';
    } else if (dial.step === 'cup') {
      var r = dialRecipe(false);
      body = '<h3>الكوب ' + (dial.i + 1) + ' من ' + n + '</h3><p class="dial-knob">' + dialLabel(dial.values[dial.i]) + '</p>' +
        '<ol class="howto"><li>' + (tea ? 'حطّ ' + r.dose_g + ' جم أوراق شاي في المصفاة.' : 'حطّ ' + r.dose_g + ' جم بن' + (dial.knob === 'grind' ? ' في المطحنة.' : ' في الفلتر.')) + '</li>' +
        '<li>حطّ كوب فاضي على الميزان.</li></ol>' +
        (link.state === 'connected' ? '<button class="primary cta" data-act="dialbrew">' + icon('play') + 'حضّر الكوب ' + (dial.i + 1) + '</button>'
          : '<button class="cta offline" data-act="go" data-view="settings">' + icon('link') + 'المكينة مو متصلة — اضغط هنا</button>');
    } else if (dial.step === 'rate') {
      body = '<h3>كيف كان الكوب ' + (dial.i + 1) + '؟</h3><p class="dial-knob">' + dialLabel(dial.values[dial.i]) + '</p>' +
        '<div class="dial-faces">' + DIAL_FACES.map(function (f) {
          return '<button data-act="dialrate" data-v="' + f[0] + '"><span>' + f[1] + '</span><small>' + f[2] + '</small></button>';
        }).join('') + '</div>' +
        '<button class="ghost" data-act="dialretry">ما ضبط التحضير — أعيد الكوب</button>';
    } else {
      var best = 0;
      dial.ratings.forEach(function (x, i) { if (x > dial.ratings[best]) best = i; });
      body = '<h3>الأحلى: ' + dialLabel(dial.values[best]) + ' ' + DIAL_FACES[dial.ratings[best] - 1][1] + '</h3>' +
        '<div class="dial-results">' + dial.values.map(function (v, i) {
          return '<div class="' + (i === best ? 'best' : '') + '"><b>' + dialLabel(v) + '</b><span>' + DIAL_FACES[dial.ratings[i] - 1][1] + '</span></div>';
        }).join('') + '</div>' +
        '<div class="row"><button class="primary" data-act="dialsave" data-i="' + best + '">' + icon('check') + 'احفظها وصفة</button>' +
        '<button data-act="dialagain" data-i="' + best + '">جولة ثانية حول الأحلى</button></div>';
    }
    $view.innerHTML = '<div class="dial"><div class="section-title"><h3>' + icon('target', 'mark') + L('ضبط') + ' «' + esc(base.name) + '»</h3>' +
      '<button class="mini" data-act="dialquit">إلغاء</button></div>' +
      '<div class="card dial-card"><div class="steps">' + dots + '</div>' + body + '</div></div>';
  }

  // The log screen: a summary, then each brew grouped by day.
  function dayLabel(t) {
    var d = new Date(t), now = new Date(), y = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    var same = function (a, b) { return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate(); };
    if (same(d, now)) return 'اليوم';
    if (same(d, y)) return 'أمس';
    return d.getDate() + '/' + (d.getMonth() + 1) + '/' + d.getFullYear();
  }
  function hhmm(t) {
    var d = new Date(t), h = d.getHours(), en = curLang() === 'en';
    var h12 = h % 12 || 12;
    return h12 + ':' + ('0' + d.getMinutes()).slice(-2) + ' ' + (h < 12 ? (en ? 'AM' : 'ص') : (en ? 'PM' : 'م'));
  }
  function renderHistory() {
    var h = history(), week = Date.now() - 7 * 86400000, counts = {}, top = null, today = 0, todayKey = dayLabel(Date.now());
    h.forEach(function (e) {
      if (e.status !== 'done') return;
      if (dayLabel(e.at) === todayKey) today++;
      if (e.at >= week) { counts[e.name] = (counts[e.name] || 0) + 1; if (!top || counts[e.name] > counts[top]) top = e.name; }
    });
    var summary = '<div class="stats"><div class="stat"><b>' + today + '</b><small>أكواب اليوم</small></div>' +
      '<div class="stat"><b>' + h.filter(function (e) { return e.status === 'done' && e.at >= week; }).length + '</b><small>هالأسبوع</small></div></div>' +
      (top ? '<p class="hint">الأكثر هالأسبوع: <b>' + esc(top) + '</b> (' + counts[top] + ')</p>' : '');
    var rows = '', lastDay = '';
    h.forEach(function (e) {
      var day = dayLabel(e.at);
      if (day !== lastDay) { rows += '<div class="hist-day">' + day + '</div>'; lastDay = day; }
      var secs = Math.max(0, Math.round((e.end - e.at) / 1000));
      var dur = Math.floor(secs / 60) + ':' + ('0' + secs % 60).slice(-2);
      var st = e.status === 'done' ? '' : '<span class="hist-bad">' + (e.status === 'stopped' ? 'انلغى' : 'ما اكتمل') + '</span>';
      rows += '<div class="hist-row"><span class="hist-time">' + hhmm(e.at) + '</span>' +
        '<span class="hist-name">' + (e.tea ? icon('tea', 'mark') : '') + esc(e.name) + st + '</span>' +
        '<span class="hist-meta">' + (e.weight !== null && e.weight !== undefined ? e.weight + ' ' + L('جم') + ' · ' : '') + dur +
        (e.taste && TASTE_WORD[e.taste] ? ' · ' + TASTE_WORD[e.taste] : '') + '</span></div>';
    });
    $view.innerHTML = '<div class="history"><div class="section-title"><h3>سجل التحضير</h3>' +
      '<button class="mini" data-act="go" data-view="home">رجوع</button></div>' +
      '<section class="card">' + summary + '</section>' +
      '<section class="card hist-list">' + (rows || '<p class="hint">ما فيه تحضير للحين — أول كوب بيطلع هنا.</p>') + '</section></div>';
  }

  // Whether this screen can scan a QR. Real camera detection isn't reliable
  // (the frame reports phantom cameras it can't actually use), so we go by how
  // it talks to the machine: through the bridge == a photo frame, no camera;
  // its own Bluetooth == a phone/POS-type device that has one. A desktop
  // browser (for testing) counts as having one.
  function hasCamera() {
    if (viaBridge) return false;
    return !!(navigator.mediaDevices || navigator.getUserMedia || navigator.webkitGetUserMedia);
  }

  // ------------------------------------------------- sound, PIN, alerts
  function soundOn() { try { return localStorage.getItem('xb.sound') !== '0'; } catch (e) { return true; } }
  function setSound(on) { try { localStorage.setItem('xb.sound', on ? '1' : '0'); } catch (e) { /* */ } }
  // A short two-note chime when the coffee is ready — no audio file needed.
  function chime() {
    if (!soundOn()) return;
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      var ac = new AC();
      [[880, 0], [1320, 0.16]].forEach(function (p) {
        var o = ac.createOscillator(), g = ac.createGain();
        o.type = 'sine'; o.frequency.value = p[0];
        o.connect(g); g.connect(ac.destination);
        var t = ac.currentTime + p[1];
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(0.35, t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
        o.start(t); o.stop(t + 0.37);
      });
      setTimeout(function () { try { ac.close(); } catch (e) { /* */ } }, 1200);
    } catch (e) { /* no audio */ }
  }

  // An alarm for too many wrong PINs: a harsh alternating two-tone siren, nothing
  // like the soft ready chime. It plays even when sound is set to silent — it's
  // a security alert, not a notification.
  function alarm() {
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      var ac = new AC(), t0 = ac.currentTime + 0.02;
      for (var i = 0; i < 10; i++) {
        var o = ac.createOscillator(), g = ac.createGain(), t = t0 + i * 0.18;
        o.type = 'square'; o.frequency.value = i % 2 ? 620 : 980;
        o.connect(g); g.connect(ac.destination);
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(0.28, t + 0.01);
        g.gain.setValueAtTime(0.28, t + 0.15);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.17);
        o.start(t); o.stop(t + 0.18);
      }
      setTimeout(function () { try { ac.close(); } catch (e) { /* */ } }, 2500);
    } catch (e) { /* no audio */ }
  }

  // PIN lock for Settings, so staff/customers can't change machine settings.
  function pinSet() { try { return localStorage.getItem('xb.pin') || ''; } catch (e) { return ''; } }
  function hasPin() { return !!pinSet(); }
  function savePin(p) { try { localStorage.setItem('xb.pin', p); } catch (e) { /* */ } }
  function clearPin() { try { localStorage.removeItem('xb.pin'); } catch (e) { /* */ } }
  var settingsUnlocked = false, pinInput = '', pinMode = 'enter', pinFirst = '';

  function renderLock() {
    var title = pinMode === 'dial' ? icon('target', 'mark') + 'الضبط التلقائي' : pinMode === 'taste' ? 'مساعد الطعم' : pinMode === 'enter' ? 'الإعدادات مقفلة' : pinMode === 'confirm' ? 'أعد كتابة الرقم' : 'اختر رقمًا سريًا';
    var sub = pinMode === 'dial' ? 'ادخل الرقم السري — الضبط لصاحب الشاشة بس'
      : pinMode === 'taste' ? 'ادخل الرقم السري — المساعد لصاحب الشاشة بس'
      : pinMode === 'enter' ? 'ادخل الرقم السري لفتح الإعدادات' : 'أربعة أرقام';
    var dots = '';
    for (var i = 0; i < 4; i++) dots += '<i class="' + (i < pinInput.length ? 'on' : '') + '"></i>';
    var keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map(function (k) {
      var act = k === 'C' ? 'pinclear' : k === '⌫' ? 'pinback' : 'pinkey';
      return '<button class="keypad-k' + (k === 'C' || k === '⌫' ? ' aux' : '') + '" data-act="' + act + '" data-k="' + k + '">' + k + '</button>';
    }).join('');
    $view.innerHTML = '<div class="lock"><div class="lock-box">' +
      '<div class="lock-ic">' + icon('lock') + '</div><h2>' + title + '</h2><p class="hint">' + sub + '</p>' +
      '<div class="pin-dots">' + dots + '</div>' +
      '<div class="keypad">' + keys + '</div>' +
      '<button class="ghost" data-act="towelcome">رجوع</button></div></div>';
  }

  var PIN_TRIES = 5, PIN_WAIT_MS = 30000;
  function pinWaitLeft() {
    var until = 0; try { until = Number(localStorage.getItem('xb.pinWait') || 0); } catch (e) { /* */ }
    return Math.max(0, Math.ceil((until - Date.now()) / 1000));
  }
  function pinWrong() {
    var n = 0; try { n = Number(localStorage.getItem('xb.pinFails') || 0) + 1; } catch (e) { /* */ }
    if (n >= PIN_TRIES) {
      try { localStorage.setItem('xb.pinWait', String(Date.now() + PIN_WAIT_MS)); localStorage.setItem('xb.pinFails', '0'); } catch (e) { /* */ }
      var secs = Math.round(PIN_WAIT_MS / 1000);
      toast(curLang() === 'en' ? 'Too many tries — wait ' + secs + ' seconds' : 'محاولات كثيرة — انتظر ' + secs + ' ثانية', true);
      alarm();
    } else {
      try { localStorage.setItem('xb.pinFails', String(n)); } catch (e) { /* */ }
      toast('رقم غلط', true);
    }
    renderLock();
  }
  function pinRight() { try { localStorage.setItem('xb.pinFails', '0'); } catch (e) { /* */ } }
  function pinDigit(k) {
    var wait = pinWaitLeft();
    if (wait && pinMode !== 'set' && pinMode !== 'confirm') { toast(curLang() === 'en' ? 'Wait ' + wait + ' seconds' : 'انتظر ' + wait + ' ثانية', true); return; }
    if (pinInput.length >= 4) return;
    pinInput += k;
    renderLock();
    if (pinInput.length === 4) setTimeout(pinSubmit, 120);
  }
  function pinSubmit() {
    var v = pinInput; pinInput = '';
    if (pinMode === 'dial') {
      if (v === pinSet()) { pinRight(); pinMode = 'enter'; dialStart(); go(dial ? 'dial' : 'home'); }
      else pinWrong();
    } else if (pinMode === 'taste') {
      // Right PIN: back to the finished brew with the helper open, for this cup only.
      if (v === pinSet()) { pinRight(); tasteUnlockedAt = link.brew.startedAt; pinMode = 'enter'; go('home'); }
      else pinWrong();
    } else if (pinMode === 'enter') {
      if (v === pinSet()) { pinRight(); settingsUnlocked = true; go('settings'); }
      else pinWrong();
    } else if (pinMode === 'set') {
      pinFirst = v; pinMode = 'confirm'; renderLock();
    } else { // confirm
      if (v === pinFirst) { savePin(v); settingsUnlocked = true; toast('تم تعيين الرقم السري'); go('settings'); }
      else { toast('الرقمان ما تطابقا', true); pinMode = 'set'; renderLock(); }
    }
  }

  // A clear, actionable machine alert for the home/welcome screens, or null.
  function machineAlert() {
    var m = link.machine;
    if (m && m.waterEnough === false) return 'خزان الماء ناقص — عبّه قبل التحضير';
    return null;
  }

  function isTea(r) { return r && r.cup_type === 4; }

  // Ready-made recipes the user can add with one tap, then tweak freely.
  // Coffee entries carry a ratio + grind; tea entries steep leaves (no grind,
  // leaf grams, a temperature and one or more steeps).
  var LIBRARY = [
    { name: 'V60 كلاسيك', desc: 'نظيفة ومتوازنة', dose: 15, ratio: 16, grind: 50, temp: 93, n: 3 },
    { name: 'هوفمان كوب واحد', desc: 'حلاوة أعلى، ٤ صبّات', dose: 15, ratio: 16.6, grind: 55, temp: 94, n: 4 },
    { name: 'فاتح مشرق', desc: 'حموضة وفواكه', dose: 14, ratio: 16.5, grind: 45, temp: 95, n: 3 },
    { name: 'غامق ناعم', desc: 'جسم أثقل، أقل حموضة', dose: 16, ratio: 15, grind: 62, temp: 88, n: 3 },
    { name: 'قهوة مثلّجة', desc: 'تُصبّ على ثلج', dose: 18, ratio: 15, grind: 48, temp: 94, n: 3 },
    { name: 'كوب مزدوج', desc: 'كوبين، كمية أكبر', dose: 22, ratio: 16, grind: 55, temp: 92, n: 4 },
    { tea: true, name: 'شاي أخضر', desc: 'حرارة ٨٠° · نقعة واحدة', leaf: 4, temp: 80, vol: 150, n: 1 },
    { tea: true, name: 'شاي أسود', desc: 'حرارة ٩٥° · نقعة واحدة', leaf: 4, temp: 95, vol: 150, n: 1 },
    { tea: true, name: 'أولونغ', desc: 'حرارة ٩٠° · نقعتين', leaf: 5, temp: 90, vol: 140, n: 2 },
    { tea: true, name: 'أعشاب/كركديه', desc: 'حرارة ٩٨° · نقعة واحدة', leaf: 5, temp: 98, vol: 150, n: 1 }
  ];
  // Build a tea recipe: no grinding, leaves in the siphon brewer, each steep a pour.
  function teaRecipe(p) {
    var pours = [];
    for (var i = 0; i < p.n; i++) pours.push({
      volume_ml: p.vol, temperature_c: p.temp, pattern: 2, flow_rate: 3.0,
      pause_s: p.n > 1 ? 10 : 0, agitate_before: 2, agitate_after: 2
    });
    return { id: 'r' + Math.random().toString(36).slice(2, 9), name: p.name, dose_g: p.leaf,
      cup_type: 4, grinder_size: 0, grinder_size_enabled: 0, rpm: 90, pours: pours };
  }
  function renderLibrary() {
    function card(p, i) {
      var meta = p.tea
        ? p.leaf + ' جم شاي · ' + p.temp + '° · ' + p.n + ' نقعة'
        : p.dose + ' جم · 1:' + p.ratio + ' · ' + p.temp + '° · ' + p.n + ' صبّات';
      return '<div class="card libitem"><div class="libtext"><h4>' + (p.tea ? icon('tea', 'mark') : '') + esc(p.name) + '</h4>' +
        '<p>' + esc(p.desc) + '</p><div class="meta">' + meta + '</div></div>' +
        '<button class="primary" data-act="addlib" data-i="' + i + '">' + icon('plus') + 'أضف</button></div>';
    }
    var coffee = '', tea = '';
    LIBRARY.forEach(function (p, i) { if (p.tea) tea += card(p, i); else coffee += card(p, i); });
    $view.innerHTML = '<div class="library"><div class="section-title"><h3>مكتبة الوصفات</h3>' +
      '<button class="mini" data-act="go" data-view="home">رجوع</button></div>' +
      '<p class="hint">وصفات جاهزة — أضفها لوصفاتك وعدّلها زي ما تحب.</p>' +
      '<div class="section-title"><h3>قهوة</h3></div>' + coffee +
      '<div class="section-title"><h3>' + icon('tea', 'mark') + 'شاي</h3></div>' + tea + '</div>';
  }

  // Favorites first, then the most-used, so the kitchen's go-to recipes rise up.
  function orderedRecipes() {
    return recipes.slice().sort(function (a, b) {
      var f = (b.fav ? 1 : 0) - (a.fav ? 1 : 0);
      if (f) return f;
      return (b.uses || 0) - (a.uses || 0);
    });
  }

  // ---------------------------------------------------------------- views
  var view = 'home', selected = null, draft = null, lastSettingsKey = '';

  function go(v) {
    if (view === 'scan' && v !== 'scan') stopScan();
    if (view === 'phone' && v !== 'phone') phoneClose();
    // Leaving Settings locks it again: the PIN is asked every time, not once
    // per power-on. (The PIN pad itself is part of the settings flow.)
    if (view === 'settings' && v !== 'settings' && v !== 'lock') settingsUnlocked = false;
    view = v;
    Array.prototype.forEach.call(document.querySelectorAll('.tabs button'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-view') === v);
    });
    render();
    animateIn();
    OTA.refresh();
  }
  // A new screen slides in (its cards one after another, see .enter in app.css).
  // Only on a screen change: later redraws of the same screen stay still.
  var enterTimer = null;
  function animateIn() {
    $view.classList.remove('enter');
    void $view.offsetWidth; // restart the animation
    $view.classList.add('enter');
    clearTimeout(enterTimer);
    enterTimer = setTimeout(function () { $view.classList.remove('enter'); }, 1100);
  }

  // -------------------------------------------------------- share / receive
  // Show a recipe as a QR for another الساقي screen or phone to scan.
  var shareId = null;
  function renderShare() {
    var r = byId(shareId);
    if (!r) { go('home'); return; }
    $view.innerHTML = '<div class="share-view"><div class="section-title"><h3>شارك «' + esc(r.name) + '»</h3>' +
      '<button class="mini" data-act="go" data-view="home">رجوع</button></div>' +
      '<div class="card qr-card"><div id="qrbox"></div>' +
      '<p class="hint">وجّه كاميرا جهاز ثاني (يشغّل الساقي) على الباركود، واضغط «استلام وصفة» فيه.</p></div></div>';
    var ok = Share.renderQR(document.getElementById('qrbox'), r);
    if (!ok) toast('تعذّر إنشاء الباركود', true);
  }

  // Open the camera and scan a recipe QR.
  var scanStop = null;
  function renderScan() {
    $view.innerHTML = '<div class="scan-view"><div class="section-title"><h3>استلام وصفة</h3>' +
      '<button class="mini" data-act="scancancel">إلغاء</button></div>' +
      '<div class="card scan-card"><div class="scan-frame"><video id="scanvid" muted playsinline></video>' +
      '<canvas id="scancanvas" style="display:none"></canvas><div class="scan-reticle"></div></div>' +
      '<p class="hint" id="scanhint">وجّه الكاميرا على باركود الوصفة…</p></div></div>';
    var vid = document.getElementById('scanvid'), cv = document.getElementById('scancanvas');
    scanStop = Share.scan(vid, cv, function (recipe) {
      recipes.push(recipe); selected = recipe.id; saveRecipes();
      scanStop = null;
      toast('انحفظت وصفة «' + recipe.name + '»');
      go('home');
    }, function (reason) {
      var h = document.getElementById('scanhint');
      if (h) h.innerHTML = '<span class="warn">' + (reason === 'denied'
        ? 'ما سمحت للكاميرا. فعّلها من إعدادات التطبيق وحاول ثانية.'
        : 'ما فيه كاميرا تشتغل على هذا الجهاز.') + '</span>';
    });
  }
  function stopScan() { if (scanStop) { scanStop(); scanStop = null; } }

  // ------------------------------------------------- add from your phone
  // The native side (XBPhone) opens a 10-minute window and gives us a URL with
  // a one-time token; we show it as a QR. The phone sends recipes back through
  // window.__phoneRecipe, which answers 'ok' or an error code for the phone.
  var phoneSession = null, phoneGot = [], phoneTick = null;
  function phoneLive() { return !!(phoneSession && phoneSession.url && Date.now() < phoneSession.until); }
  function phoneOpen() {
    phoneGot = [];
    var res = {};
    try { res = JSON.parse(XBPhone.start()); } catch (e) { res = { error: 'start' }; }
    phoneSession = res.url ? { url: res.url, until: Date.now() + (res.expiresInMs || 600000) } : { error: res.error || 'start' };
  }
  function phoneClose() {
    clearInterval(phoneTick); phoneTick = null;
    try { if (window.XBPhone) XBPhone.stop(); } catch (e) { /* */ }
    phoneSession = null;
  }
  function phoneLeft() {
    var s = Math.max(0, Math.round((phoneSession.until - Date.now()) / 1000));
    return Math.floor(s / 60) + ':' + ('0' + s % 60).slice(-2);
  }
  function qrSvg(text) {
    for (var type = 3; type <= 10; type++) {
      try { var q = window.qrcode(type, 'M'); q.addData(text); q.make(); return q.createImgTag(6, 16); } catch (e) { /* bigger */ }
    }
    return '';
  }
  function renderPhone() {
    clearInterval(phoneTick); phoneTick = null;
    var s = phoneSession || {}, body;
    if (s.error) {
      body = '<div class="notice bad">' + icon('wifi') + (s.error === 'no_wifi'
        ? 'الشاشة مو متصلة بالواي فاي — وصّلها بنفس شبكة جوالك وجرّب ثانية' : 'ما قدرنا نفتح الاستقبال — جرّب مرة ثانية') + '</div>' +
        '<button class="primary" data-act="phoneagain">جرّب مرة ثانية</button>';
    } else if (!phoneLive()) {
      body = '<p class="hint">انتهت مدة الباركود.</p><button class="primary" data-act="phoneagain">باركود جديد</button>';
    } else {
      body = '<div class="phone-qr">' + qrSvg(s.url) + '</div>' +
        '<ol class="howto"><li>خلّ جوالك على <b>نفس الواي فاي</b> اللي عليه الشاشة.</li>' +
        '<li>صوّر الباركود بكاميرا الجوال، وافتح الرابط.</li>' +
        '<li>الصق رابط وصفة من تطبيق xBloom، أو اكتب وصفتك، واضغط «أرسل للبرواز».</li></ol>' +
        '<p class="hint">الباركود يشتغل <b id="phoneleft">' + phoneLeft() + '</b> دقيقة.</p>';
    }
    var got = phoneGot.length ? '<div class="notice ok">' + icon('check') + '<span>وصلت: ' +
      phoneGot.map(function (n) { return '«' + esc(n) + '»'; }).join('، ') + '</span></div>' : '';
    $view.innerHTML = '<div class="phone-view"><div class="section-title"><h3>أضف وصفة من جوالك</h3>' +
      '<button class="mini" data-act="go" data-view="home">تم</button></div>' +
      '<div class="card phone-card">' + got + body + '</div></div>';
    if (phoneLive()) phoneTick = setInterval(function () {
      if (!phoneLive()) { phoneClose(); phoneSession = { url: '', until: 0 }; if (view === 'phone') renderPhone(); return; }
      var el = document.getElementById('phoneleft'); if (el) el.textContent = phoneLeft();
    }, 1000);
  }
  // From the native server: one recipe from the phone, as a JSON string.
  window.__phoneRecipe = function (json) {
    try {
      if (!phoneLive()) return 'expired';
      var r = XB.sanitize(JSON.parse(json));
      if (!r.name) return 'invalid:name';
      var errs = XB.validate(r);
      if (errs.length) return 'invalid:' + errs.join(',');
      recipes.push(r); selected = r.id; saveRecipes();
      phoneGot.push(r.name);
      toast('وصلت وصفة «' + r.name + '» من الجوال');
      chime();
      if (view === 'phone') renderPhone();
      return 'ok';
    } catch (e) { return 'bad_recipe'; }
  };

  // ------------------------------------------------------------- guide
  // Plain how-to for whoever uses the machine: the physical prep, then the app.
  function guideSeen() {
    try { return localStorage.getItem('xb.guideSeen') === '1'; } catch (e) { return false; }
  }
  function markGuideSeen() {
    try { localStorage.setItem('xb.guideSeen', '1'); } catch (e) { /* preview */ }
  }
  // Whether the guide is being shown as the first-run walkthrough (gets a Skip /
  // Start button) versus opened later from the tab (plain reference).
  var guideIntro = false, fromWelcome = false, guideMode = 'coffee';
  // Tea on xBloom: leaves in the Omni Tea Brewer, no grinding; the machine
  // pours water at the recipe's temperature, it steeps, then drains to the cup.
  var TEA_STEPS = [
    { ic: 'filter', t: 'ركّب مصفاة الشاي', d: 'مكان القمع على المكينة.' },
    { ic: 'beans', t: 'حطّ الأوراق', d: 'من ٣ إلى ٥ جرام في المصفاة.' },
    { ic: 'tap', t: 'الماء والكوب', d: 'الخزان مليان، والكوب على الميزان.' },
    { ic: 'play', t: 'اختر وصفة شاي واضغط «حضّر»', d: 'الأخضر ٨٠° والأسود ٩٥°. بالعافية!' }
  ];
  // Dial-in: three test cups, one change between them, the best saved as a new recipe.
  var DIAL_STEPS = [
    { ic: 'lock', t: 'افتح الوصفة واضغط «اضبط»', d: 'تطلب الرقم السري، الميزة لك بس.' },
    { ic: 'sliders', t: 'اختر الطحنة أو الحرارة', d: 'شي واحد يتغيّر بين الأكواب.' },
    { ic: 'cup', t: '٣ أكواب صغيرة، وقيّم كل واحد', d: '١٠ جرام بن وكوب فاضي لكل كوب.' },
    { ic: 'check', t: 'احفظ الأحلى', d: 'تنحفظ وصفة جديدة، والأصلية ما تتغيّر.' }
  ];
  var COFFEE_STEPS = [
    { ic: 'filter', t: 'جهّز الفلتر', d: 'فلتر ورق في القمع، ورطّبه بماء حار.' },
    { ic: 'beans', t: 'حطّ البن', d: 'حبوب في المطحنة، أو مطحون في الفلتر.' },
    { ic: 'tap', t: 'الماء والكوب', d: 'الخزان مليان، والكوب على الميزان.' },
    { ic: 'play', t: 'اختر وصفتك واضغط «حضّر»', d: 'وتابع التحضير على الشاشة. بالهناء!' }
  ];
  function renderGuide() {
    var tea = guideMode === 'tea';
    var steps = guideMode === 'dial' ? DIAL_STEPS : tea ? TEA_STEPS : COFFEE_STEPS;
    var tips = [
      'وصفة جديدة: «الوصفات» ← «وصفة جديدة».',
      'المكينة غير متصلة؟ اقفل تطبيق xBloom في جوالك.'
    ];
    var intro = guideIntro
      ? '<div class="guide-intro card"><h3>قبل ما نبدأ</h3>' +
        '<p>أربع خطوات وتصير جاهز.</p>' +
        '<button class="primary" data-act="guidedone">فهمت، يلا نبدأ</button>' +
        '<button class="ghost" data-act="guideskip">تخطّي</button></div>'
      : '';
    var html = '<div class="guide">' + intro +
      '<div class="seg guide-mode">' +
      '<button data-act="guidemode" data-v="coffee" class="' + (guideMode === 'coffee' ? 'on' : '') + '">' + icon('cup') + 'قهوة</button>' +
      '<button data-act="guidemode" data-v="tea" class="' + (guideMode === 'tea' ? 'on' : '') + '">' + icon('tea') + 'شاي</button>' +
      '<button data-act="guidemode" data-v="dial" class="' + (guideMode === 'dial' ? 'on' : '') + '">' + icon('target') + 'الضبط</button></div>' +
      '<div class="section-title"><h3>' + (guideMode === 'dial' ? 'كيف تضبط بن جديد' : tea ? 'كيف تسوّي شايك' : 'كيف تسوّي قهوتك') + '</h3><small>خطوة بخطوة</small></div>' +
      '<ol class="guide-steps">' + steps.map(function (st, i) {
        return '<li class="card"><div class="gnum">' + (i + 1) + '</div>' + icon(st.ic) +
          '<div class="gtext"><h4>' + st.t + '</h4><p>' + st.d + '</p></div></li>';
      }).join('') + '</ol>' +
      '<div class="section-title"><h3>تلميحات</h3></div>' +
      '<div class="card guide-tips"><ul>' + tips.map(function (t) { return '<li>' + t + '</li>'; }).join('') + '</ul></div>' +
      '</div>';
    $view.innerHTML = html;
  }

  function renderDiag() {
    var rows = (link.rawLog || []).slice().reverse().map(function (e) {
      var name = e.code === XB.NOTIFY.WATER ? 'ماء' : 'وزن';
      return '<tr><td>' + name + '</td><td dir=ltr>' + (e.f) + '</td><td dir=ltr>' + e.u + '</td><td dir=ltr style="font-size:12px">' + e.hex + '</td></tr>';
    }).join('');
    $view.innerHTML = '<div class="settings"><section class="card"><h4>تشخيص (أرقام المكينة الخام)</h4>' +
      '<p class="hint">سوِّ تحضير والأرقام تتعبّى هنا. العمود الأول القيمة كفلوت، والثاني كعدد صحيح.</p>' +
      '<div style="overflow:auto"><table style="width:100%;border-collapse:collapse;font-size:15px">' +
      '<tr style="color:#5F6782"><td>النوع</td><td>float</td><td>uint</td><td>hex</td></tr>' + rows + '</table></div>' +
      '<div class="row"><button data-act="go" data-view="home">رجوع</button>' +
      '<button data-act="diagrefresh">تحديث</button></div></section></div>';
  }

  function render() {
    if (view === 'diag') { document.body.className = ''; return renderDiag(); }
    if (view === 'guide') { document.body.className = ''; guideIntro = fromWelcome; return renderGuide(); }
    if (view === 'share') { document.body.className = ''; return renderShare(); }
    if (view === 'scan') { document.body.className = ''; return renderScan(); }
    if (view === 'library') { document.body.className = ''; return renderLibrary(); }
    if (view === 'phone') { document.body.className = ''; return renderPhone(); }
    if (view === 'history') { document.body.className = ''; return renderHistory(); }
    if (view === 'lock') { document.body.className = ''; return renderLock(); }
    var brewing = link.isBrewing() || ['done', 'stopped', 'failed'].indexOf(link.brew.phase) >= 0;
    // A brew started from the machine's own button shows even over the welcome screen.
    if (view === 'welcome' && !brewing) {
      document.body.className = 'in-welcome';
      return renderWelcome();
    }
    document.body.className = view === 'setup' ? 'in-setup' : '';
    if (view === 'setup') return renderSetup();
    if (link.isBrewing() || ['done', 'stopped', 'failed'].indexOf(link.brew.phase) >= 0) {
      if (isRinse()) { view = 'prep'; return renderPrep(); }
      return renderBrew();
    }
    if (view === 'prep') return renderPrep();
    if (view === 'edit') return renderEdit();
    if (view === 'settings') return renderSettings();
    if (view === 'dial') return renderDial();
    renderHome();
  }

  function grindText(r) { return r.grinder_size_enabled !== 0 && r.grinder_size > 0 ? String(r.grinder_size) : '—'; }

  // One bar per pour, as tall as its share of the water: the recipe's shape at a glance.
  function shape(r) {
    var max = 0;
    r.pours.forEach(function (p) { max = Math.max(max, p.volume_ml); });
    var bars = r.pours.map(function (p) {
      var h = max ? Math.max(10, Math.round(p.volume_ml / max * 84)) : 10;
      return '<div class="p"><div class="vol">' + fmt(p.volume_ml) + '</div><div class="bar-in" style="height:' + h + 'px"></div></div>';
    }).join('');
    var labels = r.pours.map(function (p, i) {
      return '<span>' + pourLabel(r, i) + '<br>' + p.temperature_c + '°' + (p.pause_s ? ' · ' + p.pause_s + L('ث') : '') + '</span>';
    }).join('');
    return '<div class="shape">' + bars + '</div><div class="shape-labels">' + labels + '</div>';
  }

  // What the big button says and does, so it never sits disabled without saying why.
  function brewButton(r) {
    if (XB.validate(r).length) return '<button class="cta offline" data-act="edit">' + icon('alert') + 'الوصفة تحتاج تعديل</button>';
    if (link.state === 'connected') return '<button class="cta primary" data-act="brew">' + icon('play') + 'حضّر الحين</button>';
    if (link.state === 'connecting') return '<button class="cta offline" disabled>يتصل بالمكينة…</button>';
    return '<button class="cta offline" data-act="go" data-view="settings">' + icon('link') + 'المكينة مو متصلة — اضغط هنا</button>';
  }

  function renderHome() {
    if (!selected || !byId(selected)) selected = recipes[0] && recipes[0].id;
    var sel = byId(selected), m = link.machine;
    if (!sel) {
      $view.innerHTML = '<div class="card empty"><p>ما فيه وصفات للحين.</p>' +
        '<button class="primary" data-act="new">' + icon('plus') + ' أضف أول وصفة</button></div>';
      return;
    }
    var hero = '<div class="card hero"><div class="hero-top"><h2>' + esc(sel.name) + '</h2>' +
      '<span class="tag">' + esc(CUP_AR[sel.cup_type] || '') + '</span></div>' +
      '<div class="stats">' +
      (isTea(sel)
        ? '<div class="stat"><b>' + fmt(sel.dose_g, 1) + '</b><small>جم شاي</small></div>' +
          '<div class="stat"><b>' + sel.pours.length + '</b><small>نقعات</small></div>' +
          '<div class="stat"><b>' + fmt(XB.totalWater(sel)) + '</b><small>مل ماء</small></div>' +
          '<div class="stat"><b>' + (sel.pours[0] ? sel.pours[0].temperature_c + '°' : '—') + '</b><small>الحرارة</small></div>'
        : '<div class="stat"><b>' + fmt(sel.dose_g, 1) + '</b><small>جم بن</small></div>' +
          '<div class="stat"><b>1:' + fmt(ratioOf(sel), 1) + '</b><small>النسبة</small></div>' +
          '<div class="stat"><b>' + fmt(XB.totalWater(sel)) + '</b><small>مل ماء</small></div>' +
          '<div class="stat"><b>' + grindText(sel) + '</b><small>الطحنة</small></div>') + '</div>' +
      shape(sel) +
      (m.waterEnough === false ? '<div class="notice warn">' + icon('drop') + 'خزان الماء ناقص — عبّه قبل التحضير</div>' : '') +
      (cleanDue() ? '<div class="notice warn">' + icon('alert') + 'حان وقت تنظيف المكينة — الخطوات في الإعدادات</div>' : '') +
      brewButton(sel) +
      '<div class="actions">' +
      '<button class="fav' + (sel.fav ? ' on' : '') + '" data-act="fav">' + icon('star', sel.fav ? 'filled' : '') + 'مفضلة</button>' +
      '<button data-act="edit">' + icon('edit') + 'تعديل</button>' +
      '<button data-act="dup">' + icon('copy') + 'نسخ</button>' +
      '<button data-act="share">' + icon('share') + 'شارك</button>' +
      '<button data-act="slot">' + icon('slot') + 'زر بالمكينة</button>' +
      (hasPin() ? '<button data-act="dial">' + icon('target') + 'اضبط</button>' : '') +
      '<button class="danger" data-act="del">' + icon('trash') + 'حذف</button></div></div>';
    var cards = orderedRecipes().map(function (r) {
      var max = 0;
      r.pours.forEach(function (p) { max = Math.max(max, p.volume_ml); });
      var mini = r.pours.map(function (p) { return '<i style="height:' + (max ? Math.max(4, Math.round(p.volume_ml / max * 26)) : 4) + 'px"></i>'; }).join('');
      var meta = isTea(r)
        ? icon('tea', 'mark') + fmt(r.dose_g, 1) + ' جم · ' + (r.pours[0] ? r.pours[0].temperature_c : '—') + '°'
        : fmt(r.dose_g, 1) + ' جم · 1:' + fmt(ratioOf(r), 1) + ' · ' + (r.pours[0] ? r.pours[0].temperature_c : '—') + '°';
      return '<button class="rcard' + (r.id === selected ? ' on' : '') + '" data-act="pick" data-id="' + r.id + '">' +
        '<h4>' + (r.fav ? icon('star', 'filled mark') : '') + esc(r.name) + '</h4><div class="meta">' + meta +
        '</div><div class="mini-shape">' + mini + '</div></button>';
    }).join('');
    $view.innerHTML = '<div class="home">' + hero +
      '<div class="others"><div class="section-title"><h3>وصفاتك</h3>' +
      '<button class="mini" data-act="library">' + icon('book') + ' المكتبة</button>' +
      '<button class="mini" data-act="history">' + icon('check') + ' السجل</button>' +
      (window.XBPhone ? '<button class="mini" data-act="phone">' + icon('phone') + ' من جوالك</button>' : '') +
      (hasCamera() ? '<button class="mini" data-act="receive">' + icon('scan') + ' استلام وصفة</button>' : '') + '</div>' +
      '<div class="rgrid">' + cards + '<button class="rcard add" data-act="new">' + icon('plus') + 'وصفة جديدة</button></div></div></div>';
  }

  // ---------------------------------------------------------------- editor
  function stepper(label, path, value, step, min, max, unit) {
    return '<div class="field"><label>' + label + '</label><div class="stepper">' +
      '<button data-act="step" data-path="' + path + '" data-d="' + step + '" data-min="' + min + '" data-max="' + max + '">+</button>' +
      '<output>' + fmt(value, 1) + (unit ? '<small>' + unit + '</small>' : '') + '</output>' +
      '<button data-act="step" data-path="' + path + '" data-d="' + (-step) + '" data-min="' + min + '" data-max="' + max + '">−</button>' +
      '</div></div>';
  }
  function choice(label, path, value, options) {
    return '<div class="field"><label>' + label + '</label><div class="seg">' + options.map(function (o) {
      return '<button data-act="set" data-path="' + path + '" data-v="' + o[0] + '" class="' + (String(o[0]) === String(value) ? 'on' : '') + '">' + o[1] + '</button>';
    }).join('') + '</div></div>';
  }

  function getPath(obj, path) { return path.split('.').reduce(function (o, k) { return o[k]; }, obj); }
  function setPath(obj, path, v) {
    var keys = path.split('.'), last = keys.pop();
    keys.reduce(function (o, k) { return o[k]; }, obj)[last] = v;
  }

  function renderEdit() {
    var r = draft, L = XB.LIMITS;
    var cup = XB.CUP_TYPES.filter(function (c) { return c.api === r.cup_type; })[0] || XB.CUP_TYPES[2];
    var grinds = r.grinder_size_enabled !== 0;
    var tea = isTea(r);
    var errs = XB.validate(r);
    var drink = '<div class="field"><label>نوع المشروب</label><div class="seg">' +
      '<button data-act="drink" data-v="coffee" class="' + (tea ? '' : 'on') + '">قهوة</button>' +
      '<button data-act="drink" data-v="tea" class="' + (tea ? 'on' : '') + '">' + icon('tea', 'mark') + 'شاي</button></div></div>';
    var html = '<div class="edit"><div class="edit-head">' +
      '<input id="name" value="' + esc(r.name) + '" placeholder="اسم الوصفة">' +
      '<button class="primary" data-act="save"' + (errs.length ? ' disabled' : '') + '>حفظ</button>' +
      '<button data-act="cancel">إلغاء</button></div>' +
      '<div class="totals"><div class="stat"><b>' + fmt(XB.totalWater(r)) + '</b><small>مل ماء</small></div>' +
      (tea
        ? '<div class="stat"><b>' + (r.pours[0] ? r.pours[0].temperature_c + '°' : '—') + '</b><small>الحرارة</small></div>' +
          '<div class="stat"><b>' + r.pours.length + '</b><small>نقعات</small></div></div>'
        : '<div class="stat"><b>1:' + fmt(ratioOf(r), 1) + '</b><small>النسبة</small></div>' +
          '<div class="stat"><b>' + r.pours.length + '</b><small>دفعات</small></div></div>') +
      (errs.length ? '<div class="notice bad">' + icon('alert') + errs.map(errText).join('، ') + '</div>' : '') +
      '<section class="card"><h4>' + (tea ? 'الشاي' : 'البن') + '</h4><div class="grid">' + drink +
      (tea ? '' : choice('نوع الكوب', 'cup_type', r.cup_type, XB.CUP_TYPES.filter(function (c) { return c.api !== 4; }).map(function (c) { return [c.api, CUP_AR[c.api]]; }))) +
      stepper(tea ? 'كمية الشاي (أوراق)' : 'كمية البن', 'dose_g', r.dose_g, 0.5, cup.dose[0], cup.dose[1], 'جم') +
      (tea ? '' : choice('المطحنة', 'grinder_size_enabled', grinds ? 1 : 0, [[1, 'تطحن'], [0, 'بن مطحون']])) +
      (!tea && grinds ? stepper('درجة الطحن (أقل = أنعم)', 'grinder_size', r.grinder_size, 1, L.grind_size[0], L.grind_size[1]) +
        stepper('سرعة المطحنة', 'rpm', r.rpm, 10, L.rpm[0], L.rpm[1], 'RPM') : '') +
      '</div>' + doseHint(r, cup) + '<div class="auto-row">' +
      (tea ? '<span class="lbl">كل نقعة تُصبّ ماء على الأوراق في مصفاة الشاي.</span>'
           : '<span class="lbl">وزّع الماء تلقائياً:</span>' +
             [14, 15, 16, 17].map(function (x) { return '<button data-act="auto" data-ratio="' + x + '">1:' + x + '</button>'; }).join('')) +
      '<button data-act="addpour"' + (r.pours.length >= 9 ? ' disabled' : '') + '>+ ' + (tea ? 'نقعة' : 'دفعة') + '</button></div></section>';
    r.pours.forEach(function (p, i) {
      var b = 'pours.' + i + '.';
      var head = tea ? 'نقعة ' + (i + 1) : (i === 0 && r.pours.length > 1 ? 'التشريب (دفعة 1)' : 'دفعة ' + (i + 1));
      html += '<section class="card pour"><h4>' + head +
        (r.pours.length > 1 ? ' <button class="mini danger" data-act="delpour" data-i="' + i + '">حذف</button>' : '') +
        '</h4><div class="grid">' +
        stepper(tea ? 'ماء النقعة' : 'الماء', b + 'volume_ml', p.volume_ml, 1, 0, L.volume[1], 'مل') +
        stepper('الحرارة', b + 'temperature_c', p.temperature_c, 1, L.temp[0], L.temp[1], '°م') +
        stepper(tea ? 'انتظار بين النقعات' : 'انتظار بعدها', b + 'pause_s', p.pause_s, 5, 0, L.pause[1], 'ث') +
        stepper('سرعة الصب', b + 'flow_rate', p.flow_rate, 0.1, L.flow[0], L.flow[1], 'مل/ث') +
        (tea ? '' :
          choice('طريقة الصب', b + 'pattern', p.pattern, XB.PATTERNS.map(function (x) { return [x.api, PATTERN_AR[x.api]]; })) +
          choice('هز قبل', b + 'agitate_before', p.agitate_before, [[1, 'نعم'], [2, 'لا']]) +
          choice('هز بعد', b + 'agitate_after', p.agitate_after, [[1, 'نعم'], [2, 'لا']])) +
        '</div></section>';
    });
    $view.innerHTML = html + '</div>';
  }

  // The coffee limit depends on the cup: Omni holds up to 18 g, «آخر» (your own
  // larger dripper) up to 25 g. Once Omni is at its max, say so and offer the
  // switch in one tap instead of the + button silently doing nothing.
  var BIG_CUP = 3;
  function doseHint(r, cup) {
    if (isTea(r)) return '';
    if (r.cup_type === 1) return '<div class="notice">' + icon('alert') + 'كبسولة xPod كميتها ثابتة 15 جم</div>';
    if (r.cup_type === 2 && r.dose_g >= cup.dose[1])
      return '<div class="notice dose-hint">' + icon('alert') + '<span>كوب Omni يتحمّل لين 18 جم. تبي أكثر؟</span>' +
        '<button class="primary" data-act="set" data-path="cup_type" data-v="' + BIG_CUP + '">حوّله لكوب «آخر» (لين 25 جم)</button></div>';
    return '';
  }

  function errText(e) {
    if (e === 'dose') return 'كمية البن خارج حدود الكوب';
    if (e === 'ratio') return 'النسبة لازم بين 1:5 و 1:25';
    if (e === 'water') return 'ما فيه ماء';
    if (e === 'grinder') return 'إعدادات المطحنة';
    return e;
  }

  // ------------------------------------------------------------------ brew
  // One big ring: water poured out of the recipe's total, readable from across
  // the kitchen. Grinding has no measure, so the ring turns instead.
  //
  // The brew picture is drawn ONCE per phase and then only its numbers and
  // liquid level are nudged each tick — rebuilding the whole node every second
  // restarted the CSS animations from zero, which looked like a stutter.
  var brewTimer = null, brewPhaseKey = '';

  // A little celebration when the cup is ready: dots flying out of the ring.
  function burst() {
    var h = '<div class="burst">';
    for (var i = 0; i < 12; i++) h += '<span style="-webkit-transform:rotate(' + (i * 30) + 'deg);transform:rotate(' + (i * 30) + 'deg)"><b class="k' + (i % 3) + '"></b></span>';
    return h + '</div>';
  }
  // The brew picture: the machine's head drips water into an xBloom dripper,
  // coffee drips from it into a glass coffee server that fills up as the water
  // goes in (the owner asked for a server, not a plain glass).
  // Static parts are one SVG drawn on top; the moving parts are plain elements
  // under it, moved with transforms only (cheap on the frame).
  var CUP_TOP = 176, CUP_H = 208; // the liquid's box inside the drawn server, px (see .vessel .cupfill)
  var VESSEL_SVG = '<svg class="vs-front" viewBox="0 0 360 400" width="360" height="400">' +
    '<rect x="128" y="0" width="104" height="16" rx="8" fill="#2A3350"/>' +
    '<rect x="150" y="13" width="60" height="7" rx="3.5" fill="#46527A"/>' +
    '<path d="M92 76H268L226 152H134Z" fill="#EEF2FB"/>' +
    '<path class="bed" d="M118 120Q180 108 242 120L226 152H134Z"/>' +
    '<path d="M132 92L152 140M180 90V142M228 92L208 140" stroke="#C9D3EE" stroke-width="3" stroke-linecap="round" fill="none"/>' +
    '<path d="M92 76H268L226 152H134Z" fill="none" stroke="#213E9A" stroke-width="4" stroke-linejoin="round"/>' +
    '<rect x="82" y="64" width="196" height="13" rx="6.5" fill="#213E9A"/>' +
    '<rect x="124" y="151" width="112" height="15" rx="5" fill="#213E9A"/>' +
    // A faceted smoky-glass server (the owner's photo): sloped shoulders, wide
    // base, square handle, a spout, dots up the side. Tinted glass over the coffee.
    '<path d="M262 212H296Q308 212 308 224V292Q308 304 296 306L268 312" fill="none" stroke="#8C95A8" stroke-width="8" stroke-linejoin="round" stroke-linecap="round"/>' +
    '<path d="M124 176V188C124 196 112 204 104 214L74 352Q70 384 102 384H258Q290 384 286 352L256 214C248 204 236 196 236 188V176Z" fill="rgba(70,78,95,.12)" stroke="#8C95A8" stroke-width="4" stroke-linejoin="round"/>' +
    '<path d="M104 214Q180 230 256 214M142 222L118 384M180 226V384M218 222L242 384" fill="none" stroke="#FFFFFF" stroke-width="2.5" opacity=".45"/>' +
    '<path d="M104 214Q180 230 256 214" fill="none" stroke="#8C95A8" stroke-width="2" opacity=".5"/>' +
    '<path d="M126 171L97 163Q93 166 98 170L124 186" fill="rgba(70,78,95,.15)" stroke="#8C95A8" stroke-width="3" stroke-linejoin="round"/>' +
    '<rect x="116" y="165" width="128" height="13" rx="4" fill="#C9CED9" stroke="#8C95A8" stroke-width="3"/>' +
    '<path d="M95 250L83 330" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round" opacity=".7"/>' +
    '<circle cx="244" cy="262" r="3.5" fill="#8C95A8"/><circle cx="250" cy="300" r="3.5" fill="#8C95A8"/><circle cx="256" cy="338" r="3.5" fill="#8C95A8"/>' +
    '<path d="M236 262h-10M242 300h-10M248 338h-10" stroke="#8C95A8" stroke-width="2.5" stroke-linecap="round"/></svg>';
  function vessel(b, r, spinning, center) {
    var beans = '';
    if (b.phase === 'grinding') {
      beans = '<div class="vs-orbit">';
      for (var i = 0; i < 8; i++) beans += '<span style="-webkit-transform:rotate(' + (i * 45) + 'deg);transform:rotate(' + (i * 45) + 'deg)"><b class="bn"></b></span>';
      beans += '</div>';
    }
    return '<div class="vessel' + (isTea(r) ? ' tea' : '') + (b.phase === 'grinding' ? ' grind' : '') + (spinning ? ' spin' : '') + '">' +
      '<div class="cupfill"><div class="wave" id="bwave"><i></i><i></i>' +
      '<b class="fz z1"></b><b class="fz z2"></b><b class="fz z3"></b><b class="fz z4"></b></div></div>' +
      '<div class="vs-drops"><b class="p1"></b><b class="p2"></b><b class="p3"></b></div>' +
      '<div class="vs-stream" id="bstream"><b class="q1"></b><b class="q2"></b><b class="q3"></b></div>' +
      VESSEL_SVG + beans +
      '<div class="center">' + center + '</div>' +
      (b.phase === 'done' ? '<div class="steam"><i class="s1"></i><i class="s2"></i><i class="s3"></i></div>' + burst() : '') +
      '</div>';
  }

  function brewWeight(m) { return m.weight === null ? '—' : fmt(m.weight, 1); }

  function renderBrew() {
    var b = link.brew, m = link.machine, r = b.recipe;
    var finished = ['done', 'stopped', 'failed'].indexOf(b.phase) >= 0;
    var spinning = b.phase === 'grinding' || b.phase === 'starting';
    // Full rebuild only when the phase changes; otherwise just update numbers.
    var key = b.phase + '|' + (r ? r.id : '') + '|' + (b.error || '') + '|' + (b.fault || '') + '|' + b.pour;
    if (key !== brewPhaseKey || !document.querySelector('.brew')) {
      brewPhaseKey = key;
      buildBrew(b, m, r, finished, spinning);
    }
    updateBrew(b, m, r, finished, spinning);
    clearTimeout(brewTimer);
    if (!finished) brewTimer = setTimeout(function () { if (link.isBrewing()) renderBrew(); }, 250);
  }

  function buildBrew(b, m, r, finished, spinning) {
    var total = r ? XB.totalWater(r) : 0;
    var title = (isTea(r) && PHASE_TEA[b.phase]) || PHASE_AR[b.phase] || '';
    var center = b.phase === 'done'
      ? icon('check')
      : spinning
        ? '<div class="big" id="bz">0:00</div><div class="unit">' + (b.phase === 'starting' ? L('يرسل الوصفة') : L('يطحن') + ' ' + (r ? fmt(r.dose_g, 1) + ' ' + L('جم') : '')) + '</div>'
        : '<div class="big" id="bz">0</div><div class="unit">' + L('مل') + (total ? L(' من ') + fmt(total) : '') + '</div>';
    var track = '';
    if (r && r.pours.length) {
      track = '<div class="pours-track">' + r.pours.map(function (p, i) {
        var n = i + 1;
        var cls = b.phase === 'done' || n < b.pour ? 'done' : (n === b.pour && b.phase === 'pouring') ? 'now' : '';
        return '<span class="' + cls + '">' + pourLabel(r, i) + ' · ' + fmt(p.volume_ml) + '</span>';
      }).join('') + '</div>';
    }
    var notice = b.error ? '<div class="notice bad">' + icon('alert') + (REASON_AR[b.error] || b.error) + '</div>'
      : b.fault ? '<div class="notice warn">' + icon('alert') + (REASON_AR[b.fault] || b.fault) + '</div>' : '';
    var controls = finished
      ? '<button class="primary" data-act="brewok">' + icon('check') + 'تمام</button>'
      : (b.phase === 'paused'
        ? '<button class="primary" data-act="resume">' + icon('play') + 'كمّل</button>'
        : '<button data-act="pause"' + (b.phase === 'starting' ? ' disabled' : '') + '>' + icon('pause') + 'إيقاف مؤقت</button>') +
        '<button class="danger" data-act="stop">' + icon('stop') + 'إلغاء</button>';
    $view.innerHTML = '<div class="brew ' + b.phase + '">' +
      '<div class="phase">' + title + '</div>' +
      (r ? '<div class="rname">' + esc(r.name) + '</div>' : '<div class="rname">&nbsp;</div>') +
      notice +
      vessel(b, r, spinning, center) +
      track +
      '<div class="brew-stats">' +
      '<div class="card"><b id="btime">0:00</b><small>الوقت</small></div>' +
      '<div class="card"><b id="bweight">—</b><small>جرام في الكوب</small></div></div>' +
      (b.phase === 'done' ? '<div id="taste">' + tasteCard() + '</div>' : '') +
      '<div class="brew-controls">' + controls + '</div>' +
      (finished ? '<div class="brew-bye" id="brewbye"></div>' : '') + '</div>';
  }

  // The machine's water report came through as 86800 on a cup of a few hundred
  // ml (owner's machine, fw V12.0D.500): it looks like thousandths of a ml.
  // No recipe can pour more than 9 × 240 = 2160 ml, so the first report above
  // that fixes the unit at 1/1000 for good (remembered). Anything still out of
  // range shows "—" rather than nonsense. A raw capture (diag screen) confirms.
  var waterScale = 0;
  try { waterScale = Number(localStorage.getItem('xb.waterScale')) || 0; } catch (e) { /* */ }
  function pouredMl(v, total) {
    if (v === null || v === undefined || !isFinite(v) || v < 0) return null;
    if (!waterScale && v > 2200 && v / 1000 <= 2200) {
      waterScale = 1000;
      try { localStorage.setItem('xb.waterScale', '1000'); } catch (e) { /* */ }
    }
    var ml = v / (waterScale || 1);
    if (ml > (total ? total * 1.2 + 30 : 2200)) return null;
    return Math.round(ml);
  }

  function updateBrew(b, m, r, finished, spinning) {
    var total = r ? XB.totalWater(r) : 0;
    var water = pouredMl(m.water, total);
    var end = b.endedAt || Date.now();
    var secs = Math.max(0, Math.floor((end - b.startedAt) / 1000));
    var time = Math.floor(secs / 60) + ':' + ('0' + secs % 60).slice(-2);
    var set = function (id, v) { var el = document.getElementById(id); if (el && el.textContent !== v) el.textContent = v; };
    set('btime', time);
    set('bweight', brewWeight(m));
    if (b.phase === 'done') set('bz', '');
    else if (spinning) set('bz', time);
    else set('bz', water === null ? '—' : fmt(water));
    // Fill the glass to the poured fraction (full when done), without redrawing.
    var npours = r && r.pours ? r.pours.length : 0;
    var poured = water !== null ? (total ? water / total : 0)
      : (npours && b.pour ? (b.pour - 1) / npours : 0);  // no usable number: go by pour
    var frac = b.phase === 'done' ? 1 : spinning ? 0 : Math.max(0, Math.min(1, poured));
    var wave = document.getElementById('bwave');
    if (wave) {
      var y = Math.round((1 - frac) * CUP_H + (frac > 0 ? 0 : 22)) + 'px';
      wave.style.webkitTransform = 'translateY(' + y + ')'; wave.style.transform = 'translateY(' + y + ')';
    }
    // The coffee drips from the dripper down to the surface, not into the glass's floor.
    var stream = document.getElementById('bstream');
    if (stream) {
      var h = Math.max(10, Math.round(CUP_TOP + (1 - frac) * CUP_H - 166 + 6)) + 'px';
      if (stream.style.height !== h) stream.style.height = h;
    }
  }

  // --------------------------------------------------------------- welcome
  // The first thing on screen at every start: all brand blue, the logo, a
  // greeting, one button. The link to the machine comes up behind it.
  function clockStr() {
    var d = new Date(), h = d.getHours(), m = ('0' + d.getMinutes()).slice(-2);
    var en = curLang() === 'en';
    var ap = h < 12 ? (en ? 'AM' : 'ص') : (en ? 'PM' : 'م'), h12 = h % 12; if (h12 === 0) h12 = 12;
    return h12 + ':' + m + ' ' + ap;
  }
  function renderWelcome() {
    var h = new Date().getHours();
    var en = curLang() === 'en';
    var greet = h < 12 ? (en ? 'Good morning' : 'صباح الخير') : (en ? 'Good evening' : 'مساء الخير');
    var ready = link.state === 'connected';
    var status = !link.savedAddress() ? 'أول مرة؟ بنربط الشاشة بمكينتك بخطوات بسيطة'
      : ready ? 'المكينة جاهزة' : link.state === 'connecting' ? 'نتصل بالمكينة…' : 'المكينة غير متصلة';
    var alert = machineAlert() || (cleanDue() ? 'حان وقت تنظيف المكينة' : null);
    $view.innerHTML = '<div class="splash">' +
      '<i class="deco d1"></i><i class="deco d2"></i><i class="deco d3"></i>' +
      '<i class="bub b1"></i><i class="bub b2"></i><i class="bub b3"></i><i class="bub b4"></i><i class="bub b5"></i><i class="bub b6"></i>' +
      '<i class="bean n1"></i><i class="bean n2"></i><i class="bean n3"></i><i class="bean n4"></i><i class="bean n5"></i>' +
      '<i class="splash-glow"></i>' +
      '<div class="splash-clock" id="splashclock">' + clockStr() + '</div>' +
      '<div class="splash-body">' +
      '<img class="splash-logo" src="brand/logo-white.png" alt="الساقي">' +
      '<h1>' + greet + '</h1>' +
      '<p class="splash-sub">قهوتك وشايك، بضغطة زر</p>' +
      '<button class="splash-btn" data-act="enter"><i class="shine"></i>ابدأ</button>' +
      (alert ? '<p class="splash-alert">' + esc(alert) + '</p>' : '') +
      '<p class="splash-status"><i class="dot' + (ready ? ' on' : link.state === 'connecting' ? ' wait' : '') + '"></i>' + status + '</p>' +
      '</div><div class="splash-foot">xBloom Studio</div></div>';
  }

  // ----------------------------------------------------------------- setup
  // First run, or a new machine: (1) the bridge, only on a screen without
  // Bluetooth; (2) the owner's machine, picked by the code printed on it.
  var setupCode = '', setupPicked = null;

  function setupStep() {
    if (viaBridge && transport.status() !== 'ok') return 'bridge';
    if (setupPicked && link.state === 'connected') return 'done';
    return 'machine';
  }

  function wifiLine() {
    if (!window.XBNative || !XBNative.wifiName) return '';
    var name = XBNative.wifiName();
    return '<p>واي فاي الشاشة: <b>' + (name ? esc(name) : 'غير متصل') + '</b> ' +
      '<button class="mini" data-act="wifi">إعدادات الواي فاي</button></p>';
  }

  function renderSetup() {
    var step = setupStep();
    var steps = (viaBridge ? ['bridge'] : []).concat(['machine']);
    var dots = steps.map(function (st, i) {
      var cur = steps.indexOf(step);
      return '<i class="' + (step === 'done' || i < cur ? 'done' : i === cur ? 'now' : '') + '"></i>';
    }).join('');
    var html = '<div class="setup"><button class="ghost back" data-act="towelcome">→ رجوع</button>' +
      '<div class="welcome"><img src="brand/logo-blue.png" alt="الساقي">' +
      '<h2>أهلاً بك</h2><p>خطوات بسيطة ونربط الشاشة بمكينتك</p></div><div class="steps">' + dots + '</div>';
    if (step === 'bridge') {
      var many = transport.found.length > 1;
      html += '<section class="card"><h4>١. جهاز الجسر (ESP32)</h4>' +
        '<p class="hint">هذي الشاشة ما فيها بلوتوث، فتكلّم المكينة عن طريق قطعة ESP32 صغيرة.</p>' +
        wifiLine() +
        '<ol class="howto"><li>وصّل القطعة بالكهرباء قريب من المكينة.</li>' +
        '<li>من جوالك ادخل شبكة الواي فاي <b>xBloom-Bridge-…</b> — تطلع صفحة.</li>' +
        '<li>اختر فيها شبكة البيت (نفس شبكة الشاشة) واكتب كلمة السر.</li>' +
        '<li>ارجع هنا واضغط "دوّر على الجسر".</li></ol>' +
        '<div class="row"><button class="primary" data-act="findbridge">دوّر على الجسر</button></div>' +
        (many ? '<p>لقيت أكثر من جسر — اختر اللي رقمه مكتوب على صفحة الإعداد في جوالك:</p><div class="devs">' +
          transport.found.map(function (b, i) {
            return '<button class="dev" data-act="pickbridge" data-i="' + i + '">جسر <b>' + esc(b.id || '?') + '</b> <small>' + esc(b.ip) + '</small></button>';
          }).join('') + '</div>' : '') +
        '<details><summary>ما لقيته؟ اكتب عنوانه</summary><div class="row">' +
        '<input id="bridgehost" placeholder="مثل 192.168.1.50" value="' + esc(transport.host || '') + '">' +
        '<button data-act="setbridge">اتصل</button></div></details></section>';
    } else if (step === 'machine') {
      var st = link.status();
      var problem = { no_bluetooth: 'هذي الشاشة ما فيها بلوتوث — تحتاج جسر ESP32.', off: 'البلوتوث مقفل — شغّله من إعدادات أندرويد.',
        no_permission: 'التطبيق يحتاج صلاحية الموقع/البلوتوث عشان يدوّر على المكينة.' }[st];
      html += '<section class="card"><h4>' + (viaBridge ? '٢' : '١') + '. اختر مكينتك</h4>' +
        (problem ? '<div class="notice bad">' + icon('alert') + problem + '</div>' : '') +
        '<ol class="howto"><li>شغّل المكينة، وسكّر تطبيق xBloom في الجوال (المكينة تقبل اتصال واحد بس).</li>' +
        '<li>رقم مكينتك: آخر ٦ حروف من الرقم التسلسلي — مكتوب تحت المكينة، وتلقاه في تطبيق xBloom.</li></ol>' +
        '<div class="code-row"><input id="mcode" placeholder="A1B2C3" value="' + esc(setupCode) + '" maxlength="12">' +
        '<button class="primary" data-act="scan"' + (link.scanning ? ' disabled' : '') + '>' + (link.scanning ? 'يدوّر…' : 'دوّر') + '</button></div>' +
        '<div id="devlist" class="devs">' + machineList() + '</div></section>';
    } else {
      html += '<section class="card done-card">' + icon('check') + '<h3>تم الربط</h3><p>الشاشة مربوطة بمكينة <b>' +
        esc(Link.machineCode(link.savedName())) + '</b></p><button class="primary cta" data-act="setupdone">يلا نحضّر</button></section>';
    }
    $view.innerHTML = html + '</div>';
  }

  function machineList() {
    var code = setupCode.toUpperCase().replace(/\s/g, '');
    var items = Object.keys(link.found).map(function (a) { return link.found[a]; })
      .filter(function (d) { return !code || Link.machineCode(d.name).toUpperCase().indexOf(code) >= 0; });
    if (!items.length) {
      return '<p class="hint">' + (link.scanning ? 'أدوّر على المكاين القريبة…' :
        Object.keys(link.found).length ? 'ما فيه مكينة بهذا الرقم قريبة.' : 'اضغط "دوّر".') + '</p>';
    }
    return items.map(function (d) {
      var busy = setupPicked === d.address && link.state === 'connecting';
      return '<button class="dev" data-act="pickmachine" data-addr="' + esc(d.address) + '">xBloom <b>' +
        esc(Link.machineCode(d.name)) + '</b>' + (busy ? ' <small>يتصل…</small>' : '') + '</button>';
    }).join('');
  }

  // -------------------------------------------------------------- settings
  function renderSettings() {
    var m = link.machine, st = link.status(), conn = link.state === 'connected';
    var problem = { no_bluetooth: 'هذي الشاشة ما فيها بلوتوث شغّال.', off: 'البلوتوث مقفل — شغّله من إعدادات أندرويد.',
      no_permission: 'التطبيق يحتاج صلاحية الموقع/البلوتوث عشان يدوّر على المكينة.',
      no_bridge: 'ما وصلت لجهاز الجسر (ESP32) — تأكد إنه موصول بالكهرباء وعلى نفس شبكة الواي فاي.' }[st];
    var found = Object.keys(link.found).map(function (a) {
      var d = link.found[a];
      return '<button class="dev" data-act="connect" data-addr="' + esc(a) + '">' + esc(d.name) + ' <small>' + esc(a) + '</small></button>';
    }).join('');
    function seg(label, act, cur, opts) {
      return '<div class="field"><label>' + label + '</label><div class="seg">' + opts.map(function (o) {
        return '<button data-act="' + act + '" data-v="' + o[0] + '" class="' + (cur === o[0] ? 'on' : '') + '"' + (conn ? '' : ' disabled') + '>' + o[1] + '</button>';
      }).join('') + '</div></div>';
    }
    var up = (function () {
      var p = OTA.pending();
      var head = '<section class="card"><h4>' + icon('download') + 'التحديثات</h4>';
      if (!OTA.present()) return head + '<p class="hint">التحديث التلقائي يشتغل على شاشة الساقي.</p></section>';
      var cur = '<p>الإصدار: <b>' + esc(WEB_LABEL) + '</b></p>';
      if (p) {
        var notes = (p.notes || []).map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('');
        return head + cur +
          '<div class="notice ok">' + icon('download') + 'يتوفر تحديث' + (p.label ? ' ' + esc(p.label) : '') + ': ' + esc(p.title) + (p.kind === 'apk' ? ' (تحديث النظام)' : '') + '</div>' +
          (notes ? '<ul class="ota-notes">' + notes + '</ul>' : '') +
          '<div class="row"><button class="primary" data-act="otaapply">تحديث الآن</button>' +
          '<button data-act="otacheck">تحقق</button></div></section>';
      }
      var err = OTA.lastError();
      if (err) return head + cur + '<div class="notice bad">' + icon('alert') + esc(OTA.reason(err, 'check')) + '</div>' +
        '<p class="hint" dir="ltr" style="font-size:13px">' + esc(err) + '</p>' +
        '<div class="row"><button data-act="otacheck">التحقق من التحديثات</button></div></section>';
      return head + cur + '<p class="hint">أنت على آخر إصدار.</p>' +
        '<div class="row"><button data-act="otacheck">التحقق من التحديثات</button></div></section>';
    })();
    var cs = cupStats();
    var statsCard = '<section class="card"><h4>' + icon('cup') + 'الإحصائيات</h4>' +
      '<div class="stats"><div class="stat"><b>' + cs.today + '</b><small>أكواب اليوم</small></div>' +
      '<div class="stat"><b>' + cs.total + '</b><small>الإجمالي</small></div></div>' +
      '<div class="row"><button data-act="history">' + icon('check') + 'سجل التحضير</button></div></section>';
    // Cleaning: how long since, a reminder interval, and plain steps. The
    // descaling procedure itself is xBloom's, so we point to it, not guess it.
    var cl = cleanState(), due = cleanDue();
    var cleanCard = '<section class="card"><h4>' + icon('drop') + 'تنظيف المكينة</h4>' +
      (due ? '<div class="notice warn">' + icon('alert') + 'حان وقت التنظيف</div>' : '') +
      '<p>آخر تنظيف: <b>' + (cleanDays() === 0 ? 'اليوم' : (curLang() === 'en' ? cleanDays() + ' days ago' : 'قبل ' + cleanDays() + ' يوم')) + '</b> · ' + (cl.cups || 0) + ' كوب من بعده</p>' +
      '<ol class="howto"><li>اغسل القمع ومصفاة الشاي وصينية الميزان بماء دافي.</li>' +
      '<li>فرّغ خزان الماء واغسله، وعبّه بماء جديد.</li>' +
      '<li>نظّف فتحة المطحنة من بقايا البن بفرشاة ناشفة.</li>' +
      '<li>إزالة الترسبات: اتبع طريقة xBloom في دليل المكينة أو تطبيقهم.</li></ol>' +
      '<div class="field"><label>ذكّرني كل</label><div class="seg">' + [50, 100, 200].map(function (n) {
        return '<button data-act="cleanevery" data-v="' + n + '" class="' + (cl.every === n ? 'on' : '') + '">' + n + ' ' + (curLang() === 'en' ? 'cups' : 'كوب') + '</button>';
      }).join('') + '</div></div>' +
      '<div class="row"><button class="primary" data-act="cleandone">' + icon('check') + 'نظّفتها الحين</button></div></section>';
    var guard = '<section class="card"><h4>' + icon('slot') + 'الحماية والتنبيهات</h4>' +
      '<div class="field"><label>قفل الإعدادات برقم سري</label><div class="row">' +
      (hasPin()
        ? '<button data-act="pinset">تغيير الرقم</button><button class="danger" data-act="pinremove">إزالة القفل</button>'
        : '<button class="primary" data-act="pinset">تعيين رقم سري</button>') +
      '</div></div>' +
      '<div class="field"><label>مساعد الطعم بعد التحضير</label><div class="seg">' +
      '<button data-act="tastemode" data-v="owner" class="' + (tasteMode() === 'owner' ? 'on' : '') + '">' + icon('lock', 'mark') + 'لي بس</button>' +
      '<button data-act="tastemode" data-v="off" class="' + (tasteMode() === 'off' ? 'on' : '') + '">مقفول</button></div>' +
      (hasPin() ? '' : '<p class="hint">يشتغل بعد ما تعيّن رقم سري.</p>') + '</div>' +
      '<div class="field"><label>صوت التنبيه عند الانتهاء</label><div class="seg">' +
      '<button data-act="sound" data-v="on" class="' + (soundOn() ? 'on' : '') + '">صوت</button>' +
      '<button data-act="sound" data-v="off" class="' + (soundOn() ? '' : 'on') + '">صامت</button></div></div></section>';
    var langCard = '<section class="card"><h4>' + icon('book') + (curLang() === 'en' ? 'Language' : 'اللغة / Language') + '</h4><div class="seg">' +
      '<button data-act="lang" data-v="ar" class="' + (curLang() === 'ar' ? 'on' : '') + '">العربية</button>' +
      '<button data-act="lang" data-v="en" class="' + (curLang() === 'en' ? 'on' : '') + '">English</button></div></section>';
    $view.innerHTML = '<div class="settings">' + langCard + up + statsCard + cleanCard + guard +
      (viaBridge ? '<section class="card"><h4>جهاز الجسر (ESP32)</h4>' +
        '<p>الجسر: <b>' + esc(transport.id || '—') + '</b> · ' + (st === 'ok' ? 'متصل' : 'غير متصل') +
        (transport.host ? ' <small>' + esc(transport.host) + '</small>' : '') + '</p>' + wifiLine() +
        '<div class="row"><button data-act="findbridge">دوّر على الجسر</button>' +
        '<input id="bridgehost" placeholder="أو اكتب عنوانه، مثل 192.168.8.50" value="' + esc(transport.host || '') + '">' +
        '<button data-act="setbridge">اتصل</button></div></section>' : '') +
      '<section class="card"><h4>الاتصال بالمكينة</h4>' +
      (problem ? '<div class="notice bad">' + icon('alert') + problem + '</div>' : '') +
      '<p>المكينة: <b>' + (link.savedName() ? esc(Link.machineCode(link.savedName())) : '—') + '</b> · ' +
      ({ connected: 'متصل', connecting: 'جاري الاتصال…', disconnected: 'غير متصل' }[link.state]) + '</p>' +
      '<div class="row">' +
      (conn ? '<button data-act="disconnect">قطع الاتصال</button>'
        : '<button class="primary" data-act="scan"' + (link.scanning ? ' disabled' : '') + '>' + (link.scanning ? 'يدوّر…' : 'دوّر على المكينة') + '</button>') +
      '<button data-act="resetup">ربط مكينة ثانية</button></div>' +
      (found ? '<div class="devs">' + found + '</div>' : '') +
      '<p class="hint">المكينة تقبل اتصال واحد بس. إذا تبي تستخدم تطبيق الجوال، اقطع الاتصال من هنا أول.</p></section>' +
      '<section class="card"><h4>إعدادات المكينة</h4><div class="grid">' +
      seg('مصدر الماء', 'water', m.waterSource, [['tank', 'الخزان'], ['tap', 'الحنفية']]) +
      seg('الوضع', 'mode', m.mode, [['auto', 'Auto'], ['pro', 'Pro']]) +
      seg('وحدة الوزن', 'wunit', m.weightUnit, [['g', 'جرام'], ['ml', 'مل'], ['oz', 'أونصة']]) +
      seg('وحدة الحرارة', 'tunit', m.tempUnit, [['c', '°م'], ['f', '°ف']]) +
      '</div><div class="row"><button data-act="tare"' + (conn ? '' : ' disabled') + '>تصفير الميزان</button></div>' +
      '<p class="hint">' + (m.serial ? 'الرقم التسلسلي: ' + esc(m.serial) + ' · ' : '') + (m.fw ? 'النسخة: ' + esc(m.fw) : '') + '</p></section>' +
      '</div>';
  }

  // ------------------------------------------------------------ header bar
  function renderBar() {
    var m = link.machine;
    var wt = document.getElementById('st-weight'), wa = document.getElementById('st-water');
    wt.querySelector('.ic').innerHTML = icon('scale').replace(/^<span class="ic">|<\/span>$/g, '');
    wt.querySelector('b').textContent = m.weight === null ? '—' : fmt(m.weight, 1) + ' ' + L('جم');
    wa.querySelector('.ic').innerHTML = icon('drop').replace(/^<span class="ic">|<\/span>$/g, '');
    wa.querySelector('b').textContent = m.waterEnough === null ? 'الماء —' : (m.waterEnough ? 'الماء تمام' : 'الماء ناقص');
    wa.className = 'pill' + (m.waterEnough === false ? ' bad' : '');
    var c = document.getElementById('st-conn');
    c.querySelector('b').textContent = { connected: 'متصل', connecting: 'يتصل…', disconnected: link.scanning ? 'يدوّر…' : 'غير متصل' }[link.state];
    c.className = 'pill conn ' + link.state;
  }

  // ---------------------------------------------------------------- actions
  function fail(err) { toast(REASON_AR[err && err.reason] || 'صار خطأ', true); }

  function act(el) {
    var a = el.getAttribute('data-act');
    var r = byId(selected);
    switch (a) {
      case 'go':
        draft = null;
        var dv = el.getAttribute('data-view');
        if (dv !== 'guide') fromWelcome = false;
        // Settings behind a PIN: show the lock first (once per session).
        if (dv === 'settings' && hasPin() && !settingsUnlocked) { pinInput = ''; pinMode = 'enter'; go('lock'); break; }
        go(dv); break;
      case 'pinkey': pinDigit(el.getAttribute('data-k')); break;
      case 'pinclear': pinInput = ''; renderLock(); break;
      case 'pinback': pinInput = pinInput.slice(0, -1); renderLock(); break;
      case 'pinset': pinInput = ''; pinMode = 'set'; go('lock'); break;
      case 'pinremove':
        if (confirm(L('إزالة القفل عن الإعدادات؟'))) { clearPin(); toast('انشال القفل'); renderSettings(); }
        break;
      case 'lang': setLang(el.getAttribute('data-v')); break;
      case 'sound': setSound(el.getAttribute('data-v') === 'on'); renderSettings(); if (el.getAttribute('data-v') === 'on') chime(); break;
      case 'enter':
        if (!link.savedAddress()) { go('setup'); break; }
        fromWelcome = true;  // came via the Start button -> show the guide intro
        go('guide');
        break;
      case 'diagrefresh': renderDiag(); break;
      case 'otaapply': OTA.apply(); break;
      case 'otalater': OTA.later(); break;
      case 'otacheck': toast('نتحقق من التحديثات…'); OTA.check(true); break;
      case 'guidemode': var gm = el.getAttribute('data-v'); guideMode = gm === 'tea' || gm === 'dial' ? gm : 'coffee'; renderGuide(); break;
      case 'guidedone': case 'guideskip': fromWelcome = false; guideIntro = false; go('home'); break;
      case 'share': shareId = r.id; go('share'); break;
      case 'fav': r.fav = !r.fav; saveRecipes(); renderHome(); break;
      case 'library': go('library'); break;
      case 'phone': phoneOpen(); go('phone'); break;
      case 'phoneagain': phoneOpen(); renderPhone(); break;
      case 'addlib':
        var lp = LIBRARY[Number(el.getAttribute('data-i'))];
        if (!lp) break;
        var nr = lp.tea ? teaRecipe(lp) : starter(lp.name, lp.dose, lp.ratio, lp.grind, lp.temp, lp.n);
        recipes.push(nr); selected = nr.id; saveRecipes(); toast('أضفنا «' + lp.name + '»'); go('home'); break;
      case 'receive': go('scan'); break;
      case 'scancancel': stopScan(); go('home'); break;
      case 'towelcome': goWelcome(); break;
      case 'pick': selected = el.getAttribute('data-id'); renderHome(); break;
      case 'new':
        draft = starter('وصفة جديدة', 15, 16, 50, 92, 3); draft.isNew = true; go('edit'); break;
      case 'edit': draft = JSON.parse(JSON.stringify(r)); go('edit'); break;
      case 'dup':
        var copy = JSON.parse(JSON.stringify(r));
        copy.id = 'r' + Math.random().toString(36).slice(2, 9); copy.name = r.name + ' (نسخة)';
        recipes.push(copy); selected = copy.id; saveRecipes(); renderHome(); break;
      case 'del':
        if (!confirm(L('تحذف "') + r.name + L('"؟'))) return;
        recipes = recipes.filter(function (x) { return x.id !== r.id; }); selected = null; saveRecipes(); renderHome(); break;
      case 'brew':
        if (XB.validate(r).length) return toast('الوصفة فيها مشكلة — عدّلها أول', true);
        prep = { id: r.id, rinse: '', err: null };
        expandFrom(el.closest ? el.closest('.hero') || el : el, function () { go('prep'); });
        break;
      case 'prepback': prep = null; go('home'); break;
      case 'preptare': link.send('tare', XB.packets.tare()).then(function () { toast('تم تصفير الميزان'); }, fail); break;
      case 'preprinse': startRinse(); break;
      case 'preprinsestop': link.stopBrew().catch(fail); break;
      case 'prepgo':
        var pr = prep && byId(prep.id);
        if (!pr) { go('home'); break; }
        if (XB.validate(pr).length) return toast('الوصفة فيها مشكلة — عدّلها أول', true);
        prep = null;
        expandFrom(el, function () { link.startBrew(JSON.parse(JSON.stringify(pr))).catch(function () {}); });
        break;
      case 'slot':
        var s = prompt(L('أي زر بالمكينة؟ اكتب A أو B أو C'), 'A');
        if (!s) return;
        var idx = { A: 0, B: 1, C: 2 }[s.trim().toUpperCase()];
        if (idx === undefined) return toast('اكتب A أو B أو C', true);
        link.send('slot', XB.packets.slotWrite(idx, r, true), { timeout: 3000 })
          .then(function () { toast('انحفظت في زر ' + s.trim().toUpperCase() + ' — تقدر تشغلها من المكينة بوضع Auto'); }, fail);
        break;
      case 'pause': link.pauseBrew().catch(fail); break;
      case 'resume': link.resumeBrew().catch(fail); break;
      case 'stop':
        if (confirm(L('توقف التحضير؟'))) link.stopBrew().catch(fail);
        break;
      case 'brewok':
        if (dial && dial.step === 'brewing') {
          var dialOk = link.brew.phase === 'done';
          link.clearBrew(); dial.step = dialOk ? 'rate' : 'cup'; go('dial'); break;
        }
        link.clearBrew(); go('home'); break;
      // Owner only (it uses beans): always behind the PIN.
      case 'dial': if (!hasPin()) break; pinInput = ''; pinMode = 'dial'; go('lock'); break;
      case 'dialknob':
        var dbn = document.getElementById('dialbean'); if (dbn) dial.bean = dbn.value.trim().slice(0, 24);
        dialSetKnob(el.getAttribute('data-v') === 'temp' ? 'temp' : 'grind'); renderDial(); break;
      case 'dialgo':
        var db = document.getElementById('dialbean'); dial.bean = db ? db.value.trim().slice(0, 24) : '';
        dial.step = 'cup'; renderDial(); break;
      case 'dialbrew':
        var dr = dialRecipe(false);
        dr.id = 'dial-test'; dr.dial = true; dr.name = dr.name + ' · ' + dialLabel(dial.values[dial.i]);
        if (XB.validate(dr).length) { toast('الكوب التجريبي يطلع برا حدود المكينة', true); break; }
        dial.step = 'brewing';
        link.startBrew(dr).catch(function () { dial.step = 'cup'; renderDial(); });
        break;
      case 'dialrate':
        dial.ratings[dial.i] = Number(el.getAttribute('data-v'));
        if (dial.i < dial.values.length - 1) { dial.i++; dial.step = 'cup'; } else dial.step = 'result';
        renderDial(); break;
      case 'dialretry': dial.step = 'cup'; renderDial(); break;
      case 'dialagain':
        var dbase = byId(dial.baseId), dbest = dial.values[Number(el.getAttribute('data-i'))];
        dial.values = dialValues(dbase, dial.knob, dbest, 2); dial.ratings = []; dial.i = 0; dial.step = 'cup';
        renderDial(); break;
      case 'dialsave':
        dial.i = Number(el.getAttribute('data-i'));
        var dsave = dialRecipe(true), dfrom = byId(dial.baseId);
        dsave.id = 'r' + Math.random().toString(36).slice(2, 9);
        dsave.name = (dfrom.name + ' · ' + (dial.bean || (curLang() === 'en' ? 'tuned' : 'مضبوطة'))).slice(0, 40);
        dsave.uses = 0; dsave.fav = false;
        if (XB.validate(dsave).length) { toast('ما قدرنا نحفظها — برا حدود المكينة', true); break; }
        recipes.push(dsave); selected = dsave.id; saveRecipes();
        toast('انحفظت «' + dsave.name + '»'); dial = null; go('home'); break;
      case 'dialquit':
        if (dial && dial.ratings.length && !confirm(L('توقف الضبط؟ بتضيع التقييمات.'))) break;
        dial = null; go('home'); break;
      case 'taste':
        tasteChoice = el.getAttribute('data-v');
        setTaste(link.brew.startedAt, tasteChoice);
        redrawTaste(); break;
      case 'tasteapply':
        var tr = link.brew.recipe && byId(link.brew.recipe.id), tf = tr && tasteFix(tr, tasteChoice);
        if (tf) {
          var trial = JSON.parse(JSON.stringify(tr)); tf.apply(trial);
          if (XB.validate(trial).length) { toast('ما نقدر نطبّقه — يطلع برا حدود المكينة', true); break; }
          tf.apply(tr); saveRecipes(); tasteChoice = 'applied'; toast('عدّلنا «' + tr.name + '»');
        }
        redrawTaste(); break;
      case 'tasteunlock': pinInput = ''; pinMode = 'taste'; go('lock'); break;
      case 'tastemode': try { localStorage.setItem('xb.taste', el.getAttribute('data-v')); } catch (e) { /* */ } renderSettings(); break;
      case 'tasteskip': tasteChoice = 'good_skip'; var tsEl = document.getElementById('taste'); if (tsEl) tsEl.innerHTML = ''; break;
      case 'history': go('history'); break;
      case 'cleandone': var cs0 = cleanState(); cs0.at = Date.now(); cs0.cups = 0; saveClean(cs0); toast('تمام — بنذكّرك المرة الجاية'); render(); break;
      case 'cleanevery': var cs1 = cleanState(); cs1.every = Number(el.getAttribute('data-v')) || 100; saveClean(cs1); renderSettings(); break;
      // editor
      case 'step':
        if (stepHeld) { stepHeld = false; break; }  // a press-and-hold already stepped
        stepOnce(el); break;
      case 'set':
        var p2 = el.getAttribute('data-path'), raw = el.getAttribute('data-v');
        setPath(draft, p2, Number(raw));
        if (p2 === 'cup_type') {
          var cup = XB.CUP_TYPES.filter(function (c) { return c.api === draft.cup_type; })[0];
          draft.dose_g = Math.min(cup.dose[1], Math.max(cup.dose[0], draft.dose_g));
        }
        keepName(); renderEdit(); break;
      case 'drink':
        keepName();
        var toTea = el.getAttribute('data-v') === 'tea';
        if (toTea && !isTea(draft)) {
          draft.cup_type = 4; draft.grinder_size_enabled = 0;
          if (draft.dose_g > 5 || draft.dose_g < 1) draft.dose_g = 4;
          draft.pours.forEach(function (p) { if (p.temperature_c < 70) p.temperature_c = 90; if (p.volume_ml < 80) p.volume_ml = 150; });
        } else if (!toTea && isTea(draft)) {
          draft.cup_type = 2; draft.grinder_size_enabled = 1;
          if (draft.dose_g < 5) draft.dose_g = 15;
        }
        renderEdit(); break;
      case 'auto':
        keepName();
        draft.pours = XB.autoPours(draft.dose_g, Number(el.getAttribute('data-ratio')), draft.pours.length,
          draft.pours[0] ? draft.pours[0].temperature_c : 92);
        renderEdit(); break;
      case 'addpour':
        keepName();
        var last = draft.pours[draft.pours.length - 1];
        draft.pours.push(JSON.parse(JSON.stringify(last))); renderEdit(); break;
      case 'delpour':
        keepName(); draft.pours.splice(Number(el.getAttribute('data-i')), 1); renderEdit(); break;
      case 'save':
        keepName();
        if (!draft.name.trim()) return toast('اكتب اسم للوصفة', true);
        var isNew = draft.isNew; delete draft.isNew;
        if (isNew) recipes.push(draft);
        else recipes = recipes.map(function (x) { return x.id === draft.id ? draft : x; });
        selected = draft.id; draft = null; saveRecipes(); toast('انحفظت'); go('home'); break;
      case 'cancel': draft = null; go('home'); break;
      // settings
      case 'findbridge':
        toast('أدوّر على الجسر…');
        transport.find(function (pick, all) {
          if (pick) toast('لقيت الجسر ' + (pick.id || pick.ip));
          else if (all.length > 1) toast('لقيت ' + all.length + ' — اختر جسرك');
          else toast('ما لقيته — تأكد إنه على نفس الشبكة', true);
          render();
        });
        break;
      case 'pickbridge': transport.choose(transport.found[Number(el.getAttribute('data-i'))]); toast('أتصل بالجسر…'); break;
      case 'wifi': XBNative.openWifiSettings(); break;
      case 'pickmachine':
        setupPicked = el.getAttribute('data-addr');
        link.connect(setupPicked);
        renderSetup();
        break;
      case 'setupdone': setupPicked = null; go('home'); break;
      case 'resetup':
        if (!confirm(L('تربط الشاشة بمكينة ثانية؟'))) return;
        link.forget(); setupCode = ''; setupPicked = null; go('setup');
        if (link.status() === 'ok') link.scan();
        break;
      case 'setbridge':
        var h = document.getElementById('bridgehost').value.trim();
        if (h) { transport.setHost(h); toast('أتصل بالجسر…'); }
        break;
      case 'scan':
        var st = link.status();
        if (st !== 'ok') { render(); return toast(viaBridge ? 'الجسر مو متصل' : 'البلوتوث مو جاهز', true); }
        link.scan(); render(); break;
      case 'connect': link.connect(el.getAttribute('data-addr')); break;
      case 'disconnect': link.disconnect(); break;
      case 'forget': link.forget(); renderSettings(); break;
      case 'water': link.send('water', XB.packets.waterSource(el.getAttribute('data-v'))).catch(fail); break;
      case 'mode': link.send('mode', XB.packets.mode(el.getAttribute('data-v'))).catch(fail); break;
      case 'wunit': link.send('unit', XB.packets.weightUnit(el.getAttribute('data-v'))).catch(fail); break;
      case 'tunit': link.send('unit', XB.packets.tempUnit(el.getAttribute('data-v'))).catch(fail); break;
      case 'tare': link.send('tare', XB.packets.tare()).then(function () { toast('تم تصفير الميزان'); }, fail); break;
    }
  }
  function keepName() { var n = document.getElementById('name'); if (n && draft) draft.name = n.value; }

  document.addEventListener('input', function (e) {
    if (e.target.id !== 'mcode') return;
    setupCode = e.target.value;
    var list = document.getElementById('devlist');
    if (list) list.innerHTML = machineList();
  });

  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('[data-act]') : null;
    if (el && !el.disabled) act(el);
  });

  // + / − buttons: a tap moves one step (water goes 1 ml at a time), and
  // holding the button keeps stepping, faster after a moment, so going from
  // 60 to 150 doesn't take 90 taps. The editor redraws on every step, so the
  // repeat works from the button's data, not the (replaced) element.
  var stepHeld = false, stepTimer = null;
  function stepOnce(el) {
    var path = el.getAttribute('data-path'), d = parseFloat(el.getAttribute('data-d'));
    var v = Math.round((Number(getPath(draft, path)) + d) * 10) / 10;
    v = Math.min(parseFloat(el.getAttribute('data-max')), Math.max(parseFloat(el.getAttribute('data-min')), v));
    setPath(draft, path, v); keepName(); renderEdit();
  }
  function stepHoldStop() { if (stepTimer) { clearTimeout(stepTimer); stepTimer = null; } }
  var lastTouch = 0;
  function stepHoldStart(e) {
    // A finger also fires a pretend mouse press after it lifts; ignore that one.
    if (e.type === 'touchstart') lastTouch = Date.now();
    else if (Date.now() - lastTouch < 1000) return;
    var el = e.target.closest ? e.target.closest('[data-act="step"]') : null;
    if (!el || el.disabled || !draft) return;
    stepHoldStop(); stepHeld = false;
    var data = {
      getAttribute: function (k) { return this[k]; },
      'data-path': el.getAttribute('data-path'), 'data-d': el.getAttribute('data-d'),
      'data-min': el.getAttribute('data-min'), 'data-max': el.getAttribute('data-max')
    };
    var n = 0;
    function tick() {
      if (!draft || view !== 'edit') return stepHoldStop();
      stepHeld = true; n++;
      stepOnce(data);
      stepTimer = setTimeout(tick, n < 8 ? 160 : 60);
    }
    stepTimer = setTimeout(tick, 450);
  }
  document.addEventListener('touchstart', stepHoldStart);
  document.addEventListener('mousedown', stepHoldStart);

  // A ripple where the finger lands, on a fixed layer of its own (so no
  // button's layout changes). The mouse event a touch fakes is skipped.
  var lastFxTouch = 0;
  function tapFx(e) {
    var t = e.touches ? e.touches[0] : e;
    if (!t) return;
    if (e.touches) lastFxTouch = Date.now();
    else if (Date.now() - lastFxTouch < 1000) return;
    var fx = document.createElement('i');
    fx.className = 'tapfx' + (document.body.classList.contains('in-welcome') ? ' light' : '');
    fx.style.left = t.clientX + 'px'; fx.style.top = t.clientY + 'px';
    document.body.appendChild(fx);
    setTimeout(function () { if (fx.parentNode) fx.parentNode.removeChild(fx); }, 700);
  }
  document.addEventListener('touchstart', tapFx, true);
  document.addEventListener('mousedown', tapFx, true);
  ['touchend', 'touchcancel', 'mouseup', 'mouseleave'].forEach(function (t) { document.addEventListener(t, stepHoldStop); });
  document.addEventListener('contextmenu', function (e) {
    if (e.target.closest && e.target.closest('[data-act="step"]')) e.preventDefault();
  });

  link.on(function (what) {
    renderBar();
    if (isRinse()) {
      var rph = link.brew.phase;
      if (['done', 'stopped', 'failed'].indexOf(rph) >= 0) {
        loggedBrewAt = countedBrewAt = link.brew.startedAt; // a rinse isn't a cup
        if (prep) { prep.rinse = rph === 'done' ? 'done' : rph === 'failed' ? 'failed' : ''; prep.err = link.brew.error || link.brew.fault || null; }
        if (rph === 'done') chime();
        setTimeout(function () { if (isRinse()) link.clearBrew(); }, 0);
      }
      if (what === 'machine') return updatePrep();
      if (view !== 'welcome') { view = 'prep'; render(); }
      return;
    }
    if (what === 'machine' && view === 'prep') return updatePrep();
    // Log every brew once it ends, however it ended.
    if (['done', 'stopped', 'failed'].indexOf(link.brew.phase) >= 0 && link.brew.startedAt && link.brew.startedAt !== loggedBrewAt) {
      loggedBrewAt = link.brew.startedAt;
      logBrew(link.brew, link.machine);
    }
    // Count a cup once, the moment a brew finishes, and bump that recipe's use.
    if (link.brew.phase === 'done' && link.brew.startedAt && link.brew.startedAt !== countedBrewAt) {
      countedBrewAt = link.brew.startedAt;
      bumpCup();
      bumpClean();
      chime(); // a ready chime
      var done = link.brew.recipe && byId(link.brew.recipe.id);
      if (done) { done.uses = (done.uses || 0) + 1; saveRecipes(); }
    }
    if (view === 'welcome') { if (what === 'state' || what === 'brew') render(); return; }
    if (view === 'setup') {
      if (what === 'scan') {
        var list = document.getElementById('devlist');
        if (list) return void (list.innerHTML = machineList());
      }
      if (what === 'state') {
        if (setupPicked && link.state === 'disconnected' && link.detail && link.detail !== 'bridge_offline') {
          toast('ما قدرت أتصل — قرّب الشاشة/الجسر من المكينة وجرّب ثانية', true);
        }
        renderSetup();
        // The bridge just answered: look for machines straight away.
        if (setupStep() === 'machine' && !link.scanning && !Object.keys(link.found).length && link.status() === 'ok') link.scan();
      }
      return;
    }
    if (what === 'brew') { render(); OTA.refresh(); return; }
    if (what === 'state' || what === 'scan') {
      if (view === 'settings' || view === 'home') render();
      if (what === 'state' && link.state === 'connected') toast('اتصلت بالمكينة');
    }
    if (what === 'machine' && link.isBrewing()) return renderBrew();
    if (what === 'machine' && view === 'settings') {
      // Redraw only when a shown value changed: a redraw under a finger eats the tap.
      var m = link.machine;
      var key = [m.waterSource, m.mode, m.weightUnit, m.tempUnit, m.serial, m.fw].join('|');
      if (key !== lastSettingsKey) { lastSettingsKey = key; renderSettings(); }
    }
  });

  Array.prototype.forEach.call(document.querySelectorAll('[data-icon]'), function (el) {
    el.outerHTML = icon(el.getAttribute('data-icon'));
  });

  // The logo: a tap goes back to the welcome screen; holding it 3 seconds is
  // the way out of the kiosk to Android settings.
  var brand = document.querySelector('.brand'), holdTimer, held = false;
  function holdStart() {
    held = false;
    holdTimer = setTimeout(function () {
      held = true;
      if (window.XBNative && XBNative.openSettings) XBNative.openSettings();
      else toast('إعدادات أندرويد (على الشاشة فقط)');
    }, 3000);
  }
  function holdEnd() { clearTimeout(holdTimer); }
  brand.addEventListener('touchstart', holdStart);
  brand.addEventListener('mousedown', holdStart);
  ['touchend', 'touchcancel', 'mouseup', 'mouseleave'].forEach(function (e) { brand.addEventListener(e, holdEnd); });
  brand.addEventListener('click', function () { if (!held) goWelcome(); });

  // Tap the small "xBloom" word in the header 5 times to open the diagnosis screen.
  var prodTaps = 0, prodTimer;
  var product = document.querySelector('.product');
  if (product) product.addEventListener('click', function (e) {
    e.stopPropagation();
    prodTaps++;
    clearTimeout(prodTimer);
    prodTimer = setTimeout(function () { prodTaps = 0; }, 1200);
    if (prodTaps >= 5) { prodTaps = 0; go('diag'); }
  });

  function goWelcome() {
    if (link.isBrewing()) return; // the brew screen stays up while coffee is being made
    draft = null;
    go('welcome');
  }

  // Left alone for a while, the screen goes back to the welcome screen — but
  // never mid-brew or with an unsaved recipe open.
  var IDLE_MS = 5 * 60 * 1000, idleTimer;
  function resetIdle() {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(function () {
      // Not while someone is sending a recipe from their phone, either.
      if (view !== 'welcome' && view !== 'edit' && !phoneLive() && !dialActive() && !link.isBrewing()) goWelcome();
      else resetIdle();
    }, IDLE_MS);
  }
  ['touchstart', 'mousedown', 'keydown'].forEach(function (e) { document.addEventListener(e, resetIdle, true); });
  resetIdle();

  // Keep the welcome-screen clock ticking.
  setInterval(function () {
    if (view === 'welcome') { var c = document.getElementById('splashclock'); if (c) c.textContent = clockStr(); }
  }, 15000);

  // A finished cup left on screen: after a minute with nobody touching it,
  // go back to the welcome screen by itself, with a countdown under «تمام».
  // Not mid dial-in (that screen waits for the owner to rate the cup).
  var AFTER_BREW_S = 60, afterBrewFrom = 0;
  setInterval(function () {
    var fin = ['done', 'stopped', 'failed'].indexOf(link.brew.phase) >= 0;
    if (!fin || (dial && dial.step === 'brewing')) { afterBrewFrom = 0; return; }
    if (!afterBrewFrom) afterBrewFrom = Date.now();
    var left = Math.ceil(AFTER_BREW_S - (Date.now() - afterBrewFrom) / 1000);
    if (left <= 0) { afterBrewFrom = 0; link.clearBrew(); goWelcome(); return; }
    var bye = document.getElementById('brewbye');
    if (bye) {
      var t = left <= 15 ? L('ترجع الشاشة للبداية بعد') + ' ' + left + ' ' + L('ث') : '';
      if (bye.textContent !== t) bye.textContent = t;
    }
  }, 1000);
  ['touchstart', 'mousedown'].forEach(function (e) {
    document.addEventListener(e, function () { if (afterBrewFrom) afterBrewFrom = Date.now(); }, true);
  });

  startLangObserver(); // sets lang/dir; rewrites rendered text when English
  renderBar();
  view = 'welcome';
  render();
  animateIn();
  translateTree(document.body); // static bits (tabs, header) outside the re-rendered view
  OTA.init(); // check for updates in the background
  if (viaBridge) {
    // The bridge reports its link as soon as it answers; if that link is down,
    // connect to the remembered machine (or look for one) straight away.
    var looked = false;
    link.on(function (what) {
      if (what === 'state' && !looked && transport.status() === 'ok') {
        looked = true;
        if (link.state !== 'connected' && !link.autoConnect()) link.scan();
      }
    });
    transport.start();
  } else if (link.status() === 'ok') {
    if (!link.autoConnect()) link.scan();
  } else go('setup');
})();
