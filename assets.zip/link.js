/*
 * Link: talks to the machine through a transport and keeps the machine's
 * live state. Transport = window.XBNative (Android BLE bridge) or the mock in
 * the browser preview. Both call back into window.xbNative.on*.
 *
 * Transport API (strings only, so it crosses the Android JS bridge):
 *   status() -> "ok" | "no_bluetooth" | "off" | "no_permission"
 *   startScan() / stopScan() / connect(address) / disconnect() / write(hex)
 * Callbacks:
 *   xbNative.onScan(name, address, rssi)
 *   xbNative.onState(state, detail)   state: disconnected|connecting|connected
 *   xbNative.onNotify(hex)
 */
(function (root) {
  'use strict';

  var ECHO_TIMEOUT = 1500, BREW_STEP_TIMEOUT = 3000, BREW_STEP_ATTEMPTS = 2, SETTLE = 100;
  var HOME_ACTIVITIES = [1, 65], MODULE_ACTIVITIES = [2, 3, 4, 5];
  var ACT_BREWING = 34, ACT_DONE = 36;

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function Link(transport) {
    this.t = transport;
    this.assembler = new XB.Assembler();
    this.waiters = {};          // command code -> {resolve}
    this.listeners = [];
    this.found = {};            // address -> {name, address, rssi}
    this.state = 'disconnected';
    this.address = this.savedAddress();
    this.machine = {
      weight: null, water: null, activity: null, waterEnough: null, waterSource: null,
      mode: null, weightUnit: null, tempUnit: null, fw: null, serial: null, sleeping: false
    };
    this.brew = { phase: 'idle', pour: 0, pours: 0, startedAt: 0, recipe: null, error: null, fault: null };
    var self = this;
    root.xbNative = {
      onScan: function (name, address, rssi) { self._onScan(name, address, rssi); },
      onState: function (state, detail) { self._onState(state, detail); },
      onNotify: function (hex) { self._onNotify(hex); }
    };
  }

  Link.prototype.on = function (fn) { this.listeners.push(fn); };
  Link.prototype.emit = function (what) {
    var self = this;
    this.listeners.forEach(function (fn) { try { fn(what, self); } catch (e) { console.error(e); } });
  };

  Link.prototype.status = function () { return this.t.status(); };
  Link.prototype.scan = function () {
    this.found = {};
    this.t.startScan();
    this.scanning = true;
    this.emit('scan');
    var self = this;
    clearTimeout(this._scanTimer);
    this._scanTimer = setTimeout(function () { self.stopScan(); }, 15000);
  };
  Link.prototype.stopScan = function () {
    if (!this.scanning) return;
    this.scanning = false;
    this.t.stopScan();
    this.emit('scan');
  };
  Link.prototype.connect = function (address) {
    this.stopScan();
    this.address = address;
    var seen = this.found[address];
    try {
      localStorage.setItem('xb.address', address);
      if (seen) localStorage.setItem('xb.machineName', seen.name);
    } catch (e) { /* preview */ }
    this.t.connect(address);
  };
  Link.prototype.disconnect = function () { this.wantDisconnect = true; this.t.disconnect(); };
  Link.prototype.forget = function () {
    try { localStorage.removeItem('xb.address'); localStorage.removeItem('xb.machineName'); } catch (e) { /* preview */ }
    this.address = null;
    this.disconnect();
  };
  Link.prototype.savedAddress = function () {
    try { return localStorage.getItem('xb.address'); } catch (e) { return null; }
  };

  Link.prototype.savedName = function () {
    try { return localStorage.getItem('xb.machineName'); } catch (e) { return null; }
  };

  // Connects to the machine this screen was set up with. Never picks one by
  // itself: a neighbour's xBloom may be in range too, so the owner chooses
  // theirs once, by its code, in the setup screen.
  Link.prototype.autoConnect = function () {
    var addr = this.savedAddress();
    if (addr) this.connect(addr);
    return !!addr;
  };

  Link.prototype._onScan = function (name, address, rssi) {
    if (!name || name.toUpperCase().indexOf('XBLOOM') !== 0) return;
    this.found[address] = { name: name, address: address, rssi: rssi };
    this.emit('scan');
  };

  Link.prototype._onState = function (state, detail) {
    var was = this.state;
    this.state = state;
    if (state === 'connected' && was !== 'connected') {
      this.assembler.reset();
      this.wantDisconnect = false;
      var self = this;
      // Nudge the machine so it sends its status heartbeat straight away.
      setTimeout(function () { self.send('handshake', XB.packets.handshake()).catch(function () {}); }, 400);
    }
    if (state === 'disconnected') {
      Object.keys(this.waiters).forEach(function (k) { this.waiters[k].resolve({ lost: true }); }, this);
      this.waiters = {};
      // Bluetooth drops when the machine sleeps or is switched off: keep trying.
      var self2 = this;
      if (!this.wantDisconnect && this.address) {
        clearTimeout(this._retry);
        this._retry = setTimeout(function () {
          if (self2.state === 'disconnected' && !self2.wantDisconnect) self2.t.connect(self2.address);
        }, 5000);
      }
    }
    this.detail = detail || '';
    this.emit('state');
  };

  Link.prototype._onNotify = function (hex) {
    var frames = this.assembler.feed(XB.fromHex(hex));
    for (var i = 0; i < frames.length; i++) this._onFrame(frames[i]);
  };

  Link.prototype._onFrame = function (frame) {
    var code = XB.frameCode(frame);
    var w = this.waiters[code];
    if (w) w.resolve({ refusal: XB.refusalCode(frame) });
    // Diagnosis log: keep the last raw water/weight frames so a developer can
    // read exactly what the machine sends (see the hidden diag screen).
    if (code === XB.NOTIFY.WATER || code === XB.NOTIFY.WEIGHT || code === XB.NOTIFY.WEIGHT_ALT) {
      this.rawLog = this.rawLog || [];
      var pl = frame.length > 12 ? frame.subarray(10, frame.length - 2) : new Uint8Array(0);
      var hex = '', f = null, u = null;
      for (var i = 0; i < pl.length; i++) hex += (pl[i] < 16 ? '0' : '') + pl[i].toString(16);
      if (pl.length >= 4) {
        var ddv = new DataView(pl.buffer, pl.byteOffset, pl.length);
        f = Math.round(ddv.getFloat32(0, true) * 1000) / 1000;
        u = ddv.getUint32(0, true);
      }
      this.rawLog.push({ code: code, hex: hex, f: f, u: u });
      if (this.rawLog.length > 40) this.rawLog.shift();
    }
    var d = XB.decode(frame);
    if (!d) return;
    var m = this.machine, b = this.brew, N = XB.NOTIFY;
    if (d.weight_g !== undefined) m.weight = d.weight_g;
    if (d.water_ml !== undefined) m.water = d.water_ml;
    if (d.cmd === N.SLEEPING) m.sleeping = true;
    if (d.cmd === N.AWAKE) m.sleeping = false;
    if (d.cmd === N.MACHINE_INFO) {
      if (d.water_enough !== undefined) m.waterEnough = !!d.water_enough;
      ['water_source', 'mode', 'weight_unit', 'temp_unit', 'fw_version', 'serial'].forEach(function (k) {
        if (d[k] !== undefined && d[k] !== null) m[{ water_source: 'waterSource', weight_unit: 'weightUnit',
          temp_unit: 'tempUnit', fw_version: 'fw' }[k] || k] = d[k];
      });
    }
    this._track(d);
    this.emit('machine');
  };

  function busy(phase) { return ['starting', 'grinding', 'pouring', 'paused'].indexOf(phase) >= 0; }
  Link.prototype.isBrewing = function () { return busy(this.brew.phase); };

  // Follows a brew through the frames the machine sends (see xbloom-studio's
  // brew-status sensor for where each of these was observed).
  Link.prototype._track = function (d) {
    var b = this.brew, N = XB.NOTIFY, cmd = d.cmd, prev = b.phase;
    if (cmd === N.ACTIVITY) {
      this.machine.activity = d.activity;
      if (MODULE_ACTIVITIES.indexOf(d.activity) >= 0) this.onModule = true;
      if (HOME_ACTIVITIES.indexOf(d.activity) >= 0) {
        this.onModule = false;
        if (busy(b.phase) && b.phase !== 'starting' && Date.now() - b.startedAt > 5000) b.phase = 'stopped';
      }
      if (d.activity === ACT_DONE && busy(b.phase)) b.phase = 'done';
      if (d.activity === ACT_BREWING && !busy(b.phase) && !this.onModule) {
        // A brew started with the machine's own button.
        b.phase = 'grinding'; b.startedAt = Date.now(); b.pour = 0; b.pours = 0; b.recipe = null;
        b.error = null; b.fault = null;
      }
    }
    if (this.onModule) return;
    if (cmd === N.GRINDER_START && busy(b.phase)) b.phase = 'grinding';
    if (cmd === N.BLOOM && busy(b.phase)) { b.phase = 'pouring'; b.pour = (d.pour_index || 0) + 1; }
    if (cmd === N.PAUSED || cmd === N.GRINDER_PAUSED || cmd === N.BREWER_PAUSED) {
      if (busy(b.phase)) { b.resumeTo = b.phase === 'paused' ? b.resumeTo : b.phase; b.phase = 'paused'; }
    }
    if ((cmd === N.RESUMED || cmd === N.MACHINE_RESUMED) && b.phase === 'paused') b.phase = b.resumeTo || 'pouring';
    if (cmd === N.ENJOY && busy(b.phase)) b.phase = 'done';
    if (cmd === N.ABANDONED && busy(b.phase)) b.phase = 'stopped';
    if (d.fault) {
      b.fault = d.fault;
      if (d.fault === 'no_water') this.machine.waterEnough = false;
      if (d.fault === 'no_beans' && busy(b.phase)) { b.phase = 'failed'; b.error = 'no_beans'; }
    }
    if (prev !== b.phase) {
      if (b.phase === 'done') b.endedAt = Date.now();
      this.emit('brew');
    }
  };

  // Writes one command and waits for the machine to answer it with its own
  // code. Resolves true on acceptance; rejects with {reason} on a refusal or
  // no answer.
  Link.prototype.send = function (name, frame, opts) {
    opts = opts || {};
    var timeout = opts.timeout || ECHO_TIMEOUT;
    var attempts = opts.attempts || 3;
    var retryAlways = !!opts.retryAlways;
    var self = this, code = XB.frameCode(frame);
    if (this.state !== 'connected') return Promise.reject({ reason: 'not_connected', step: name });
    return new Promise(function (resolve, reject) {
      var attempt = 0, timer = null;
      function finish(r) {
        clearTimeout(timer);
        delete self.waiters[code];
        if (r.lost) return reject({ reason: 'not_connected', step: name });
        if (!r.refusal) return resolve(true);
        if (attempt > 1 && XB.takenOnResend(r.refusal)) return resolve(true);
        reject({ reason: XB.refusalFor(r.refusal) || 'refused', step: name });
      }
      function fire() {
        attempt++;
        self.t.write(XB.toHex(frame));
        timer = setTimeout(function () {
          if (attempt < attempts && (retryAlways || self.machine.sleeping)) fire();
          else if (retryAlways || attempt >= attempts) { delete self.waiters[code]; reject({ reason: 'no_reply', step: name }); }
          // Awake but silent: the app proceeds as if taken.
          else { delete self.waiters[code]; resolve(false); }
        }, timeout);
      }
      self.waiters[code] = { resolve: finish };
      fire();
    });
  };

  Link.prototype.startBrew = function (recipe) {
    var self = this, b = this.brew;
    b.phase = 'starting'; b.recipe = recipe; b.pour = 0; b.pours = (recipe.pours || []).length;
    b.startedAt = Date.now(); b.error = null; b.fault = null; b.endedAt = 0;
    this.onModule = false;
    this.emit('brew');
    var steps = XB.buildBrewFrames(recipe);
    var chain = Promise.resolve();
    steps.forEach(function (s) {
      chain = chain.then(function () {
        return self.send(s.name, s.frame, { timeout: BREW_STEP_TIMEOUT, attempts: BREW_STEP_ATTEMPTS, retryAlways: true });
      }).then(function () { return sleep(SETTLE); });
    });
    return chain.then(function () {
      var grinds = recipe.grinder_size_enabled !== 0 && recipe.grinder_size > 0;
      if (b.phase === 'starting') b.phase = grinds ? 'grinding' : 'pouring';
      self.emit('brew');
    }, function (err) {
      b.phase = 'failed'; b.error = err.reason || 'error';
      self.emit('brew');
      throw err;
    });
  };

  Link.prototype.pauseBrew = function () { return this.send('pause', XB.packets.pause()); };
  Link.prototype.resumeBrew = function () { return this.send('resume', XB.packets.resume()); };
  Link.prototype.stopBrew = function () {
    var self = this;
    return this.send('stop', XB.packets.stop()).then(function () {
      self.brew.phase = 'stopped'; self.emit('brew');
    });
  };
  Link.prototype.clearBrew = function () {
    this.brew.phase = 'idle'; this.brew.error = null; this.brew.fault = null; this.emit('brew');
  };

  // "XBLOOM ABC123" -> "ABC123": the code printed on the machine.
  Link.machineCode = function (name) { return String(name || '').replace(/^XBLOOM\s*/i, '').trim(); };

  root.Link = Link;
})(window);
