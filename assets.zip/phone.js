/* The phone side of "add a recipe from your phone". Served by the frame
   (PhoneServer.java) over the home Wi-Fi; the token in the URL came from the
   QR on the frame and is sent with every call. */
(function () {
  'use strict';
  var k = (/[?&]k=([0-9a-f]{32})/.exec(location.search) || [])[1] || '';
  var $ = function (id) { return document.getElementById(id); };
  var PATTERN = { 1: 'وسط', 2: 'حلزوني', 3: 'دائري' };
  var CUP = { 1: 'xPod', 2: 'Omni', 3: 'آخر', 4: 'شاي' };
  var ERR = {
    expired: 'الباركود انتهى — اضغط «من جوالك» في البرواز مرة ثانية',
    bad_link: 'هذا مو رابط وصفة xBloom. لازم يبدأ بـ https://share-h5.xbloom.com',
    not_found: 'ما لقينا الوصفة — تأكد إن الرابط كامل',
    network: 'البرواز ما قدر يوصل لـ xBloom — تأكد إن الواي فاي فيه نت',
    no_page: 'البرواز مو جاهز — افتح شاشة «من جوالك» فيه',
    timeout: 'البرواز ما ردّ — جرّب مرة ثانية',
    offline: 'ما وصلنا للبرواز — لازم جوالك على نفس الواي فاي'
  };
  var BAD = { dose: 'كمية البن خارج حدود الكوب', ratio: 'النسبة لازم بين 1:5 و 1:25', water: 'ما فيه ماء',
    grinder: 'إعدادات المطحنة', name: 'اكتب اسم للوصفة', pour_count: 'عدد الدفعات من 1 إلى 9' };

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function msg(el, cls, text) { el.innerHTML = text ? '<div class="msg ' + cls + '">' + esc(text) + '</div>' : ''; }
  function errText(code) {
    code = String(code || '');
    if (code.indexOf('invalid:') === 0) return 'البرواز رفض الوصفة: ' + code.slice(8).split(',').map(function (e) { return BAD[e] || e; }).join('، ');
    return ERR[code] || 'صار خطأ — جرّب مرة ثانية';
  }
  function api(path, body) {
    body.k = k;
    return fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      .then(function (r) { return r.json(); })
      .catch(function () { return { ok: false, error: 'offline' }; });
  }
  function show(expired) { $('expired').className = expired ? 'card' : 'card hide'; $('main').className = expired ? 'hide' : ''; }
  if (!k) show(true);

  function preview(r) {
    var tea = r.cup_type === 4, total = XB.totalWater(r);
    var meta = tea
      ? r.dose_g + ' جم شاي · ' + total + ' مل · ' + r.pours.length + ' نقعة'
      : r.dose_g + ' جم · 1:' + (Math.round(total / r.dose_g * 10) / 10) + ' · ' + total + ' مل · كوب ' + CUP[r.cup_type] +
        (r.grinder_size_enabled ? ' · طحنة ' + r.grinder_size : ' · بن مطحون');
    var pours = r.pours.map(function (p, i) {
      var label = tea ? 'نقعة ' + (i + 1) : (i === 0 && r.pours.length > 1 ? 'ترطيب' : 'صبة ' + (i + 1));
      return '<span>' + label + ': ' + p.volume_ml + ' مل · <bdo dir="ltr">' + p.temperature_c + '°</bdo>' + (p.pause_s ? ' · ' + p.pause_s + 'ث' : '') +
        (tea ? '' : ' · ' + PATTERN[p.pattern]) + '</span>';
    }).join('');
    return '<div class="preview"><b>' + (tea ? '<span class="teatag">شاي</span> ' : '') + esc(r.name || 'بدون اسم') + '</b><div class="meta">' + meta + '</div>' +
      '<div class="pours">' + pours + '</div></div>';
  }

  function send(recipe, out, btn) {
    btn.disabled = true;
    return api('/api/recipe', { recipe: recipe }).then(function (res) {
      btn.disabled = false;
      var box = document.createElement('div');
      box.className = 'sendmsg';
      var old = out.querySelector('.sendmsg'); if (old) old.parentNode.removeChild(old);
      out.appendChild(box);
      if (res.ok) msg(box, 'ok', 'وصلت للبرواز ✓ — تلقاها في «وصفاتك» على الشاشة');
      else { if (res.error === 'expired') show(true); msg(box, 'bad', errText(res.error)); }
      return res.ok;
    });
  }

  // ---- import from an xBloom share link ----
  var imported = null;
  $('fetch').addEventListener('click', function () {
    var link = $('link').value.trim(), out = $('importOut'), btn = this;
    imported = null;
    if (!link) return msg(out, 'bad', 'الصق رابط الوصفة أول');
    btn.disabled = true; btn.textContent = 'نجيبها…';
    api('/api/import', { link: link }).then(function (res) {
      btn.disabled = false; btn.textContent = 'جيب الوصفة';
      if (!res.ok) { if (res.error === 'expired') show(true); return msg(out, 'bad', errText(res.error)); }
      imported = XB.fromXbloom(res.recipe, res.teaVolume);
      var errs = XB.validate(imported);
      out.innerHTML = preview(imported) +
        (imported.bypass ? '<div class="msg warn">الوصفة فيها ماء إضافي (bypass ' + imported.bypass.volume_ml + ' مل) — الساقي ما يدعمه للحين، بتنضاف بدونه.</div>' : '') +
        (errs.length ? '<div class="msg bad">' + esc(errText('invalid:' + errs.join(','))) + '</div>' : '') +
        '<button class="primary" id="sendImport"' + (errs.length ? ' disabled' : '') + '>أرسل للبرواز</button>';
      var sb = $('sendImport');
      sb.addEventListener('click', function () {
        var r = JSON.parse(JSON.stringify(imported)); delete r.bypass;
        send(r, out, sb);
      });
    });
  });

  // ---- type it in ----
  var drink = 'coffee';
  Array.prototype.forEach.call(document.querySelectorAll('#drink button'), function (b) {
    b.addEventListener('click', function () {
      drink = b.getAttribute('data-v');
      Array.prototype.forEach.call(document.querySelectorAll('#drink button'), function (x) { x.className = x === b ? 'on' : ''; });
      $('coffeeFields').className = drink === 'tea' ? 'hide' : '';
      $('teaFields').className = drink === 'tea' ? '' : 'hide';
      update();
    });
  });
  function n(id) { return Number($(id).value); }
  function manual() {
    if (drink === 'tea') {
      var steeps = Math.round(n('steeps')) || 1, pours = [];
      for (var i = 0; i < steeps; i++) pours.push({ volume_ml: n('tVol'), temperature_c: n('tTemp'), pattern: 2, flow_rate: 3.0,
        pause_s: steeps > 1 ? 10 : 0, agitate_before: 2, agitate_after: 2 });
      return XB.sanitize({ name: $('name').value, dose_g: n('leaf'), cup_type: 4, grinder_size_enabled: 0, rpm: 90, pours: pours });
    }
    var dose = n('dose');
    return XB.sanitize({
      name: $('name').value, dose_g: dose, cup_type: dose > 18 ? 3 : 2, // Omni holds up to 18 g
      grinder_size: n('grind'), grinder_size_enabled: Number($('ground').value), rpm: 90,
      pours: XB.autoPours(dose, n('ratio'), Math.min(9, Math.max(1, Math.round(n('pours')) || 3)), n('temp'))
    });
  }
  function update() {
    var r = manual(), errs = XB.validate(r);
    if (!r.name) errs.push('name');
    $('manualOut').innerHTML = preview(r) + (errs.length ? '<div class="msg bad">' + esc(errText('invalid:' + errs.join(','))) + '</div>' : '');
    $('sendManual').disabled = errs.length > 0;
  }
  Array.prototype.forEach.call(document.querySelectorAll('input, select'), function (el) {
    el.addEventListener('input', update); el.addEventListener('change', update);
  });
  $('sendManual').addEventListener('click', function () { send(manual(), $('manualOut'), this); });
  update();
})();
